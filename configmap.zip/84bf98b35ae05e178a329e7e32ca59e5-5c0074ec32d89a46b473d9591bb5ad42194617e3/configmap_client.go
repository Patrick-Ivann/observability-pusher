package k8s

import (
    "context"
    "errors"
    "fmt"
    "time"

    v1 "k8s.io/api/core/v1"
    metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
    "k8s.io/client-go/kubernetes"
)

// ConfigMapClient is the interface for ConfigMap operations
type ConfigMapClient interface {
    CreateConfigMap(ctx context.Context, namespace string, configMap *v1.ConfigMap) (*v1.ConfigMap, error)
    GetConfigMap(ctx context.Context, namespace, name string) (*v1.ConfigMap, error)
    ListConfigMaps(ctx context.Context, namespace string) (*v1.ConfigMapList, error)
    DeleteConfigMap(ctx context.Context, namespace, name string) error
}

// ConfigMapClientImpl is the implementation of ConfigMapClient
type ConfigMapClientImpl struct {
    clientset kubernetes.Interface
    timeout   time.Duration
}

// NewConfigMapClient creates a new instance of ConfigMapClientImpl
func NewConfigMapClient(clientset kubernetes.Interface, timeout time.Duration) ConfigMapClient {
    return &ConfigMapClientImpl{clientset: clientset, timeout: timeout}
}

// CreateConfigMap creates a ConfigMap in the given namespace
func (c *ConfigMapClientImpl) CreateConfigMap(ctx context.Context, namespace string, configMap *v1.ConfigMap) (*v1.ConfigMap, error) {
    ctx, cancel := context.WithTimeout(ctx, c.timeout)
    defer cancel()

    _, err := c.clientset.CoreV1().Namespaces().Get(ctx, namespace, metav1.GetOptions{})
    if err != nil {
        return nil, fmt.Errorf("namespace '%s' does not exist: %w", namespace, err)
    }

    return c.clientset.CoreV1().ConfigMaps(namespace).Create(ctx, configMap, metav1.CreateOptions{})
}

// GetConfigMap retrieves a ConfigMap by name in the given namespace
func (c *ConfigMapClientImpl) GetConfigMap(ctx context.Context, namespace, name string) (*v1.ConfigMap, error) {
    ctx, cancel := context.WithTimeout(ctx, c.timeout)
    defer cancel()

    _, err := c.clientset.CoreV1().Namespaces().Get(ctx, namespace, metav1.GetOptions{})
    if err != nil {
        return nil, fmt.Errorf("namespace '%s' does not exist: %w", namespace, err)
    }

    return c.clientset.CoreV1().ConfigMaps(namespace).Get(ctx, name, metav1.GetOptions{})
}

// ListConfigMaps lists all ConfigMaps in the given namespace
func (c *ConfigMapClientImpl) ListConfigMaps(ctx context.Context, namespace string) (*v1.ConfigMapList, error) {
    ctx, cancel := context.WithTimeout(ctx, c.timeout)
    defer cancel()

    _, err := c.clientset.CoreV1().Namespaces().Get(ctx, namespace, metav1.GetOptions{})
    if err != nil {
        return nil, fmt.Errorf("namespace '%s' does not exist: %w", namespace, err)
    }

    return c.clientset.CoreV1().ConfigMaps(namespace).List(ctx, metav1.ListOptions{})
}

// DeleteConfigMap deletes a ConfigMap by name in the given namespace
func (c *ConfigMapClientImpl) DeleteConfigMap(ctx context.Context, namespace, name string) error {
    ctx, cancel := context.WithTimeout(ctx, c.timeout)
    defer cancel()

    _, err := c.clientset.CoreV1().Namespaces().Get(ctx, namespace, metav1.GetOptions{})
    if err != nil {
        return fmt.Errorf("namespace '%s' does not exist: %w", namespace, err)
    }

    return c.clientset.CoreV1().ConfigMaps(namespace).Delete(ctx, name, metav1.DeleteOptions{})
}
