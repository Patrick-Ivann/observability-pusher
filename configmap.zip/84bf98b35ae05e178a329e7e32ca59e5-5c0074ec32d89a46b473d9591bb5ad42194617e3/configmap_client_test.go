package k8s

import (
    "context"
    "errors"
    "testing"
    "time"

    v1 "k8s.io/api/core/v1"
    metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
    "k8s.io/client-go/kubernetes/fake"
)

func TestConfigMapClient(t *testing.T) {
    clientset := fake.NewSimpleClientset(&v1.Namespace{ObjectMeta: metav1.ObjectMeta{Name: "default"}})
    cmClient := NewConfigMapClient(clientset, 2*time.Second)
    ctx := context.TODO()
    namespace := "default"

    t.Run("CreateConfigMap - Namespace does not exist", func(t *testing.T) {
        _, err := cmClient.CreateConfigMap(ctx, "non-existent", &v1.ConfigMap{})
        if err == nil || !errors.Is(err, context.DeadlineExceeded) {
            t.Fatal("Expected namespace error, got nil or other")
        }
    })

    t.Run("Timeout during GetConfigMap", func(t *testing.T) {
        clientset.PrependReactor("get", "configmaps", func(action testing.Action) (handled bool, ret runtime.Object, err error) {
            time.Sleep(3 * time.Second)
            return false, nil, errors.New("timeout")
        })

        _, err := cmClient.GetConfigMap(ctx, namespace, "slow-config")
        if err == nil || !errors.Is(err, context.DeadlineExceeded) {
            t.Fatal("Expected timeout, got nil or other")
        }
    })

    t.Run("Valid Create and List ConfigMap", func(t *testing.T) {
        cm := &v1.ConfigMap{ObjectMeta: metav1.ObjectMeta{Name: "test-config"}}
        _, err := cmClient.CreateConfigMap(ctx, namespace, cm)
        if err != nil {
            t.Fatalf("Unexpected error: %v", err)
        }

        list, err := cmClient.ListConfigMaps(ctx, namespace)
        if err != nil || len(list.Items) == 0 {
            t.Fatalf("Expected ConfigMap list, got error: %v", err)
        }
    })
}
