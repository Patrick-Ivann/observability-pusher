package k8s

import (
    "k8s.io/client-go/kubernetes"
    "k8s.io/client-go/tools/clientcmd"
    "path/filepath"
)

// CreateKubernetesClient creates a Kubernetes clientset
func CreateKubernetesClient(kubeconfigPath string) (kubernetes.Interface, error) {
    if kubeconfigPath == "" {
        kubeconfigPath = filepath.Join(filepath.Clean(clientcmd.RecommendedHomeFile))
    }

    config, err := clientcmd.BuildConfigFromFlags("", kubeconfigPath)
    if err != nil {
        return nil, err
    }

    return kubernetes.NewForConfig(config)
}
