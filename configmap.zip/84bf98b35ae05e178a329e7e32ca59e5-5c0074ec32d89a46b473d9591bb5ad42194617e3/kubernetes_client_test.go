package k8s

import (
    "os"
    "testing"
)

func TestCreateKubernetesClient(t *testing.T) {
    t.Run("Invalid kubeconfig path", func(t *testing.T) {
        _, err := CreateKubernetesClient("/invalid/path")
        if err == nil {
            t.Fatal("Expected error for invalid kubeconfig path, got nil")
        }
    })

    t.Run("Valid kubeconfig path", func(t *testing.T) {
        os.Setenv("KUBECONFIG", "/path/to/kubeconfig")
        defer os.Unsetenv("KUBECONFIG")

        _, err := CreateKubernetesClient("")
        if err != nil {
            t.Fatalf("Unexpected error: %v", err)
        }
    })
}
