package caching

import (
	"context"
)

// HSet sets multiple fields in a hash
func (r *RedisWrapper) HSet(ctx context.Context, key string, fields map[string]interface{}) error {
	return r.Client.HSet(ctx, key, fields).Err()
}

// HGet gets a single field from a hash
func (r *RedisWrapper) HGet(ctx context.Context, key, field string) (string, error) {
	return r.Client.HGet(ctx, key, field).Result()
}
