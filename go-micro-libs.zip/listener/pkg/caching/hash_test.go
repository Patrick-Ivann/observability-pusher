package caching

import (
	"context"
	"testing"

	"github.com/go-redis/redismock/v8"
	"github.com/stretchr/testify/assert"
)

func TestRedisWrapper_HSet(t *testing.T) {
	db, mock := redismock.NewClientMock()
	mock.ExpectHSet("test-hash", "field1", "value1").SetVal(1)

	rw := &RedisWrapper{Client: db}
	err := rw.HSet(context.Background(), "test-hash", map[string]interface{}{"field1": "value1"})
	assert.NoError(t, err)
	mock.ExpectationsWereMet()
}

func TestRedisWrapper_HGet(t *testing.T) {
	db, mock := redismock.NewClientMock()
	mock.ExpectHGet("test-hash", "field1").SetVal("value1")

	rw := &RedisWrapper{Client: db}
	val, err := rw.HGet(context.Background(), "test-hash", "field1")
	assert.NoError(t, err)
	assert.Equal(t, "value1", val)
	mock.ExpectationsWereMet()
}
