package caching

import (
	"context"
)

// HashOperations defines hash-related commands
type HashOperations interface {
	HSet(ctx context.Context, key string, fields map[string]interface{}) error
	HGet(ctx context.Context, key, field string) (string, error)
}

// StringOperations defines string-related commands
type StringOperations interface {
	Set(ctx context.Context, key string, value interface{}, ttl int64) error
	Get(ctx context.Context, key string) (string, error)
}
