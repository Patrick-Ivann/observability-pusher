package caching

import "context"

// LPush pushes values to the left of a Redis list
func (r *RedisWrapper) LPush(ctx context.Context, key string, values ...interface{}) error {
	return r.Client.LPush(ctx, key, values...).Err()
}

// RPush pushes values to the right of a Redis list
func (r *RedisWrapper) RPush(ctx context.Context, key string, values ...interface{}) error {
	return r.Client.RPush(ctx, key, values...).Err()
}

// LPop pops a value from the left of a Redis list
func (r *RedisWrapper) LPop(ctx context.Context, key string) (string, error) {
	return r.Client.LPop(ctx, key).Result()
}

// RPop pops a value from the right of a Redis list
func (r *RedisWrapper) RPop(ctx context.Context, key string) (string, error) {
	return r.Client.RPop(ctx, key).Result()
}

// LRange retrieves a range of values from a Redis list
func (r *RedisWrapper) LRange(ctx context.Context, key string, start, stop int64) ([]string, error) {
	return r.Client.LRange(ctx, key, start, stop).Result()
}
