package caching

import (
	"context"
	"testing"

	"github.com/go-redis/redismock/v8"
	"github.com/stretchr/testify/assert"
)

func TestRedis_ListOperations(t *testing.T) {
	db, mock := redismock.NewClientMock()
	ctx := context.Background()

	// Mock LPush and RPush
	mock.ExpectLPush("listKey", "left1", "left2").SetVal(2)
	mock.ExpectRPush("listKey", "right1", "right2").SetVal(2)

	rw := &RedisWrapper{Client: db}
	err := rw.LPush(ctx, "listKey", "left1", "left2")
	assert.NoError(t, err)
	err = rw.RPush(ctx, "listKey", "right1", "right2")
	assert.NoError(t, err)

	// Mock LRange
	mock.ExpectLRange("listKey", 0, 3).SetVal([]string{"left1", "left2", "right1", "right2"})

	listRange, err := rw.LRange(ctx, "listKey", 0, 3)
	assert.NoError(t, err)
	assert.Equal(t, []string{"left1", "left2", "right1", "right2"}, listRange)

	// Mock LPop and RPop
	mock.ExpectLPop("listKey").SetVal("left1")
	mock.ExpectRPop("listKey").SetVal("right2")

	leftValue, err := rw.LPop(ctx, "listKey")
	assert.NoError(t, err)

	assert.NotNil(t, leftValue)

}
