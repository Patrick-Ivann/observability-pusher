package caching

import (
	"context"
	"fmt"
	"sync"
	"time"
)

type LocalCacheWrapper struct {
	mu        sync.Map
	expiryMap sync.Map // To track expiration times
}

// Set stores a value in the local cache
func (lc *LocalCacheWrapper) Set(ctx context.Context, key string, value interface{}, ttl int64) error {
	lc.mu.Store(key, value)
	// Store expiration time if TTL is provided
	if ttl > 0 {
		expiration := time.Now().Add(time.Duration(ttl) * time.Second)
		lc.expiryMap.Store(key, expiration)
	} else {
		lc.expiryMap.Delete(key) // Remove expiration if TTL is 0
	}
	return nil
}

// Get retrieves a value from the local cache
func (lc *LocalCacheWrapper) Get(ctx context.Context, key string) (string, error) {
	// Check expiration
	if expiration, ok := lc.expiryMap.Load(key); ok {
		if time.Now().After(expiration.(time.Time)) {
			// Key expired
			lc.mu.Delete(key)
			lc.expiryMap.Delete(key)
			return "", fmt.Errorf("key expired")
		}
	}

	value, ok := lc.mu.Load(key)
	if !ok {
		return "", fmt.Errorf("key not found")
	}
	return fmt.Sprintf("%v", value), nil
}

// HSet stores fields in a hash
func (lc *LocalCacheWrapper) HSet(ctx context.Context, key string, fields map[string]interface{}) error {
	hash, _ := lc.mu.LoadOrStore(key, &sync.Map{})
	hashMap := hash.(*sync.Map)

	for k, v := range fields {
		hashMap.Store(k, v)
	}
	return nil
}

// HGet retrieves a single field from a hash
func (lc *LocalCacheWrapper) HGet(ctx context.Context, key, field string) (string, error) {
	hash, ok := lc.mu.Load(key)
	if !ok {
		return "", fmt.Errorf("hash not found")
	}
	hashMap := hash.(*sync.Map)
	value, ok := hashMap.Load(field)
	if !ok {
		return "", fmt.Errorf("field not found")
	}
	return fmt.Sprintf("%v", value), nil
}

// SAdd adds one or more members to a local cache set
func (lc *LocalCacheWrapper) SAdd(ctx context.Context, key string, members ...interface{}) error {
	set, _ := lc.mu.LoadOrStore(key, &sync.Map{})
	setMap := set.(*sync.Map)
	for _, member := range members {
		setMap.Store(member, struct{}{})
	}
	return nil
}

// SIsMember checks if a member exists in a local cache set
func (lc *LocalCacheWrapper) SIsMember(ctx context.Context, key string, member interface{}) (bool, error) {
	set, ok := lc.mu.Load(key)
	if !ok {
		return false, fmt.Errorf("set not found")
	}
	setMap := set.(*sync.Map)
	_, exists := setMap.Load(member)
	return exists, nil
}

// Close is a noop for the local cache
func (lc *LocalCacheWrapper) Close() error {
	return nil
}

// LPush pushes values to the left of a local cache list
func (lc *LocalCacheWrapper) LPush(ctx context.Context, key string, values ...interface{}) error {
	list, _ := lc.mu.LoadOrStore(key, []interface{}{})
	l := list.([]interface{})
	l = append(values, l...) // Add values to the front
	lc.mu.Store(key, l)
	return nil
}

// RPush pushes values to the right of a local cache list
func (lc *LocalCacheWrapper) RPush(ctx context.Context, key string, values ...interface{}) error {
	list, _ := lc.mu.LoadOrStore(key, []interface{}{})
	l := list.([]interface{})
	l = append(l, values...) // Add values to the end
	lc.mu.Store(key, l)
	return nil
}

// LPop pops a value from the left of a local cache list
func (lc *LocalCacheWrapper) LPop(ctx context.Context, key string) (string, error) {
	list, ok := lc.mu.Load(key)
	if !ok {
		return "", fmt.Errorf("list not found")
	}
	l := list.([]interface{})
	if len(l) == 0 {
		return "", fmt.Errorf("list is empty")
	}
	value := l[0]
	lc.mu.Store(key, l[1:]) // Remove the first element
	return fmt.Sprintf("%v", value), nil
}

// RPop pops a value from the right of a local cache list
func (lc *LocalCacheWrapper) RPop(ctx context.Context, key string) (string, error) {
	list, ok := lc.mu.Load(key)
	if !ok {
		return "", fmt.Errorf("list not found")
	}
	l := list.([]interface{})
	if len(l) == 0 {
		return "", fmt.Errorf("list is empty")
	}
	value := l[len(l)-1]
	lc.mu.Store(key, l[:len(l)-1]) // Remove the last element
	return fmt.Sprintf("%v", value), nil
}

// LRange retrieves a range of values from a local cache list
func (lc *LocalCacheWrapper) LRange(ctx context.Context, key string, start, stop int64) ([]string, error) {
	list, ok := lc.mu.Load(key)
	if !ok {
		return nil, fmt.Errorf("list not found")
	}
	l := list.([]interface{})
	if int64(len(l)) <= start || start > stop {
		return nil, fmt.Errorf("invalid range")
	}
	if stop >= int64(len(l)) {
		stop = int64(len(l)) - 1
	}
	result := l[start : stop+1] // Extract the range
	var stringResult []string
	for _, v := range result {
		stringResult = append(stringResult, fmt.Sprintf("%v", v))
	}
	return stringResult, nil
}
