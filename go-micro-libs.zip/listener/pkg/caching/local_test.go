package caching

import (
	"context"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
)

func TestLocalCache_SetAndGet(t *testing.T) {
	cache := ConnectToLocalCache()
	ctx := context.Background()

	err := cache.Set(ctx, "mykey", "myvalue", 60)
	assert.NoError(t, err)

	val, err := cache.Get(ctx, "mykey")
	assert.NoError(t, err)
	assert.Equal(t, "myvalue", val)
}

func TestLocalCache_Expiration(t *testing.T) {
	cache := ConnectToLocalCache()
	ctx := context.Background()

	err := cache.Set(ctx, "mykey", "myvalue", 1) // 1-second TTL
	assert.NoError(t, err)

	// Wait for expiration
	time.Sleep(2 * time.Second)

	val, err := cache.Get(ctx, "mykey")
	assert.Error(t, err)
	assert.Equal(t, "", val)
}

func TestLocalCache_HSetAndHGet(t *testing.T) {
	cache := ConnectToLocalCache()
	ctx := context.Background()

	err := cache.HSet(ctx, "myhash", map[string]interface{}{"field1": "value1", "field2": "value2"})
	assert.NoError(t, err)

	val, err := cache.HGet(ctx, "myhash", "field1")
	assert.NoError(t, err)
	assert.Equal(t, "value1", val)

	_, err = cache.HGet(ctx, "myhash", "nonexistent")
	assert.Error(t, err)
}

func TestLocalCache_StringOperations(t *testing.T) {
	cache := ConnectToLocalCache()
	ctx := context.Background()

	// Set
	err := cache.Set(ctx, "stringKey", "stringValue", 60)
	assert.NoError(t, err)

	// Get
	value, err := cache.Get(ctx, "stringKey")
	assert.NoError(t, err)
	assert.Equal(t, "stringValue", value)
}

func TestLocalCache_SetOperations(t *testing.T) {
	cache := ConnectToLocalCache()
	ctx := context.Background()

	// SAdd
	err := cache.SAdd(ctx, "setKey", "member1", "member2")
	assert.NoError(t, err)

	// SIsMember
	isMember, err := cache.SIsMember(ctx, "setKey", "member2")
	assert.NoError(t, err)
	assert.True(t, isMember)
}

func TestLocalCache_ListOperations(t *testing.T) {
	cache := ConnectToLocalCache()
	ctx := context.Background()

	// Test LPush and RPush
	err := cache.LPush(ctx, "listKey", "left1", "left2")
	assert.NoError(t, err)
	err = cache.RPush(ctx, "listKey", "right1", "right2")
	assert.NoError(t, err)

	// Test LRange
	listRange, err := cache.LRange(ctx, "listKey", 0, 3)
	assert.NoError(t, err)
	assert.Equal(t, []string{"left1", "left2", "right1", "right2"}, listRange)

	// Test LPop and RPop
	leftValue, err := cache.LPop(ctx, "listKey")
	assert.NoError(t, err)
	assert.Equal(t, "left1", leftValue)

	rightValue, err := cache.RPop(ctx, "listKey")
	assert.NoError(t, err)
	assert.Equal(t, "right2", rightValue)
}
