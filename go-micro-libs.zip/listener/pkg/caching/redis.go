package caching

import (
	"context"
	"fmt"

	"github.com/go-redis/redis/v8"
)

// RedisClientInterface defines the common interface for the Redis client
type RedisClientInterface interface {
	// String
	Set(ctx context.Context, key string, value interface{}, ttl int64) error
	Get(ctx context.Context, key string) (string, error)
	// Hashset
	HSet(ctx context.Context, key string, fields map[string]interface{}) error
	HGet(ctx context.Context, key, field string) (string, error)
	// Set
	SAdd(ctx context.Context, key string, members ...interface{}) error
	SIsMember(ctx context.Context, key string, member interface{}) (bool, error)
	// List
	LPush(ctx context.Context, key string, values ...interface{}) error
	RPush(ctx context.Context, key string, values ...interface{}) error
	LPop(ctx context.Context, key string) (string, error)
	RPop(ctx context.Context, key string) (string, error)
	LRange(ctx context.Context, key string, start, stop int64) ([]string, error)
	Close() error
}

// RedisWrapper implements RedisClientInterface
type RedisWrapper struct {
	Client *redis.Client
}

// RedisClusterWrapper implements RedisClientInterface for cluster mode
type RedisClusterWrapper struct {
	Client *redis.ClusterClient
}

// ConnectToLocalCache creates a connection to a local cache
func ConnectToLocalCache() *LocalCacheWrapper {
	return &LocalCacheWrapper{}
}

// ConnectToStandalone creates a connection to standalone Redis
func ConnectToStandalone(addr, password string, db int) (*RedisWrapper, error) {
	rdb := redis.NewClient(&redis.Options{
		Addr:     addr,
		Password: password,
		DB:       db,
	})
	if err := rdb.Ping(context.Background()).Err(); err != nil {
		return nil, fmt.Errorf("failed to connect to Redis: %w", err)
	}
	return &RedisWrapper{Client: rdb}, nil
}

// ConnectToCluster creates a connection to Redis cluster
func ConnectToCluster(addrs []string, password string) (*RedisClusterWrapper, error) {
	rdb := redis.NewClusterClient(&redis.ClusterOptions{
		Addrs:    addrs,
		Password: password,
	})
	if err := rdb.Ping(context.Background()).Err(); err != nil {
		return nil, fmt.Errorf("failed to connect to Redis cluster: %w", err)
	}
	return &RedisClusterWrapper{Client: rdb}, nil
}

// Close closes a standalone Redis connection
func (r *RedisWrapper) Close() error {
	return r.Client.Close()
}

// Close closes a Redis cluster connection
func (r *RedisClusterWrapper) Close() error {
	return r.Client.Close()
}
