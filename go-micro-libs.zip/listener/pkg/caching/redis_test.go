package caching

import (
	"context"
	"testing"
	"time"

	"github.com/go-redis/redismock/v8"
	"github.com/stretchr/testify/assert"
)

func TestRedis_StringOperations(t *testing.T) {
	db, mock := redismock.NewClientMock()
	ctx := context.Background()

	// Mock Set
	mock.ExpectSet("stringKey", "stringValue", time.Second*60).SetVal("OK")

	rw := &RedisWrapper{Client: db}
	err := rw.Set(ctx, "stringKey", "stringValue", 60)
	assert.NoError(t, err)

	// Mock Get
	mock.ExpectGet("stringKey").SetVal("stringValue")

	value, err := rw.Get(ctx, "stringKey")
	assert.NoError(t, err)
	assert.Equal(t, "stringValue", value)
}

func TestRedis_SetOperations(t *testing.T) {
	db, mock := redismock.NewClientMock()
	ctx := context.Background()

	// Mock SAdd
	mock.ExpectSAdd("setKey", "member1", "member2").SetVal(2)

	rw := &RedisWrapper{Client: db}
	err := rw.SAdd(ctx, "setKey", "member1", "member2")
	assert.NoError(t, err)

	// Mock SIsMember
	mock.ExpectSIsMember("setKey", "member2").SetVal(true)

	isMember, err := rw.SIsMember(ctx, "setKey", "member2")
	assert.NoError(t, err)
	assert.True(t, isMember)
}
