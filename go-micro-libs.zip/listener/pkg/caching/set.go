package caching

import "context"

// SAdd adds one or more members to a Redis set
func (r *RedisWrapper) SAdd(ctx context.Context, key string, members ...interface{}) error {
	return r.Client.SAdd(ctx, key, members...).Err()
}

// SIsMember checks if a member exists in a Redis set
func (r *RedisWrapper) SIsMember(ctx context.Context, key string, member interface{}) (bool, error) {
	return r.Client.SIsMember(ctx, key, member).Result()
}
