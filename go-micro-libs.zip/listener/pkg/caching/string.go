package caching

import (
	"context"
	"time"
)

// Set adds a string value to Redis with TTL (time-to-live)
func (r *RedisWrapper) Set(ctx context.Context, key string, value interface{}, ttl int64) error {
	return r.Client.Set(ctx, key, value, time.Duration(ttl)*time.Second).Err()
}

// Get retrieves a string value from Redis by key
func (r *RedisWrapper) Get(ctx context.Context, key string) (string, error) {
	return r.Client.Get(ctx, key).Result()
}
