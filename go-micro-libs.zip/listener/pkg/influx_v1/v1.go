package influxv1

import (
	"fmt"

	client "github.com/influxdata/influxdb1-client/v2"
)

type InfluxDBClient struct {
	client client.Client
	db     string
}

func NewInfluxDBClient(url, db string) (*InfluxDBClient, error) {
	cli, err := client.NewHTTPClient(client.HTTPConfig{Addr: url})
	if err != nil {
		return nil, err
	}
	return &InfluxDBClient{client: cli, db: db}, nil
}

func (db *InfluxDBClient) Ping() error {
	_, _, err := db.client.Ping(0)
	return err
}

func (db *InfluxDBClient) WritePoint(measurement string, tags map[string]string, fields map[string]interface{}) error {
	bp, _ := client.NewBatchPoints(client.BatchPointsConfig{Database: db.db})
	pt, err := client.NewPoint(measurement, tags, fields)
	if err != nil {
		return err
	}
	bp.AddPoint(pt)
	return db.client.Write(bp)
}

func (db *InfluxDBClient) WritePoints(points []*client.Point) error {
	bp, _ := client.NewBatchPoints(client.BatchPointsConfig{Database: db.db})
	bp.AddPoints(points)
	return db.client.Write(bp)
}

func (db *InfluxDBClient) CreateDatabase(name string) error {
	query := fmt.Sprintf(`CREATE DATABASE "%s"`, name)
	_, err := db.client.Query(client.NewQuery(query, "", ""))
	return err
}

func (db *InfluxDBClient) DeleteDatabase(name string) error {
	query := fmt.Sprintf(`DROP DATABASE "%s"`, name)
	_, err := db.client.Query(client.NewQuery(query, "", ""))
	return err
}

func (db *InfluxDBClient) ChangeRetentionPolicy(database, policyName, duration string) error {
	query := fmt.Sprintf(`ALTER RETENTION POLICY "%s" ON "%s" DURATION %s DEFAULT`, policyName, database, duration)
	_, err := db.client.Query(client.NewQuery(query, "", ""))
	return err
}

func (db *InfluxDBClient) GetMeasurements() ([]string, error) {
	query := `SHOW MEASUREMENTS`
	response, err := db.client.Query(client.NewQuery(query, db.db, ""))
	if err != nil {
		return nil, err
	}

	var measurements []string
	for _, result := range response.Results {
		for _, row := range result.Series {
			for _, value := range row.Values {
				measurements = append(measurements, value[0].(string))
			}
		}
	}
	return measurements, nil
}

func (db *InfluxDBClient) GetMeasurementsWithFilters(filters map[string]string) ([]string, error) {
	query := `SHOW MEASUREMENTS`
	for k, v := range filters {
		query += fmt.Sprintf(` WHERE %s='%s'`, k, v)
	}

	response, err := db.client.Query(client.NewQuery(query, db.db, ""))
	if err != nil {
		return nil, err
	}

	var measurements []string
	for _, result := range response.Results {
		for _, row := range result.Series {
			for _, value := range row.Values {
				measurements = append(measurements, value[0].(string))
			}
		}
	}
	return measurements, nil
}
