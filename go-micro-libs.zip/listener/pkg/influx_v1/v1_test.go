package influxv1

import (
	"testing"

	"github.com/stretchr/testify/assert"
)

func TestPing(t *testing.T) {
	client, _ := NewInfluxDBClient("http://localhost:8086", "testdb")
	err := client.Ping()
	assert.Nil(t, err)
}

func TestWritePoint(t *testing.T) {
	client, _ := NewInfluxDBClient("http://localhost:8086", "testdb")

	tags := map[string]string{"sensor": "temperature"}
	fields := map[string]interface{}{"value": 22.5}

	err := client.WritePoint("sensor_data", tags, fields)
	assert.Nil(t, err)
}

func TestCreateDatabase(t *testing.T) {
	client, _ := NewInfluxDBClient("http://localhost:8086", "testdb")

	err := client.CreateDatabase("newdb")
	assert.Nil(t, err)
}

func TestDeleteDatabase(t *testing.T) {
	client, _ := NewInfluxDBClient("http://localhost:8086", "testdb")

	err := client.DeleteDatabase("newdb")
	assert.Nil(t, err)
}

func TestChangeRetentionPolicy(t *testing.T) {
	client, _ := NewInfluxDBClient("http://localhost:8086", "testdb")

	err := client.ChangeRetentionPolicy("testdb", "autogen", "7d")
	assert.Nil(t, err)
}

func TestGetMeasurements(t *testing.T) {
	client, _ := NewInfluxDBClient("http://localhost:8086", "testdb")

	measurements, err := client.GetMeasurements()
	assert.Nil(t, err)
	assert.NotEmpty(t, measurements)
}

func TestGetMeasurementsWithFilters(t *testing.T) {
	client, _ := NewInfluxDBClient("http://localhost:8086", "testdb")

	filters := map[string]string{"sensor": "temperature"}
	measurements, err := client.GetMeasurementsWithFilters(filters)
	assert.Nil(t, err)
	assert.NotEmpty(t, measurements)
}
