package logger

import (
	"bytes"
	"fmt"
	"os"
	"testing"
	"text/template"

	"github.com/sirupsen/logrus"
	"github.com/stretchr/testify/assert"
)

func TestNewLogger(t *testing.T) {
	logger, err := NewLogger("info", "testdata/log_templates.xml")
	assert.NoError(t, err)
	assert.NotNil(t, logger)
	assert.NotNil(t, logger.StandardLogger)
	assert.NotNil(t, logger.DetailedLogger)
	assert.NotEmpty(t, logger.DetailedLogger.LogTemplates)
	assert.NotEmpty(t, logger.DetailedLogger.TemplateCache)
}

func TestLogStandard(t *testing.T) {
	var buf bytes.Buffer
	stdLogger := logrus.New()
	stdLogger.SetOutput(&buf)
	stdLogger.SetFormatter(&logrus.JSONFormatter{})

	logger := &Logger{
		StandardLogger: stdLogger,
	}

	logger.StandardLogger.Info("Test standard log")
	assert.Contains(t, buf.String(), `"msg":"Test standard log"`)
}

func TestLogDetailed(t *testing.T) {
	var buf bytes.Buffer
	detailLogger := logrus.New()
	detailLogger.SetOutput(&buf)
	detailLogger.SetFormatter(&logrus.JSONFormatter{})

	dLogger := &DetailedLogger{
		Logger: detailLogger,
		LogTemplates: map[string]Log{
			"TEST_KEY": {
				Key:     "TEST_KEY",
				Message: "User {0} logged in from IP {1}",
				Properties: []Property{
					{Name: "criticality", Value: "Medium"},
				},
			},
		},
		TemplateCache: map[string]*template.Template{
			"TEST_KEY": template.Must(template.New("TEST_KEY").Parse("User {0} logged in from IP {1}")),
		},
	}

	dLogger.LogDetailed("TEST_KEY", "user123", "192.168.1.1")
	assert.Contains(t, buf.String(), `"criticality":"Medium"`)
	assert.Contains(t, buf.String(), `"message":"User user123 logged in from IP 192.168.1.1"`)
}

func TestLogDetailed_MissingTemplate(t *testing.T) {
	var buf bytes.Buffer
	detailLogger := logrus.New()
	detailLogger.SetOutput(&buf)
	detailLogger.SetFormatter(&logrus.JSONFormatter{})

	// Detailed logger setup with no templates
	dLogger := &DetailedLogger{
		Logger:        detailLogger,
		LogTemplates:  map[string]Log{},                // Empty templates map
		TemplateCache: map[string]*template.Template{}, // Empty cache
	}

	// Attempt to log with a non-existent template key
	dLogger.LogDetailed("NON_EXISTENT_KEY", "param1", "param2")
	assert.Contains(t, buf.String(), `Log template for key NON_EXISTENT_KEY not found`)
}

func TestParseLogTemplates_FileOpenError(t *testing.T) {
	// Mock openFile function to simulate an error
	mockOpenFile := func(name string) (*os.File, error) {
		return nil, fmt.Errorf("mock file open error")
	}

	_, _, err := parseLogTemplates("non-existent-file.xml", mockOpenFile)
	assert.Error(t, err)
	assert.Equal(t, "failed to open XML file: mock file open error", err.Error())
}

func TestParseLogTemplates_XMLDecodeError(t *testing.T) {
	// Temporary invalid XML file
	fileContent := []byte("<InvalidXML>")
	tmpFile, err := os.CreateTemp("", "invalid-xml-*.xml")
	assert.NoError(t, err)
	defer os.Remove(tmpFile.Name())

	_, err = tmpFile.Write(fileContent)
	assert.NoError(t, err)
	tmpFile.Close()

	// Mock openFile function
	mockOpenFile := func(name string) (*os.File, error) {
		return os.Open(name)
	}

	_, _, err = parseLogTemplates(tmpFile.Name(), mockOpenFile)
	assert.Error(t, err)
	assert.Contains(t, err.Error(), "failed to parse XML file")
}

// func TestParseLogTemplates_FileOpenError(t *testing.T) {
// 	// Save the original os.Open function
// 	originalOpen := os.Open
// 	defer func() { os.Open = originalOpen }()

// 	// Mock os.Open to return an error
// 	os.Open = func(name string) (*os.File, error) {
// 		return nil, errors.New("mock file open error")
// 	}

// 	_, _, err := parseLogTemplates("non-existent-file.xml")
// 	assert.Error(t, err)
// 	assert.Equal(t, "failed to open XML file: mock file open error", err.Error())
// }

// func TestParseLogTemplates_XMLDecodeError(t *testing.T) {
// 	// Create a temporary invalid XML file
// 	fileContent := []byte("<InvalidXML>")
// 	tmpFile, err := os.CreateTemp("", "invalid-xml-*.xml")
// 	assert.NoError(t, err)
// 	defer os.Remove(tmpFile.Name())

// 	_, err = tmpFile.Write(fileContent)
// 	assert.NoError(t, err)
// 	tmpFile.Close()

// 	// Test parseLogTemplates
// 	_, _, err = parseLogTemplates(tmpFile.Name())
// 	assert.Error(t, err)
// 	assert.Contains(t, err.Error(), "failed to parse XML file")
// }

// func TestParseLogTemplates_TemplateParsingError(t *testing.T) {
// 	// Create a temporary XML file with invalid template syntax
// 	fileContent := []byte(`
// <LogTemplates>
//     <Log key="INVALID_TEMPLATE">
//         <Message>User {INVALID_PLACEHOLDER logged in from IP {1}</Message>
//         <Properties>
//             <Property name="criticality" value="Medium" />
//         </Properties>
//     </Log>
// </LogTemplates>
// `)
// 	tmpFile, err := os.CreateTemp("", "invalid-template-*.xml")
// 	assert.NoError(t, err)
// 	defer os.Remove(tmpFile.Name())

// 	_, err = tmpFile.Write(fileContent)
// 	assert.NoError(t, err)
// 	tmpFile.Close()

// 	// Test parseLogTemplates
// 	_, _, err = parseLogTemplates(tmpFile.Name())
// 	assert.Error(t, err)
// 	assert.Contains(t, err.Error(), "failed to compile template for key INVALID_TEMPLATE")
// }

// func TestParseLogTemplates_TemplateParsingError(t *testing.T) {
// 	// Temporary XML file with invalid template syntax
// 	fileContent := []byte(`
// <LogTemplates>
//     <Log key="INVALID_TEMPLATE">
//         <Message>User {INVALID_PLACEHOLDER} logged in from IP {1}</Message>
//         <Properties>
//             <Property name="criticality" value="Medium" />
//         </Properties>
//     </Log>
// </LogTemplates>
// `)
// 	tmpFile, err := os.CreateTemp("", "invalid-template-*.xml")
// 	assert.NoError(t, err)
// 	defer os.Remove(tmpFile.Name())

// 	_, err = tmpFile.Write(fileContent)
// 	assert.NoError(t, err)
// 	tmpFile.Close()

// 	// Mock openFile function
// 	mockOpenFile := func(name string) (*os.File, error) {
// 		return os.Open(name)
// 	}

// 	_, _, err = parseLogTemplates(tmpFile.Name(), mockOpenFile)
// 	assert.Error(t, err)
// 	assert.Contains(t, err.Error(), "failed to compile template for key INVALID_TEMPLATE")
// }
