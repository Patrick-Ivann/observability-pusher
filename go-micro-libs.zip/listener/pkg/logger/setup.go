package logger

import (
    "github.com/sirupsen/logrus"
)

func InitLogger(level string) *logrus.Logger {
    logger := logrus.New()
    parsedLevel, err := logrus.ParseLevel(level)
    if err != nil {
        parsedLevel = logrus.InfoLevel
    }
    logger.SetLevel(parsedLevel)
    return logger
}
