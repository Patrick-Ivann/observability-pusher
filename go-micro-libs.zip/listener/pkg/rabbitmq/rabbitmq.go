package rabbitmq

import (
	"github.com/streadway/amqp"
)

// Define an interface for the channel
type ChannelInterface interface {
	ExchangeDeclare(name, kind string, durable, autoDelete, internal, noWait bool, args amqp.Table) error
	Publish(exchange, key string, mandatory, immediate bool, msg amqp.Publishing) error
	QueueDeclare(name string, durable, autoDelete, exclusive, noWait bool, args amqp.Table) (amqp.Queue, error)
	QueueBind(name, key, exchange string, noWait bool, args amqp.Table) error
	Consume(name, consumer string, autoAck, exclusive, noLocal, noWait bool, args amqp.Table) (<-chan amqp.Delivery, error)
	Get(queue string, autoAck bool) (amqp.Delivery, bool, error)
	Close() error
}

type ConnectionInterface interface {
	Channel() (ChannelInterface, error)
	Close() error
}

type RabbitMQService struct {
	Connection ConnectionInterface
	Channel    ChannelInterface
}

// NewRabbitMQService creates a new RabbitMQ service
func NewRabbitMQService(conn ConnectionInterface) (*RabbitMQService, error) {
	channel, err := conn.Channel()
	if err != nil {
		return nil, err
	}

	return &RabbitMQService{
		Connection: conn,
		Channel:    channel,
	}, nil
}

// CreateExchange declares an exchange if it doesn't exist
func (r *RabbitMQService) CreateExchange(name, kind string) error {
	err := r.Channel.ExchangeDeclare(
		name,  // name
		kind,  // type ("topic", "direct", "headers", etc.)
		true,  // durable
		false, // auto-deleted
		false, // internal
		false, // no-wait
		nil,   // arguments
	)
	return err
}

// PublishMessage publishes a message with headers and properties
func (r *RabbitMQService) PublishMessage(exchange, routingKey string, body []byte, headers map[string]interface{}, properties amqp.Table) error {
	err := r.Channel.Publish(
		exchange,   // exchange
		routingKey, // routing key
		false,      // mandatory
		false,      // immediate
		amqp.Publishing{
			ContentType:  "application/json",
			Body:         body,
			Headers:      headers,
			DeliveryMode: amqp.Persistent, // Makes the message persistent
			MessageId:    "message_id",    // Example property
			AppId:        "your-app",      // Example property
		},
	)
	return err
}

// ReadMessagesFromTopicExchange listens to messages from a topic exchange
func (r *RabbitMQService) ReadMessagesFromTopicExchange(exchange, routingKey, queue string) (<-chan amqp.Delivery, error) {
	_, err := r.Channel.QueueDeclare(
		queue, // name of the queue
		true,  // durable
		false, // delete when unused
		false, // exclusive
		false, // no-wait
		nil,   // arguments
	)
	if err != nil {
		return nil, err
	}

	err = r.Channel.QueueBind(
		queue,      // queue name
		routingKey, // routing key
		exchange,   // exchange name
		false,      // no-wait
		nil,        // arguments
	)
	if err != nil {
		return nil, err
	}

	msgs, err := r.Channel.Consume(
		queue, // queue name
		"",    // consumer tag
		true,  // auto-ack
		false, // exclusive
		false, // no-local
		false, // no-wait
		nil,   // arguments
	)
	if err != nil {
		return nil, err
	}

	return msgs, nil
}

// ReadMessagesFromDirectExchange listens to messages from a direct exchange
func (r *RabbitMQService) ReadMessagesFromDirectExchange(exchange, routingKey, queue string) (<-chan amqp.Delivery, error) {
	return r.ReadMessagesFromTopicExchange(exchange, routingKey, queue)
}

// ReadMessagesFromHeaderExchange listens to messages from a headers exchange
func (r *RabbitMQService) ReadMessagesFromHeaderExchange(exchange string, headers map[string]interface{}, queue string) (<-chan amqp.Delivery, error) {
	_, err := r.Channel.QueueDeclare(
		queue, // name of the queue
		true,  // durable
		false, // delete when unused
		false, // exclusive
		false, // no-wait
		nil,   // arguments
	)
	if err != nil {
		return nil, err
	}

	err = r.Channel.QueueBind(
		queue,    // queue name
		"",       // empty routing key for headers exchange
		exchange, // exchange name
		false,    // no-wait
		headers,  // binding headers
	)
	if err != nil {
		return nil, err
	}

	msgs, err := r.Channel.Consume(
		queue, // queue name
		"",    // consumer tag
		true,  // auto-ack
		false, // exclusive
		false, // no-local
		false, // no-wait
		nil,   // arguments
	)
	if err != nil {
		return nil, err
	}

	return msgs, nil
}

// ReadMessagesBatch retrieves a batch of messages from the queue
func (r *RabbitMQService) ReadMessagesBatch(queue string, batchSize int) ([]amqp.Delivery, error) {
	var messages []amqp.Delivery
	for i := 0; i < batchSize; i++ {
		delivery, ok, err := r.Channel.Get(
			queue, // queue name
			true,  // auto-ack
		)
		if err != nil {
			return nil, err
		}
		if !ok {
			break // No more messages in the queue
		}
		messages = append(messages, delivery)
	}
	return messages, nil
}

// ReadMessage retrieves a single message from the queue
func (r *RabbitMQService) ReadMessage(queue string) (*amqp.Delivery, error) {
	delivery, ok, err := r.Channel.Get(
		queue, // queue name
		true,  // auto-ack
	)
	if err != nil {
		return nil, err
	}
	if !ok {
		return nil, nil // No message available
	}
	return &delivery, nil
}

// Close RabbitMQ connection and channel
func (r *RabbitMQService) Close() error {
	if r.Channel != nil {
		if err := r.Channel.Close(); err != nil {
			return err
		}
	}
	if r.Connection == nil {
		return nil
	}
	return r.Connection.Close()
}
