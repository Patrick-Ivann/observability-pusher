package rabbitmq

import (
	"errors"
	"testing"

	"github.com/streadway/amqp"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
)

func TestChannelWrapper_ExchangeDeclare(t *testing.T) {
	mockChannel := new(MockChannel)
	mockChannel.On("ExchangeDeclare", "test-exchange", "topic", true, false, false, false, mock.AnythingOfType("amqp.Table")).Return(nil)

	cw := &ChannelWrapper{Channel: mockChannel}
	err := cw.ExchangeDeclare("test-exchange", "topic", true, false, false, false, nil)

	assert.NoError(t, err)
	mockChannel.AssertExpectations(t)
}
func TestChannelWrapper_Publish(t *testing.T) {
	mockChannel := new(MockChannel)

	mockChannel.On("Publish", "test-exchange", "key", true, false, mock.AnythingOfType("amqp.Publishing")).Return(nil)

	msg := amqp.Publishing{}
	cw := &ChannelWrapper{Channel: mockChannel}
	err := cw.Publish("test-exchange", "key", true, false, msg)

	assert.NoError(t, err)
	mockChannel.AssertExpectations(t)
}
func TestChannelWrapper_QueueDeclare(t *testing.T) {
	mockChannel := new(MockChannel)
	queueDeclare := amqp.Queue{}

	mockChannel.On("QueueDeclare", "test-exchange", true, false, true, true, mock.AnythingOfType("amqp.Table")).Return(queueDeclare, nil)

	table := amqp.Table{}
	cw := &ChannelWrapper{Channel: mockChannel}
	queueDeclared, err := cw.QueueDeclare("test-exchange", true, false, true, true, table)

	assert.NotNil(t, queueDeclared)
	assert.NoError(t, err)
	mockChannel.AssertExpectations(t)
}
func TestChannelWrapper_QueueBind(t *testing.T) {
	mockChannel := new(MockChannel)

	mockChannel.On("QueueBind", "test-queue", "test-exchange", "test-key", true, mock.AnythingOfType("amqp.Table")).Return(nil)

	table := amqp.Table{}
	cw := &ChannelWrapper{Channel: mockChannel}
	err := cw.QueueBind("test-queue", "test-exchange", "test-key", true, table)

	assert.NoError(t, err)
	mockChannel.AssertExpectations(t)
}
func TestChannelWrapper_Consume(t *testing.T) {
	mockChannel := new(MockChannel)
	dd := make(<-chan amqp.Delivery, 0)

	mockChannel.On("Consume", "test-exchange", "consumer", true, false, true, true, mock.AnythingOfType("amqp.Table")).Return(dd, nil)
	table := amqp.Table{}
	cw := &ChannelWrapper{Channel: mockChannel}
	returnerDelivered, err := cw.Consume("test-exchange", "consumer", true, false, true, true, table)

	assert.NotNil(t, returnerDelivered)
	assert.NoError(t, err)
	mockChannel.AssertExpectations(t)
}

func TestChannelWrapper_Get(t *testing.T) {
	mockChannel := new(MockChannel)
	delivery := amqp.Delivery{}

	mockChannel.On("Get", "test-queue", true).Return(delivery, true, nil)
	cw := &ChannelWrapper{Channel: mockChannel}
	delivery, ok, err := cw.Get("test-queue", true)

	assert.NotNil(t, ok)
	assert.NotNil(t, delivery)
	assert.NoError(t, err)
	mockChannel.AssertExpectations(t)
}

func TestChannelWrapper_ExchangeDeclare_Error(t *testing.T) {
	mockChannel := new(MockChannel)
	mockChannel.On("ExchangeDeclare", "test-exchange", "topic", true, false, false, false, mock.AnythingOfType("amqp.Table")).Return(errors.New("exchange declare error"))

	cw := &ChannelWrapper{Channel: mockChannel}
	err := cw.ExchangeDeclare("test-exchange", "topic", true, false, false, false, nil)

	assert.Error(t, err)
	assert.Equal(t, "exchange declare error", err.Error())
	mockChannel.AssertExpectations(t)
}
