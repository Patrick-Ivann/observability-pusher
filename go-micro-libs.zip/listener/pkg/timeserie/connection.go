package timeserie

import (
	"context"
	"fmt"

	influxdb2 "github.com/influxdata/influxdb-client-go/v2"
	influxdb1 "github.com/influxdata/influxdb1-client/v2"
)

// InfluxV1Wrapper wraps the InfluxDB v1 client
type InfluxV1Wrapper struct {
	Client influxdb1.Client
}

// InfluxV2Wrapper wraps the InfluxDB v2 client
type InfluxV2Wrapper struct {
	Client influxdb2.Client
}

// ConnectToInfluxV1 connects to InfluxDB v1
func ConnectToInfluxV1(addr, username, password string) (*InfluxV1Wrapper, error) {
	client, err := influxdb1.NewHTTPClient(influxdb1.HTTPConfig{
		Addr:     addr,
		Username: username,
		Password: password,
	})
	if err != nil {
		return nil, fmt.Errorf("failed to connect to InfluxDB v1: %w", err)
	}
	return &InfluxV1Wrapper{Client: client}, nil
}

// ConnectToInfluxV2 connects to InfluxDB v2
func ConnectToInfluxV2(addr, token string) (*InfluxV2Wrapper, error) {
	client := influxdb2.NewClient(addr, token)
	if _, err := client.Ping(context.Background()); err != nil {
		return nil, fmt.Errorf("failed to connect to InfluxDB v2: %w", err)
	}
	return &InfluxV2Wrapper{Client: client}, nil
}

// Close closes InfluxDB v1 connection
func (iw *InfluxV1Wrapper) Close() error {
	return iw.Client.Close()
}

// Close closes InfluxDB v2 connection
func (iw *InfluxV2Wrapper) Close() error {
	iw.Client.Close()
	return nil
}
