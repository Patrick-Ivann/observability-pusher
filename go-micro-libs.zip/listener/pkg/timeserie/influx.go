package timeserie

import (
	"context"
)

// InfluxClientInterface defines operations for both InfluxDB v1 and v2
type InfluxClientInterface interface {
	WritePoint(ctx context.Context, measurement string, tags map[string]string, fields map[string]interface{}, timestamp int64) error
	WritePoints(ctx context.Context, points []Point) error
	Close() error
}

// ManagementInterface defines management operations
type ManagementInterface interface {
	CreateDatabase(ctx context.Context, name string, retentionPolicy string) error
	DeleteDatabase(ctx context.Context, name string) error
	UpdateRetentionPolicy(ctx context.Context, dbName, retentionPolicy string) error
}

// Point represents a single Line Protocol data point
type Point struct {
	Measurement string
	Tags        map[string]string
	Fields      map[string]interface{}
	Timestamp   int64
}
