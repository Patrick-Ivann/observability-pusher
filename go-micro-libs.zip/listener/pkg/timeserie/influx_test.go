package timeserie

import (
	"testing"
	"time"

	client "github.com/influxdata/influxdb1-client"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
)

type MockV1Client struct {
	mock.Mock
}

// Ping mocks the Ping operation for testing connectivity
func (m *MockV1Client) Ping(timeout time.Duration) (time.Duration, string, error) {
	args := m.Called(timeout)
	return args.Get(0).(time.Duration), args.String(1), args.Error(2)
}

// Query mocks the Query operation for executing InfluxQL queries
func (m *MockV1Client) Query(q client.Query) (*client.Response, error) {
	args := m.Called(q)
	return args.Get(0).(*client.Response), args.Error(1)
}

// Write mocks the Write operation for writing data points
func (m *MockV1Client) Write(bp client.BatchPoints) error {
	args := m.Called(bp)
	return args.Error(0)
}

// Close mocks the Close operation for closing the client
func (m *MockV1Client) Close() error {
	args := m.Called()
	return args.Error(0)
}

func TestConnectToInfluxV1_Success(t *testing.T) {
	client, err := ConnectToInfluxV1("http://localhost:8086", "user", "password")
	assert.NoError(t, err)
	assert.NotNil(t, client)
}

func TestConnectToInfluxV1_Error(t *testing.T) {
	client, err := ConnectToInfluxV1("http://invalid-address", "user", "password")
	assert.Error(t, err)
	assert.Nil(t, client)
}

func TestConnectToInfluxV2_Success(t *testing.T) {
	client, err := ConnectToInfluxV2("http://localhost:8086", "my-token")
	assert.NoError(t, err)
	assert.NotNil(t, client)
}

func TestConnectToInfluxV2_Error(t *testing.T) {
	client, err := ConnectToInfluxV2("http://invalid-address", "my-token")
	assert.Error(t, err)
	assert.Nil(t, client)
}
