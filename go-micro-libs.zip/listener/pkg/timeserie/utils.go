package timeserie

import (
	"strconv"
)

// parseDuration converts human-readable duration strings (e.g., "7d", "30m") into seconds.
func parseDuration(duration string) int64 {
	unit := duration[len(duration)-1] // Extracts the last character (time unit)
	valueStr := duration[:len(duration)-1]
	value, err := strconv.Atoi(valueStr)
	if err != nil {
		return 0 // Handle error appropriately in the application
	}

	switch unit {
	case 's':
		return int64(value)
	case 'm':
		return int64(value * 60)
	case 'h':
		return int64(value * 3600)
	case 'd':
		return int64(value * 86400)
	case 'w':
		return int64(value * 604800)
	case 'M': // Month (approximate)
		return int64(value * 2592000)
	case 'y': // Year (approximate)
		return int64(value * 31536000)
	default:
		return 0 // Unknown unit
	}
}
