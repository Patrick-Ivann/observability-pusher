package timeserie

import (
	"context"
	"fmt"
	"time"

	influxdb2 "github.com/influxdata/influxdb-client-go/v2"
	"github.com/influxdata/influxdb-client-go/v2/api/write"
	"github.com/influxdata/influxdb-client-go/v2/domain"
)

type InfluxDBClient struct {
	client influxdb2.Client
	org    string
	bucket string
}

func NewInfluxDBClient(url, token, org, bucket string) *InfluxDBClient {
	client := influxdb2.NewClient(url, token)
	return &InfluxDBClient{client: client, org: org, bucket: bucket}
}

func (db *InfluxDBClient) Ping(ctx context.Context) error {
	ready, err := db.client.Health(ctx)
	if err != nil || ready.Status != "pass" {
		return fmt.Errorf("InfluxDB not reachable: %v", err)
	}
	return nil
}

func (db *InfluxDBClient) WritePoint(ctx context.Context, measurement string, tags map[string]string, fields map[string]interface{}) error {
	writeAPI := db.client.WriteAPIBlocking(db.org, db.bucket)
	p := influxdb2.NewPoint(measurement, tags, fields, time.Now())
	return writeAPI.WritePoint(ctx, p)
}

func (db *InfluxDBClient) WritePoints(ctx context.Context, points []*write.Point) error {
	writeAPI := db.client.WriteAPIBlocking(db.org, db.bucket)
	return writeAPI.WritePoint(ctx, points...)
}

func (db *InfluxDBClient) CreateBucket(ctx context.Context, name string, duration string) error {

	bucketAPI := db.client.BucketsAPI()
	bucket := &domain.Bucket{Name: name, OrgID: &db.org, RetentionRules: []domain.RetentionRule{{EverySeconds: parseDuration(duration)}}}
	_, err := bucketAPI.CreateBucket(ctx, bucket)
	return err
}

func (db *InfluxDBClient) DeleteBucket(ctx context.Context, name string) error {
	bucketAPI := db.client.BucketsAPI()
	b, err := bucketAPI.FindBucketByName(ctx, name)
	if err != nil {
		return err
	}
	return bucketAPI.DeleteBucket(ctx, b)
}

func (db *InfluxDBClient) ChangeRetentionPolicy(ctx context.Context, bucket string, duration string) (*domain.Bucket, error) {
	bucketAPI := db.client.BucketsAPI()
	b, err := bucketAPI.FindBucketByName(ctx, bucket)
	if err != nil {
		return nil, err
	}
	b.RetentionRules[0].EverySeconds = parseDuration(duration)
	return bucketAPI.UpdateBucket(ctx, b)
}

func (db *InfluxDBClient) GetMeasurements(ctx context.Context) ([]string, error) {
	query := `import "influxdata/influxdb/schema" schema.measurements(bucket: "` + db.bucket + `")`
	queryAPI := db.client.QueryAPI(db.org)
	result, err := queryAPI.Query(ctx, query)
	if err != nil {
		return nil, err
	}

	var measurements []string
	for result.Next() {
		measurements = append(measurements, result.Record().Value().(string))
	}
	return measurements, nil
}

func (db *InfluxDBClient) GetMeasurementsWithFilters(ctx context.Context, filters map[string]string) ([]string, error) {
	query := `import "influxdata/influxdb/schema" schema.measurements(bucket: "` + db.bucket + `")`
	for k, v := range filters {
		query += fmt.Sprintf(` |> filter(fn: (r) => r.%s == "%s")`, k, v)
	}

	queryAPI := db.client.QueryAPI(db.org)
	result, err := queryAPI.Query(ctx, query)
	if err != nil {
		return nil, err
	}

	var measurements []string
	for result.Next() {
		measurements = append(measurements, result.Record().Value().(string))
	}
	return measurements, nil
}
