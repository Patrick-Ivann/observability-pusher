package timeserie

import (
	"context"
	"testing"

	"github.com/stretchr/testify/assert"
)

func TestCreateBucket(t *testing.T) {
	client := NewInfluxDBClient("http://localhost:8086", "my-token", "my-org", "my-bucket")
	err := client.CreateBucket(context.Background(), "test_bucket", "7d")
	assert.Nil(t, err)
}

func TestDeleteBucket(t *testing.T) {
	client := NewInfluxDBClient("http://localhost:8086", "my-token", "my-org", "my-bucket")
	err := client.DeleteBucket(context.Background(), "test_bucket")
	assert.Nil(t, err)
}

func TestChangeRetentionPolicy(t *testing.T) {
	client := NewInfluxDBClient("http://localhost:8086", "my-token", "my-org", "test_bucket")
	updatedBucket, err := client.ChangeRetentionPolicy(context.Background(), "test_bucket", "30d")
	assert.Nil(t, err)
	assert.NotNil(t, updatedBucket)
}

func TestGetMeasurements(t *testing.T) {
	client := NewInfluxDBClient("http://localhost:8086", "my-token", "my-org", "my-bucket")
	measurements, err := client.GetMeasurements(context.Background())
	assert.Nil(t, err)
	assert.NotEmpty(t, measurements)
}

func TestGetMeasurementsWithFilters(t *testing.T) {
	client := NewInfluxDBClient("http://localhost:8086", "my-token", "my-org", "my-bucket")
	filters := map[string]string{"location": "server-room"}
	measurements, err := client.GetMeasurementsWithFilters(context.Background(), filters)
	assert.Nil(t, err)
	assert.NotEmpty(t, measurements)
}
