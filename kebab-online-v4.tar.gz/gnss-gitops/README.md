# gnss-gitops

GitOps repository for the GNSS Ground Segment platform.
Managed by FluxCD v2.8 with OCI chart sources from GitLab Container Registry.

## Clusters

| Cluster   | Distribution    | Domain                    |
|-----------|-----------------|---------------------------|
| dev       | OVH Managed K8s | dev.svc.example.com       |
| staging   | RKE2 bare-metal | staging.svc.example.com   |
| remote    | K3s edge        | remote.svc.example.com    |

## Quick start

### Prerequisites

Install the following tools before bootstrapping:

- flux >= 2.8.0
- kubectl
- helm >= 3.15
- kustomize >= 5.4
- age and age-keygen
- sops >= 3.8

### 1. Generate SOPS keys

```bash
./bootstrap/bootstrap-sops.sh
```

Follow the printed instructions to update .sops.yaml with real public keys.
Store private keys as GitLab CI variables: AGE_KEY_DEV, AGE_KEY_STAGING, AGE_KEY_REMOTE.

### 2. Generate encrypted cluster secrets

```bash
./bootstrap/gen-cluster-secret.sh dev
./bootstrap/gen-cluster-secret.sh staging
./bootstrap/gen-cluster-secret.sh remote
```

### 3. Bootstrap Flux

```bash
export KUBECONFIG=~/.kube/dev-cluster.yaml
./bootstrap/bootstrap-flux.sh dev <gitlab-personal-access-token>
```

### 4. Watch reconciliation

```bash
flux get all -A --watch
```

## Repository structure

```
clusters/           Flux entrypoints, one directory per cluster
  dev/
  staging/
  remote/

infrastructure/
  controllers/      Operator HelmReleases (cert-manager, traefik, ECK, etc.)
  configs/          Operator CRD instances (OpenSearch, CNPG, RabbitMQ, etc.)
  observability/    kube-prometheus-stack, Tempo, Jaeger, logging flows, dashboards
  overlays/         Per-cluster component selection and resource patches

apps/
  base/spa          Demo SPA showing the deployment pattern
  overlays/         Per-cluster image tag and replica patches

testing/
  base/             Microcks, k6 operator, kube-burner, grpcui
  overlays/         dev gets full stack, staging gets k6 + kube-burner only

monitoring-demo/    Dummy frontend in the monitoring namespace
  base/
  overlays/

networking/
  gateways/         Shared Gateway and wildcard certificate
  httproutes/       Per-cluster HTTPRoutes for infrastructure services

policies/kyverno/   ClusterPolicy manifests
bootstrap/          Bootstrap shell scripts
docs/               Architecture notes
```

## Application deployment pattern

Microservices live in their own monorepo and ship their own Helm charts as
OCI artifacts. To deploy a new service into this cluster, add a HelmRelease
manifest in a new directory under infrastructure/configs/ or create a
dedicated Flux Kustomization pointing at the monorepo OCI chart.

The spa under apps/base/ demonstrates the minimal pattern:
- Deployment with image tag managed by CI commit-back
- Service
- HTTPRoute using ${cluster_domain} substitution
- Kustomize overlay per cluster for image tag and replica count

## Adding a new cluster

1. Copy clusters/dev/ to clusters/<name>/
2. Update cluster-vars.yaml with the new domain, region, and flags
3. Create infrastructure/overlays/<name>/kustomization.yaml
4. Run ./bootstrap/bootstrap-flux.sh <name> <token>

## CI pipeline stages

| Stage    | Jobs                                                              |
|----------|-------------------------------------------------------------------|
| validate | yaml-lint, kubeconform, helm-lint, flux build, kyverno, sops check |
| publish  | Push OCI bundle to GitLab registry                                |
| update   | Triggered by app pipelines to commit-back image tags              |

## Search backend switching

Set search_backend in clusters/<name>/cluster-vars.yaml to document intent.
To actually switch from OpenSearch to Elasticsearch, edit the resources list
in infrastructure/overlays/<cluster>/kustomization.yaml:
- Comment out opensearch-operator and configs/opensearch
- Uncomment eck-operator and configs/elasticsearch
- Apply the logging clusteroutput patch from configs/elasticsearch/clusteroutput-patch.yaml

See docs/architecture.md for the full procedure.
