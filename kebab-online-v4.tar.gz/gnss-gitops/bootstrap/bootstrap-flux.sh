#!/usr/bin/env bash
# bootstrap-flux.sh -- Bootstrap FluxCD v2.8 on a target cluster
# Usage: ./bootstrap/bootstrap-flux.sh <cluster> <gitlab-token>
# Example: ./bootstrap/bootstrap-flux.sh dev glpat-xxxxxxxxxxxx
set -euo pipefail

CLUSTER=${1:?Usage: $0 <dev|staging|remote> <gitlab-token>}
GITLAB_TOKEN=${2:?Usage: $0 <cluster> <gitlab-token>}

GITLAB_HOST="gitlab.com"
GITLAB_USER="your-org"
GITLAB_REPO="gnss-gitops"
FLUX_VERSION="2.8.0"

echo "==> Bootstrapping FluxCD ${FLUX_VERSION} on cluster: ${CLUSTER}"

# 1. Check prerequisites
for bin in flux kubectl age sops; do
  command -v "$bin" >/dev/null 2>&1 || { echo "ERROR: $bin not found in PATH"; exit 1; }
done

# 2. Create flux-system namespace
kubectl create namespace flux-system --dry-run=client -o yaml | kubectl apply -f -

# 3. Load AGE key for SOPS (stored as GitLab CI variable AGE_KEY_<CLUSTER>)
AGE_KEY_VAR="AGE_KEY_$(echo ${CLUSTER} | tr '[:lower:]' '[:upper:]')"
AGE_KEY="${!AGE_KEY_VAR:-}"
if [[ -z "$AGE_KEY" ]]; then
  echo "WARNING: ${AGE_KEY_VAR} not set -- you must create the SOPS secret manually"
  echo "  kubectl create secret generic sops-age -n flux-system --from-literal=age.agekey=<KEY>"
else
  kubectl create secret generic sops-age \
    --namespace=flux-system \
    --from-literal=age.agekey="${AGE_KEY}" \
    --dry-run=client -o yaml | kubectl apply -f -
  echo "==> SOPS age key applied"
fi

# 4. Create GitLab registry pull secret
kubectl create secret docker-registry gitlab-registry-creds \
  --namespace=flux-system \
  --docker-server="registry.gitlab.com" \
  --docker-username="gitlab-ci-token" \
  --docker-password="${GITLAB_TOKEN}" \
  --dry-run=client -o yaml | kubectl apply -f -

# 5. Bootstrap Flux from GitLab
flux bootstrap gitlab \
  --version="${FLUX_VERSION}" \
  --hostname="${GITLAB_HOST}" \
  --owner="${GITLAB_USER}" \
  --repository="${GITLAB_REPO}" \
  --branch=main \
  --path="clusters/${CLUSTER}" \
  --token-auth \
  --deploy-token-auth=false \
  --personal=false

echo "==> FluxCD bootstrapped for cluster: ${CLUSTER}"
echo "==> Monitor reconciliation: flux get all -A --watch"
