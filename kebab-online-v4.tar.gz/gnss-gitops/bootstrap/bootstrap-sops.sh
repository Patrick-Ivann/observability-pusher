#!/usr/bin/env bash
# bootstrap-sops.sh -- Generate AGE keypairs for each cluster and print public keys
# Usage: ./bootstrap/bootstrap-sops.sh
# Store the private keys as GitLab CI variables: AGE_KEY_DEV, AGE_KEY_STAGING, AGE_KEY_REMOTE
set -euo pipefail

command -v age-keygen >/dev/null 2>&1 || { echo "ERROR: age-keygen not found. Install: https://age-encryption.org"; exit 1; }

for cluster in dev staging remote; do
  echo ""
  echo "==> Generating AGE keypair for cluster: ${cluster}"
  KEYFILE="/tmp/age-${cluster}.key"
  age-keygen -o "${KEYFILE}" 2>/dev/null
  PUBKEY=$(age-keygen -y "${KEYFILE}")
  echo "    Public key:  ${PUBKEY}"
  echo "    Private key: ${KEYFILE}"
  echo ""
  echo "    ACTION REQUIRED:"
  echo "    1. Add private key to GitLab CI variable: AGE_KEY_$(echo $cluster | tr '[:lower:]' '[:upper:]')"
  echo "    2. Update .sops.yaml -- replace placeholder age1${cluster}... with:"
  echo "       ${PUBKEY}"
  echo ""
done

echo "==> After updating .sops.yaml, encrypt secrets with:"
echo "    sops -e -i infrastructure/configs/opensearch/secret-admin-creds.yaml"
