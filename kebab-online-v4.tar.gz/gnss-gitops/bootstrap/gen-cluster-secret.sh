#!/usr/bin/env bash
# gen-cluster-secret.sh -- Create a SOPS-encrypted cluster-secrets Secret
# Contains sensitive values referenced by Flux postBuild.substituteFrom
# Usage: ./bootstrap/gen-cluster-secret.sh <cluster>
set -euo pipefail

CLUSTER=${1:?Usage: $0 <dev|staging|remote>}

cat > "/tmp/cluster-secrets-${CLUSTER}.yaml" << YAML
---
apiVersion: v1
kind: Secret
metadata:
  name: cluster-secrets
  namespace: flux-system
stringData:
  grafana_admin_password: "CHANGE_ME"
  opensearch_admin_password: "CHANGE_ME"
  influxdb_admin_token: "CHANGE_ME"
  pg_password: "CHANGE_ME"
YAML

echo "==> Encrypting with SOPS for cluster: ${CLUSTER}"
sops --config .sops.yaml -e "/tmp/cluster-secrets-${CLUSTER}.yaml" \
  > "clusters/${CLUSTER}/cluster-secrets.sops.yaml"

echo "==> Encrypted secret written to: clusters/${CLUSTER}/cluster-secrets.sops.yaml"
echo "==> Add to clusters/${CLUSTER}/flux-system.yaml resources list"
rm "/tmp/cluster-secrets-${CLUSTER}.yaml"
