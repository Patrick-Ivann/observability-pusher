# GNSS Ground Segment - Architecture

## Cluster topology

| Cluster  | Distribution    | CNI    | Role                       | Multus |
|----------|-----------------|--------|----------------------------|--------|
| dev      | OVH Managed K8s | CANAL  | Development, integration   | no     |
| staging  | RKE2 bare-metal | Cilium | Pre-production, HW-in-loop | yes    |
| remote   | K3s edge        | Cilium | Field deployment stub      | yes    |

---

## Flux reconciliation graph

Flux reconciles resources in dependency order. Each Kustomization waits for
its upstream dependency to reach a Ready state before proceeding.

```mermaid
graph TD
    A[flux-system OCIRepository] --> B[infrastructure-controllers<br/>wait: true]
    B --> C[infrastructure-observability]
    B --> D[apps]
    B --> E[testing]
    D --> F[networking]
```

---

## Full stack overview

```mermaid
graph TB
    subgraph internet["External access"]
        user[Browser / client]
    end

    subgraph gateway["traefik-system"]
        gw[Traefik Gateway API]
    end

    subgraph gnss["gnss namespace"]
        spa[SPA demo]
    end

    subgraph obs["monitoring namespace"]
        grafana[Grafana]
        jaeger[Jaeger]
        prom[Prometheus]
        tempo[Tempo]
        headlamp[Headlamp]
    end

    subgraph data["data namespaces"]
        os[OpenSearch]
        influx[InfluxDB]
        pg[PostgreSQL]
        rmq[RabbitMQ]
        redis[Redis]
    end

    subgraph logging["logging namespace"]
        fb[Fluent Bit DS]
        fd[Fluentd aggregator]
    end

    subgraph testing["testing namespace"]
        microcks[Microcks]
        grpcui[grpcui]
        k6[k6 operator]
    end

    user --> gw
    gw --> spa
    gw --> grafana
    gw --> jaeger
    gw --> microcks
    gw --> grpcui
    prom --> influx
    fb --> fd --> os
```

---

## Namespace map

| Namespace      | Contents                                                       |
|----------------|----------------------------------------------------------------|
| flux-system    | Flux controllers, OCIRepository, SOPS age secret              |
| kube-system    | Cilium, Multus, Whereabouts, VPA                               |
| traefik-system | Traefik, Gateway, wildcard TLS certificate                     |
| cert-manager   | cert-manager operator                                          |
| kyverno        | Kyverno admission controller and policies                      |
| monitoring     | kube-prometheus-stack, Grafana, Tempo, Jaeger, Pushgateway, Headlamp, Goldilocks, demo-frontend |
| logging        | logging-operator, Fluent Bit DaemonSet, Fluentd aggregator     |
| opensearch     | OpenSearch cluster and dashboards (operator-managed)           |
| elasticsearch  | ECK Elasticsearch and Kibana (inactive by default)             |
| elastic-system | ECK operator                                                   |
| influxdb       | InfluxDB OSS v2 (operator-managed)                             |
| rabbitmq       | RabbitMQ cluster (operator-managed)                            |
| postgresql     | CloudNativePG cluster                                          |
| redis          | Redis cluster (OT operator)                                    |
| seaweedfs      | SeaweedFS master, volume, filer                                |
| gnss           | Demo SPA and future microservice HelmReleases                  |
| testing        | Microcks, k6 operator, kube-burner, grpcui                     |

---

## SOPS secret management

### Overview

All secrets are encrypted at rest using SOPS (Secrets OPerationS) with Age
as the encryption backend. Age uses X25519 elliptic-curve keys. Flux decrypts
secrets at reconciliation time using a private key stored as a Kubernetes
Secret in the flux-system namespace.

No plaintext secret ever touches the Git repository. The CI pipeline enforces
this with both a YAML inspection job and Gitleaks secret scanning.

### Key lifecycle

```mermaid
sequenceDiagram
    participant dev as Developer
    participant gl as GitLab CI<br/>AGE_KEY_* variable
    participant repo as Git repository
    participant flux as Flux controller
    participant k8s as Kubernetes

    dev->>dev: age-keygen -o cluster.key
    dev->>gl: store private key as AGE_KEY_DEV
    dev->>repo: commit public key to .sops.yaml

    dev->>dev: sops -e -i secret.yaml
    dev->>repo: commit encrypted *.sops.yaml

    flux->>k8s: read sops-age Secret
    flux->>repo: fetch *.sops.yaml
    flux->>flux: decrypt with age private key
    flux->>k8s: apply decrypted Secret
```

### Key generation

Generate one keypair per cluster. Run once and store the private keys securely.

```bash
task bootstrap:sops
# or directly:
age-keygen -o /tmp/age-dev.key
age-keygen -y /tmp/age-dev.key   # prints the public key
```

The public key looks like:

```
age1ql3z7hjy54pw3hyww5ayyfg7zqgvc7w3j2elw8zmrj2kg5sfn9aqmcac8p
```

Put this in `.sops.yaml` under the correct `creation_rules` entry. Store the
private key content (the entire file including the `AGE-SECRET-KEY-` line)
as a GitLab CI variable named `AGE_KEY_DEV`.

The bootstrap script reads this variable and creates the `sops-age` Secret
before Flux starts its first reconciliation.

### Encrypting a new secret

```bash
# Create the plaintext file. Do not commit this file.
cat > /tmp/my-secret.yaml << EOF
apiVersion: v1
kind: Secret
metadata:
  name: my-secret
  namespace: gnss
stringData:
  api-key: "my-plaintext-value"
EOF

# Encrypt in-place. SOPS reads .sops.yaml to select the right key.
task sops:encrypt FILE=/tmp/my-secret.yaml

# Move to the repo and commit.
cp /tmp/my-secret.yaml clusters/dev/my-secret.sops.yaml
git add clusters/dev/my-secret.sops.yaml
git commit -m "feat: add my-secret for dev cluster"
```

### Decrypting for inspection

```bash
# Decrypt to stdout only. Do not redirect to a file inside the repo.
task sops:decrypt FILE=clusters/dev/my-secret.sops.yaml

# Open an encrypted file in your editor. SOPS re-encrypts on save.
task sops:edit FILE=clusters/dev/my-secret.sops.yaml
```

### Connecting an encrypted file to Flux

After committing the encrypted file, add it to the cluster entrypoint
kustomization and declare decryption on the Kustomization that consumes it.

```yaml
# clusters/dev/flux-system.yaml  (kustomize resources list)
resources:
  - my-secret.sops.yaml

# The Flux Kustomization that deploys the workload using this secret:
spec:
  decryption:
    provider: sops
    secretRef:
      name: sops-age
```

### What a correctly encrypted file looks like

The `stringData` values are replaced with AES256-GCM ciphertext. Kubernetes
metadata stays in plaintext so Flux can identify the resource.

```yaml
apiVersion: v1
kind: Secret
metadata:
    name: cluster-secrets
    namespace: flux-system
sops:
    age:
        - recipient: age1ql3z7hjy54pw3...
          enc: |
            -----BEGIN AGE ENCRYPTED FILE-----
            ...
            -----END AGE ENCRYPTED FILE-----
    lastmodified: "2024-01-15T10:00:00Z"
    version: 3.8.1
stringData:
    grafana_admin_password: ENC[AES256_GCM,data:abc123...,tag:xyz...]
    opensearch_admin_password: ENC[AES256_GCM,data:def456...,tag:uvw...]
```

### Key rotation

Run this when a team member leaves or a key is suspected to be compromised.

```bash
# 1. Generate a new keypair.
age-keygen -o /tmp/age-dev-new.key

# 2. Add the new public key to .sops.yaml alongside the old one (both keys
#    can decrypt during transition).

# 3. Re-encrypt all SOPS files to add the new recipient.
task sops:rotate

# 4. Update the GitLab CI variable AGE_KEY_DEV with the new private key.

# 5. Update the sops-age Secret in the running cluster.
kubectl create secret generic sops-age \
  --namespace=flux-system \
  --from-literal=age.agekey="$(cat /tmp/age-dev-new.key)" \
  --dry-run=client -o yaml | kubectl apply -f -

# 6. Remove the old public key from .sops.yaml, then rotate again to
#    drop the old recipient from all encrypted files.
task sops:rotate

# 7. Commit and push.
git add .sops.yaml clusters/
git commit -m "security: rotate AGE key for dev cluster"
```

---

## HTTPRoute hostname convention

Pattern: `<service>.<cluster_prefix>.svc.example.com`

The `${cluster_domain}` placeholder in HTTPRoute manifests is substituted at
reconciliation time by Flux using `postBuild.substituteFrom` referencing the
`cluster-vars` ConfigMap in flux-system.

| Service                | Dev URL                                        |
|------------------------|------------------------------------------------|
| SPA                    | spa.dev.svc.example.com                        |
| Grafana                | grafana.dev.svc.example.com                    |
| Jaeger                 | jaeger.dev.svc.example.com                     |
| OpenSearch Dashboards  | gnss-opensearch-dashboards.dev.svc.example.com |
| Traefik Dashboard      | traefik.dev.svc.example.com                    |
| Demo frontend          | demo.dev.svc.example.com                       |
| Microcks               | microcks.dev.svc.example.com                   |
| Microcks gRPC          | microcks-grpc.dev.svc.example.com              |
| grpcui                 | grpcui.dev.svc.example.com                     |
| Headlamp               | headlamp.dev.svc.example.com                   |
| Goldilocks             | goldilocks.dev.svc.example.com                 |

---

## Logging pipeline

```mermaid
flowchart LR
    pods[Pod stdout/stderr] --> fb[Fluent Bit DaemonSet]
    fb -->|label: part-of=gnss| fd[Fluentd aggregator]
    fb -->|all other logs| fd
    fd -->|gnss events| os1[(OpenSearch<br/>gnss-events-*)]
    fd -->|app logs| os2[(OpenSearch<br/>app-logs-*)]

    subgraph edge["K3s remote"]
        fb2[Fluent Bit<br/>no aggregator] -->|direct| os3[(OpenSearch<br/>core cluster)]
    end
```

---

## Search backend switching

To swap from OpenSearch to Elasticsearch, edit the resources list in
`infrastructure/overlays/<cluster>/kustomization.yaml`:

```mermaid
flowchart LR
    A[Comment out opensearch-operator<br/>and configs/opensearch] --> B[Uncomment eck-operator<br/>and configs/elasticsearch]
    B --> C[Add clusteroutput-patch from<br/>configs/elasticsearch/]
    C --> D[Update Jaeger storage.type<br/>in HelmRelease values]
    D --> E[git commit and push]
    E --> F[Flux reconciles the swap]
```

Both operators can coexist during migration. The `ClusterOutput` resource is
named `opensearch-output` regardless of backend so `ClusterFlow` references
never need updating.

---

## CI/CD pipeline

```mermaid
flowchart LR
    subgraph validate["validate"]
        v1[yaml-lint]
        v2[kubeconform]
        v3[helm-lint]
        v4[flux-build]
        v5[kyverno]
        v6[sops-check]
    end

    subgraph security["security"]
        s1[gitleaks]
        s2[GitLab secret detection]
        s3[trivy misconfig]
        s4[trivy SBOM]
    end

    subgraph publish["publish"]
        p1[flux push OCI bundle]
    end

    subgraph update["update"]
        u1[commit-back image tag]
    end

    validate --> security --> publish
```

### Secret detection

Two independent tools scan for committed secrets:

Gitleaks scans the full git history on every MR and push to main. It covers
150+ secret patterns by default. The `.gitleaks.toml` file at the repo root
adds project-specific rules (OVH API keys, InfluxDB tokens) and allowlists
placeholder values that would otherwise trigger false positives.

The GitLab native secret detection template runs as a second opinion using
a different ruleset. Findings surface in the MR security widget.

### SBOM generation

Trivy generates a CycloneDX SBOM for every container image referenced in the
dev overlay and for the repo filesystem (Go modules, Python packages, NPM
dependencies). SBOMs are archived as job artifacts for 90 days and can be
uploaded to a Dependency Track instance for supply-chain tracking.

### Misconfig scanning

Trivy config scans rendered Kubernetes manifests for CIS Benchmark violations,
insecure pod specs, and RBAC issues. HIGH and CRITICAL findings on application
manifests fail the pipeline. Infrastructure manifests produce a SARIF report
that surfaces inline in the MR diff view.

---

## Resource sizing

### Dev and remote (lightweight)

| Service    | Replicas | Storage | Memory limit          |
|------------|----------|---------|-----------------------|
| OpenSearch | 1        | 10 Gi   | 1 Gi                  |
| PostgreSQL | 1        | 5 Gi    | default               |
| RabbitMQ   | 1        | 5 Gi    | 512 Mi                |
| Redis      | 1 shard  | 1 Gi    | 128 Mi                |
| InfluxDB   | 1        | 10 Gi   | 512 Mi                |
| Prometheus | 1        | 5 Gi    | 512 Mi, 3d retention  |

### Staging (moderate)

| Service    | Replicas | Storage | Memory limit            |
|------------|----------|---------|-------------------------|
| OpenSearch | 2        | 30 Gi   | 2 Gi                    |
| PostgreSQL | 3        | 20 Gi   | default                 |
| RabbitMQ   | 3        | 20 Gi   | 2 Gi                    |
| Redis      | 3 shards | 5 Gi    | 512 Mi                  |
| InfluxDB   | 1        | 50 Gi   | 2 Gi                    |
| Prometheus | 1        | 50 Gi   | default, 10d retention  |

---

## Uninstall procedures

All uninstall operations are available via Taskfile and include interactive
confirmation prompts to prevent accidents. The procedures below show what
each task does so you can run steps manually if needed.

### Remove application workloads only

Keeps all infrastructure running. Safe to re-deploy afterwards.

```bash
task uninstall:apps
# manually:
flux suspend kustomization apps
kubectl delete namespace gnss --ignore-not-found
# re-enable later:
flux resume kustomization apps
```

### Remove testing tooling

```bash
task uninstall:testing
# manually:
flux suspend kustomization testing
kubectl delete namespace testing --ignore-not-found
```

### Remove the observability stack

Deletes all metrics history and log data in the monitoring and logging
namespaces. Export dashboards from Grafana first if needed.

```bash
task uninstall:observability
# manually:
flux suspend kustomization infrastructure-observability
kubectl delete namespace monitoring --ignore-not-found
kubectl delete namespace logging --ignore-not-found
```

### Remove stateful data services

This is destructive and irreversible for data not backed up elsewhere.
Check for remaining PVCs after deletion.

```bash
task uninstall:data
# manually:
for ns in opensearch postgresql rabbitmq redis influxdb seaweedfs elasticsearch; do
  kubectl delete namespace $ns --ignore-not-found
done
kubectl get pvc -A   # check for orphaned PVCs
```

### Remove Flux but keep deployed resources

Useful when migrating to a different GitOps tool or re-bootstrapping.
All resources that Flux deployed continue running.

```bash
task uninstall:flux
# manually:
flux uninstall --keep-namespace --silent
```

### Full cluster teardown

```mermaid
flowchart TD
    A[uninstall:apps] --> B[uninstall:testing]
    B --> C[uninstall:observability]
    C --> D[uninstall:data]
    D --> E[delete traefik-system]
    E --> F[delete cert-manager]
    F --> G[delete kyverno + elastic-system]
    G --> H[flux uninstall]
    H --> I[cluster is clean]
```

```bash
task uninstall:full
```

The Kubernetes cluster itself is not deleted. After a full teardown, to
re-bootstrap from scratch:

```bash
task bootstrap:sops          # only needed if keys were lost
task bootstrap:secrets       # re-generate encrypted secrets
task bootstrap:cluster CLUSTER=dev GITLAB_TOKEN=<token>
```

---

## Testing stack

| Tool        | Namespace | URL (dev)                    | Purpose                    |
|-------------|-----------|------------------------------|----------------------------|
| Microcks    | testing   | microcks.dev.svc.example.com | API mocking, REST and gRPC |
| grpcui      | testing   | grpcui.dev.svc.example.com   | Browser gRPC exploration   |
| grpc_cli    | testing   | Job, run manually            | CLI service reflection     |
| k6 operator | testing   | results in Grafana           | HTTP and gRPC load testing |
| kube-burner | testing   | Job, run manually            | Cluster stress testing     |

To switch the grpcui target at runtime:

```bash
kubectl set env deployment/grpcui -n testing \
  GRPC_TARGET=gnss-receiver.gnss.svc.cluster.local:50051
```

---

## Extra observability tools

| Tool       | URL (dev)                       | Purpose                             |
|------------|---------------------------------|-------------------------------------|
| Headlamp   | headlamp.dev.svc.example.com    | Lightweight read-only Kubernetes UI |
| Goldilocks | goldilocks.dev.svc.example.com  | VPA-based right-sizing dashboard    |
| Kepler     | metrics only, Grafana dashboard | Pod-level energy and carbon metrics |
