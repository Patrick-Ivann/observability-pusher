# Search Backend Switch

This directory provides two Kustomize **Components** that act as a
drop-in swap between OpenSearch and Elasticsearch.

## How to switch

In your cluster overlay (`infrastructure/overlays/<cluster>/kustomization.yaml`),
use exactly **one** of these components:

```yaml
# OpenSearch (default)
components:
  - ../../configs/search-backend/opensearch

# Elasticsearch (ECK)
components:
  - ../../configs/search-backend/elasticsearch
```

The component patches:
1. The `ClusterOutput` for the logging operator -> new host/credentials
2. The `Jaeger` HelmRelease storage backend
3. Adds/removes the operator and cluster CRDs accordingly

Grafana datasources are controlled separately via the
`search_backend` variable in `cluster-vars.yaml` (value: `opensearch` or `elasticsearch`).
