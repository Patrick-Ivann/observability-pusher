# gRPC Collections

Use grpcui (deployed in the `testing` namespace) or grpc_cli locally.

## grpc_cli quick reference

```bash
# List services (requires server reflection)
grpc_cli ls grpc-api.dev.svc.example.com

# Describe a service
grpc_cli type grpc-api.dev.svc.example.com gnss.v1.FixService

# Call a method
grpc_cli call grpc-api.dev.svc.example.com gnss.v1.FixService.GetLatestFix \
  "request_id: 'test-001'"

# Streaming call
grpc_cli call --noremotedb grpc-api.dev.svc.example.com \
  gnss.v1.FixService.StreamFixes ""
```

## grpcui access

Available at: https://grpcui.dev.svc.example.com
Connects to gnss-api:9090 by default.
To change target, redeploy with different `-service` arg or patch the Deployment.
