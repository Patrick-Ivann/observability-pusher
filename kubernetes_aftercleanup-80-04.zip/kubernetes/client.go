package kubernetes

import (
	"context"
	"fmt"

	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/client-go/kubernetes"
)

// K8sClient defines a high-level abstraction for Kubernetes interactions.
type K8sClient interface {
	GetPodNameByLabel(namespace, labelSelector string) (string, error)
}

// RealK8sClient implements actual Kubernetes calls using `kubernetes.Interface`.
type RealK8sClient struct {
	Clientset kubernetes.Interface
}

// GetPodNameByLabel retrieves the first pod matching a label selector.
func (k *RealK8sClient) GetPodNameByLabel(namespace, labelSelector string) (string, error) {
	pods, err := k.Clientset.CoreV1().Pods(namespace).List(context.Background(), metav1.ListOptions{
		LabelSelector: labelSelector,
	})
	if err != nil || len(pods.Items) == 0 {
		return "", fmt.Errorf("failed to find pod: %w", err)
	}
	return pods.Items[0].Name, nil
}
