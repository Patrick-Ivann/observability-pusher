package kubernetes_test

import (
	"context"
	"errors"
	"testing"

	"github.com/Patrick-Ivann/go-microservice-playground/pkg/kubernetes"
	"github.com/stretchr/testify/assert"
	v1 "k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	properKubernetes "k8s.io/client-go/kubernetes"
	"k8s.io/client-go/kubernetes/fake"
)

// MockK8sClient is a mock implementation of K8sClient
type MockK8sClient struct {
	Clientset *properKubernetes.Clientset
}

// GetPodNameByLabel retrieves the first pod matching a label selector (mocked)
func (m *MockK8sClient) GetPodNameByLabel(namespace, labelSelector string) (string, error) {
	pods, err := m.Clientset.CoreV1().Pods(namespace).List(context.Background(), metav1.ListOptions{
		LabelSelector: labelSelector,
	})
	if err != nil || len(pods.Items) == 0 {
		return "", errors.New("no pod found")
	}
	return pods.Items[0].Name, nil
}

// Test successful retrieval of a pod name
func TestGetPodNameByLabel_Success(t *testing.T) {
	clientset := fake.NewSimpleClientset()

	// Create mock pod with matching label
	_, err := clientset.CoreV1().Pods("default").Create(context.Background(), &v1.Pod{
		ObjectMeta: metav1.ObjectMeta{
			Name:   "mock-pod",
			Labels: map[string]string{"app": "test"},
		},
	}, metav1.CreateOptions{})
	assert.Nil(t, err)

	k8sClient := &kubernetes.RealK8sClient{Clientset: clientset}
	podName, err := k8sClient.GetPodNameByLabel("default", "app=test")

	assert.Nil(t, err)
	assert.Equal(t, "mock-pod", podName)
}

// Test case when no pod matches the label
func TestGetPodNameByLabel_NoMatchingPod(t *testing.T) {
	clientset := fake.NewSimpleClientset() // No pods exist

	k8sClient := &kubernetes.RealK8sClient{Clientset: clientset}
	podName, err := k8sClient.GetPodNameByLabel("default", "app=nonexistent")

	assert.NotNil(t, err)
	assert.Empty(t, podName)
}
