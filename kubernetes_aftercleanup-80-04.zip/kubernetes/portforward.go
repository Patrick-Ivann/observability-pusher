// package kubernetes

// import (
// 	"fmt"
// 	"net/http"
// 	"os"

// 	"k8s.io/client-go/rest"
// 	"k8s.io/client-go/tools/portforward"
// 	"k8s.io/client-go/transport/spdy"
// )

// // SPDYManager defines an abstraction over SPDY connection setup.
// type SPDYManager interface {
// 	CreateRoundTripper() (http.RoundTripper, spdy.Upgrader, error)
// }

// // RealSPDYManager implements actual SPDY communication.
// type RealSPDYManager struct {
// 	Config *rest.Config
// }

// // CreateRoundTripper initializes transport and upgrader.
// func (s *RealSPDYManager) CreateRoundTripper() (http.RoundTripper, spdy.Upgrader, error) {
// 	return spdy.RoundTripperFor(s.Config)
// }

// // PortForwarder interface abstracts the port-forwarding logic.
// type PortForwarder interface {
// 	Forward(reqURL string, ports []string, stopChan, readyChan chan struct{}) error
// }

// // KubernetesPortForwarder handles real Kubernetes port forwarding.
// type KubernetesPortForwarder struct {
// 	SPDY SPDYManager
// }

// // Forward initiates port forwarding using an SPDY transport.
// func (k *KubernetesPortForwarder) Forward(reqURL string, ports []string, stopChan, readyChan chan struct{}) error {
// 	transport, upgrader, err := k.SPDY.CreateRoundTripper()
// 	if err != nil {
// 		return fmt.Errorf("failed to create SPDY round tripper: %w", err)
// 	}

// 	fmt.Printf("transport: %v\n", transport)
// 	fmt.Printf("upgrader: %v\n", upgrader)

// 	fw, err := portforward.New(reqURL, ports, stopChan, readyChan, os.Stdout, os.Stderr)
// 	if err != nil {
// 		return fmt.Errorf("failed to create port forwarder: %w", err)
// 	}

// 	go func() { _ = fw.ForwardPorts() }()
// 	<-readyChan
// 	return nil
// }

// package kubernetes

// import (
// 	"fmt"
// 	"net/http"
// 	"net/url"

// 	httpstream "k8s.io/apimachinery/pkg/util/httpstream"
// 	"k8s.io/client-go/rest"
// 	k8srest "k8s.io/client-go/rest"
// 	"k8s.io/client-go/transport/spdy"
// 	k8sspdy "k8s.io/client-go/transport/spdy"
// )

// // DialerCreator abstracts the creation of SPDY-compatible HTTP stream dialers.
// type DialerCreator interface {
// 	CreateDialer(transport http.RoundTripper, upgrader k8sspdy.Upgrader, reqURL *url.URL) httpstream.Dialer
// }

// // RealDialerCreator implements the actual SPDY-to-HTTP streaming dialer.
// type RealDialerCreator struct{}

// // CreateDialer correctly initializes a `httpstream.Dialer` for SPDY tunneling.
// func (d *RealDialerCreator) CreateDialer(transport http.RoundTripper, upgrader k8sspdy.Upgrader, reqURL *url.URL) httpstream.Dialer {
// 	return k8sspdy.NewDialer(upgrader, &http.Client{Transport: transport}, "POST", reqURL)
// }

// // SPDYRoundTripperProvider abstracts RoundTripperFor.
// type SPDYRoundTripperProvider interface {
// 	GetRoundTripper(config *rest.Config) (http.RoundTripper, spdy.Upgrader, error)
// }

// // Real implementation that calls the actual Kubernetes method.
// type RealSPDYRoundTripperProvider struct{}

// func (r *RealSPDYRoundTripperProvider) GetRoundTripper(config *rest.Config) (http.RoundTripper, spdy.Upgrader, error) {
// 	return spdy.RoundTripperFor(config)
// }

// type RealKubernetesPortForwarder interface {
// 	Forward(reqURL *url.URL, ports []string, stopChan <-chan struct{}, readyChan chan struct{}) error
// }

// type PortForwarder interface {
// 	ForwardPorts() error
// }

// type PortForwarderFactory func(dialer httpstream.Dialer, ports []string, stopChan <-chan struct{}, readyChan chan struct{}) (PortForwarder, error)

// // KubernetesPortForwarder handles Kubernetes port forwarding.
// type KubernetesPortForwarder struct {
// 	Config           *k8srest.Config
// 	DialerCreator    DialerCreator
// 	SPDYProvider     SPDYRoundTripperProvider
// 	ForwarderFactory PortForwarderFactory // Injected function
// }

// // Forward establishes a port-forwarding connection using `httpstream.Dialer`.
// func (k *KubernetesPortForwarder) Forward(reqURL *url.URL, ports []string, stopChan <-chan struct{}, readyChan chan struct{}) error {
// 	transport, upgrader, err := k.SPDYProvider.GetRoundTripper(k.Config)
// 	if err != nil {
// 		return fmt.Errorf("failed to create SPDY round tripper: %w", err)
// 	}

// 	dialer := k.DialerCreator.CreateDialer(transport, upgrader, reqURL) // Uses injected dialer creator.

// 	fw, err := k.ForwarderFactory(dialer, ports, stopChan, readyChan) //injected method instead of concrete call
// 	if err != nil {
// 		fmt.Printf("PortForward creation error: %v\n", err)
// 		return fmt.Errorf("failed to create port forwarder: %w", err)
// 	}

// 	if fw == nil {
// 		return fmt.Errorf("port forwarder is unexpectedly nil")
// 	}

// 	go func() {
// 		if err := fw.ForwardPorts(); err != nil {
// 			fmt.Printf("Error forwarding ports: %v\n", err)
// 		}
// 	}()
// 	<-readyChan
// 	return nil
// }

package kubernetes

import (
	"fmt"
	"net/http"
	"net/url"

	httpstream "k8s.io/apimachinery/pkg/util/httpstream"
	"k8s.io/client-go/rest"
	"k8s.io/client-go/transport/spdy"
)

// DialerCreator defines an interface for creating SPDY-compatible HTTP stream dialers.
type DialerCreator interface {
	CreateDialer(transport http.RoundTripper, upgrader spdy.Upgrader, reqURL *url.URL) httpstream.Dialer
}

// RealDialerCreator provides an implementation for creating SPDY dialers.
type RealDialerCreator struct{}

// CreateDialer initializes a `httpstream.Dialer` to establish SPDY tunnel communication.
func (d *RealDialerCreator) CreateDialer(transport http.RoundTripper, upgrader spdy.Upgrader, reqURL *url.URL) httpstream.Dialer {
	return spdy.NewDialer(upgrader, &http.Client{Transport: transport}, http.MethodPost, reqURL)
}

// SPDYRoundTripperProvider abstracts the retrieval of SPDY-compatible `RoundTripper`.
type SPDYRoundTripperProvider interface {
	GetRoundTripper(config *rest.Config) (http.RoundTripper, spdy.Upgrader, error)
}

// RealSPDYRoundTripperProvider implements the Kubernetes method for obtaining SPDY transport.
type RealSPDYRoundTripperProvider struct{}

// GetRoundTripper retrieves a SPDY-compatible `RoundTripper` for Kubernetes port-forwarding.
func (r *RealSPDYRoundTripperProvider) GetRoundTripper(config *rest.Config) (http.RoundTripper, spdy.Upgrader, error) {
	return spdy.RoundTripperFor(config)
}

type RealKubernetesPortForwarder interface {
	Forward(reqURL *url.URL, ports []string, stopChan <-chan struct{}, readyChan chan struct{}) error
}

// PortForwarder defines an interface for managing port forwarding operations.
type PortForwarder interface {
	ForwardPorts() error
}

// PortForwarderFactory is a function type used to create port-forwarding instances dynamically.
type PortForwarderFactory func(dialer httpstream.Dialer, ports []string, stopChan <-chan struct{}, readyChan chan struct{}) (PortForwarder, error)

// KubernetesPortForwarder manages Kubernetes port forwarding through SPDY tunnels.
type KubernetesPortForwarder struct {
	Config           *rest.Config
	DialerCreator    DialerCreator
	SPDYProvider     SPDYRoundTripperProvider
	ForwarderFactory PortForwarderFactory // Factory method to enable testability.
}

// Forward establishes a port-forwarding connection using SPDY and an HTTP dialer.
func (k *KubernetesPortForwarder) Forward(reqURL *url.URL, ports []string, stopChan <-chan struct{}, readyChan chan struct{}) error {
	// Retrieve SPDY transport components.
	transport, upgrader, err := k.SPDYProvider.GetRoundTripper(k.Config)
	if err != nil {
		return fmt.Errorf("failed to create SPDY round tripper: %w", err)
	}

	// Initialize a dialer for communication with the Kubernetes API server.
	dialer := k.DialerCreator.CreateDialer(transport, upgrader, reqURL)

	// Use the injected factory method to create a port-forwarding instance.
	fw, err := k.ForwarderFactory(dialer, ports, stopChan, readyChan)
	if err != nil {
		return fmt.Errorf("failed to create port forwarder: %w", err)
	}

	// Ensure the forwarder instance is valid.
	if fw == nil {
		return fmt.Errorf("port forwarder is unexpectedly nil")
	}

	// Launch the port-forwarding process asynchronously.
	go func() {
		if fwErr := fw.ForwardPorts(); fwErr != nil {
			fmt.Printf("Error forwarding ports: %v\n", fwErr)
		}
	}()

	// Wait for readiness confirmation.
	<-readyChan
	return nil
}
