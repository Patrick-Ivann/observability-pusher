package kubernetes

import (
	"fmt"

	"k8s.io/client-go/rest"
)

// PortForwardExecutor abstracts port forwarding and execution logic.
type PortForwardExecutor interface {
	// Execute synchronously triggers port forwarding and calls the callback function once ready.
	Execute(
		config *rest.Config,
		restClient RESTClientInterface,
		portForwarder RealKubernetesPortForwarder,
		podName string,
		namespace string,
		ports []string,
		callback func() interface{},
	) (interface{}, error)

	// ExecuteAsync forwards ports while sending callback results via a channel.
	ExecuteAsync(
		config *rest.Config,
		restClient RESTClientInterface,
		portForwarder RealKubernetesPortForwarder,
		podName string,
		namespace string,
		ports []string,
		callback func() interface{},
		resultsChan chan interface{}, // Channel for sending async values
	) error
}

// RESTClientInterface provides an abstraction for Kubernetes REST interactions.
// This allows mocking and testing without relying on a real Kubernetes API client.
type RESTClientInterface interface {
	PostRequest(namespace, podName string) *rest.Request
}

// RealRESTClient implements actual REST requests using the Kubernetes client.
type RealRESTClient struct {
	Client rest.Interface // Injected Kubernetes REST client interface
}

// PostRequest creates a Kubernetes REST request for initiating port forwarding.
// The request targets a specific pod within a given namespace.
func (r *RealRESTClient) PostRequest(namespace, podName string) *rest.Request {
	return r.Client.Post().
		Resource("pods").
		Namespace(namespace).
		Name(podName).
		SubResource("portforward")
}

// DefaultPortForwardExecutor provides a concrete implementation for port forwarding.
type DefaultPortForwardExecutor struct{}

// PortForwardAndExecute establishes a port-forwarding session and executes a callback once ready.
// It abstracts Kubernetes port-forwarding logic while allowing execution of additional commands.
func (e *DefaultPortForwardExecutor) PortForwardAndExecute(
	config *rest.Config, // Kubernetes cluster configuration
	restClient RESTClientInterface, // REST client for issuing requests
	portForwarder RealKubernetesPortForwarder, // Port-forwarding implementation
	podName string, // Name of the target pod
	namespace string, // Namespace where the pod resides
	ports []string, // Ports to forward (e.g., "9091:9091")
	callback func() interface{}, // Optional callback function to execute upon readiness
) (interface{}, error) {
	// Generate a Kubernetes request for port forwarding
	req := restClient.PostRequest(namespace, podName)

	// Create signaling channels for stopping and readiness notification
	stopChan := make(chan struct{}, 1)
	readyChan := make(chan struct{}, 1)
	defer close(stopChan) // Ensure stopChan is properly closed

	// Initiate port forwarding and wait for readiness
	err := portForwarder.Forward(req.URL(), ports, stopChan, readyChan)
	if err != nil {
		return nil, fmt.Errorf("port forwarding failed: %w", err)
	}

	// Execute the provided callback function if present
	if callback != nil {
		return callback(), nil
	}
	return nil, nil
}

// ExecuteAsync performs port forwarding while asynchronously sending callback results to a channel.
func (e *DefaultPortForwardExecutor) ExecuteAsync(
	config *rest.Config,
	restClient RESTClientInterface,
	portForwarder RealKubernetesPortForwarder,
	podName string,
	namespace string,
	ports []string,
	callback func() interface{},
	resultsChan chan interface{}, // Sends async results
) error {
	req := restClient.PostRequest(namespace, podName)

	stopChan := make(chan struct{}, 1)
	readyChan := make(chan struct{}, 1)
	defer close(stopChan)

	// Start port forwarding
	err := portForwarder.Forward(req.URL(), ports, stopChan, readyChan)
	if err != nil {
		return fmt.Errorf("port forwarding failed: %w", err)
	}

	// Continuously send callback results via the channel
	go func() {
		for {
			select {
			case <-readyChan:
				if callback != nil {
					resultsChan <- callback()
				}
			case <-stopChan: // Stop processing when channel is closed
				close(resultsChan)
				return
			}
		}
	}()

	return nil
}
