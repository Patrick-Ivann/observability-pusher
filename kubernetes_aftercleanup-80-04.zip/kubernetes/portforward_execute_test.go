package kubernetes_test

import (
	"errors"
	"net/url"
	"testing"
	"time"

	"github.com/Patrick-Ivann/go-microservice-playground/pkg/kubernetes"
	"github.com/stretchr/testify/assert"
	httpstream "k8s.io/apimachinery/pkg/util/httpstream"
	"k8s.io/client-go/rest"
)

// MockRESTClient provides a fake implementation of RESTClientInterface.
// This allows controlled testing of Kubernetes REST requests.
type MockRESTClient struct {
	Client *rest.RESTClient // Stores a real or fake REST client.
}

// PostRequest simulates the creation of a REST request for testing purposes.
// If no Client is initialized, it sets up a dummy REST client.
func (m *MockRESTClient) PostRequest(namespace, podName string) *rest.Request {
	if m.Client == nil {
		m.Client = &rest.RESTClient{} // Ensures a valid REST client exists.
	}

	return rest.NewRequest(m.Client).
		Verb("POST").
		Resource("pods").
		Namespace(namespace).
		Name(podName).
		SubResource("portforward")
}

// MockPortForwarder provides a mock implementation of Kubernetes port forwarding.
type MockPortForwarder struct{}

// Forward simulates successful port forwarding by sending readiness signals after a delay.
func (m *MockPortForwarder) Forward(reqURL *url.URL, ports []string, stopChan <-chan struct{}, readyChan chan struct{}) error {
	go func() {
		time.Sleep(10 * time.Millisecond) // Simulates async behavior.
		readyChan <- struct{}{}           // Prevents `<-readyChan` from blocking indefinitely.
	}()
	return nil
}

// mockCallback simulates a successful callback function execution.
func mockCallback() interface{} {
	return "Callback executed successfully"
}

// mockCallbackError simulates an error response from a callback function.
func mockCallbackError() interface{} {
	return errors.New("Callback error")
}

// TestPortForwardAndExecute_Success verifies port forwarding with a valid callback.
func TestPortForwardAndExecute_Success(t *testing.T) {
	mockREST := &MockRESTClient{}
	mockDialer := &MockDialerCreator{}
	mockSPDYProvider := &MockSPDYProvider{}
	config := &rest.Config{}
	executor := &kubernetes.DefaultPortForwardExecutor{}

	// Mock function replacing ForwarderFactory for controlled testing.
	mockFactory := func(dialer httpstream.Dialer, ports []string, stopChan <-chan struct{}, readyChan chan struct{}) (kubernetes.PortForwarder, error) {
		// Simulates readiness correctly to prevent blocking.
		go func() {
			time.Sleep(50 * time.Millisecond)
			readyChan <- struct{}{}
		}()
		return &MockPortForwarder{}, nil
	}

	// Inject mocks into KubernetesPortForwarder.
	mockForwarder := &kubernetes.KubernetesPortForwarder{
		Config:           config,
		DialerCreator:    mockDialer,
		SPDYProvider:     mockSPDYProvider,
		ForwarderFactory: mockFactory,
	}

	// Execute port forwarding and verify the callback result.
	result, err := executor.PortForwardAndExecute(config, mockREST, mockForwarder, "mock-pod", "default", []string{"9091:9091"}, mockCallback)

	assert.Nil(t, err, "Expected no error in successful execution")
	assert.Equal(t, "Callback executed successfully", result, "Expected correct callback response")
}

// TestPortForwardAndExecute_NilCallback verifies port forwarding when no callback is provided.
func TestPortForwardAndExecute_NilCallback(t *testing.T) {
	mockREST := &MockRESTClient{}
	config := &rest.Config{}
	executor := &kubernetes.DefaultPortForwardExecutor{}

	// Use MockPortForwarder for testing.
	mockForwarder := &MockPortForwarder{}

	// Execute port forwarding without a callback.
	result, err := executor.PortForwardAndExecute(config, mockREST, mockForwarder, "mock-pod", "default", []string{"9091:9091"}, nil)

	// Ensure execution completes successfully even when callback is nil.
	assert.Nil(t, err)
	assert.Nil(t, result) // Expected nil result since no callback was executed.
}

func TestExecuteAsync_Success(t *testing.T) {
	mockREST := &MockRESTClient{}
	config := &rest.Config{}
	mockForwarder := &MockPortForwarder{}
	executor := &kubernetes.DefaultPortForwardExecutor{}

	resultsChan := make(chan interface{}) // Channel to receive async results

	// Start async execution
	err := executor.ExecuteAsync(config, mockREST, mockForwarder, "mock-pod", "default", []string{"9091:9091"}, mockCallback, resultsChan)

	assert.Nil(t, err, "Expected no error in async execution")

	// Collect async results
	go func() {
		for result := range resultsChan {
			assert.Equal(t, "Callback executed successfully", result, "Expected correct callback response")
		}
	}()

	time.Sleep(100 * time.Millisecond) // Simulate waiting before stopping port forwarding
}
