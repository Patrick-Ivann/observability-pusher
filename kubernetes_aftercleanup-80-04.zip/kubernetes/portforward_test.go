package kubernetes_test

import (
	"errors"
	"net/http"
	"net/url"
	"testing"
	"time"

	"github.com/Patrick-Ivann/go-microservice-playground/pkg/kubernetes"
	"github.com/stretchr/testify/assert"
	httpstream "k8s.io/apimachinery/pkg/util/httpstream"
	"k8s.io/client-go/rest"
	k8srest "k8s.io/client-go/rest"
	"k8s.io/client-go/transport/spdy"
	k8sspdy "k8s.io/client-go/transport/spdy"
)

// Mock Dialer Creator
type MockDialerCreator struct{}

// CreateDialer simulates the creation of a valid HTTP stream dialer using SPDY upgrader.
func (m *MockDialerCreator) CreateDialer(transport http.RoundTripper, upgrader k8sspdy.Upgrader, reqURL *url.URL) httpstream.Dialer {
	return k8sspdy.NewDialer(upgrader, &http.Client{Transport: transport}, "POST", reqURL)
}

// Mock SPDY Provider
type MockSPDYProvider struct{}

// GetRoundTripper returns a valid SPDY transport and upgrader for testing.
func (m *MockSPDYProvider) GetRoundTripper(config *k8srest.Config) (http.RoundTripper, k8sspdy.Upgrader, error) {
	return k8sspdy.RoundTripperFor(config)
}

// Test SPDY round tripper failure.
type FailingSPDYManager struct{}

func (f *FailingSPDYManager) CreateDialer(transport http.RoundTripper, upgrader k8sspdy.Upgrader, reqURL *url.URL) httpstream.Dialer {
	return nil // Simulate SPDY dialer failure.
}

type FailingSPDYProvider struct{}

func (m *MockPortForwarder) ForwardPorts() error {
	return nil // Simulating successful port forwarding
}

// Test successful port forwarding execution.
func TestKubernetesPortForwarder_Success(t *testing.T) {
	mockDialer := &MockDialerCreator{}
	config := &k8srest.Config{
		Host: "https://127.0.0.1:6443", // Use valid Kubernetes API server
	}
	mockSpdy := MockSPDYProvider{}

	// Mock function replacing portforward.New
	mockFactory := func(dialer httpstream.Dialer, ports []string, stopChan <-chan struct{}, readyChan chan struct{}) (kubernetes.PortForwarder, error) {
		go func() {
			time.Sleep(time.Millisecond * 10)
			readyChan <- struct{}{}
		}()
		return &MockPortForwarder{}, nil // Returns mocked forwarder
	}
	mockForwarder := &kubernetes.KubernetesPortForwarder{Config: config, DialerCreator: mockDialer, SPDYProvider: &mockSpdy, ForwarderFactory: mockFactory}

	reqURL, _ := url.Parse(config.Host) // Use Kubernetes API server
	err := mockForwarder.Forward(reqURL, []string{"9091:9091"}, make(chan struct{}), make(chan struct{}))

	assert.Nil(t, err, "Expected port forwarding to succeed")
}

func (f *FailingSPDYProvider) GetRoundTripper(config *rest.Config) (http.RoundTripper, spdy.Upgrader, error) {
	return nil, nil, errors.New("SPDY round tripper failed")
}

func TestKubernetesPortForwarder_SPDYRoundTripperFailure(t *testing.T) {
	mockDialer := &FailingSPDYManager{}
	config := &k8srest.Config{}
	failingSPDYProvider := &FailingSPDYProvider{}

	// Create KubernetesPortForwarder with a failing SPDY manager
	portForwarder := &kubernetes.KubernetesPortForwarder{Config: config, DialerCreator: mockDialer, SPDYProvider: failingSPDYProvider}

	reqURL, _ := url.Parse("https://mock-url")
	err := portForwarder.Forward(reqURL, []string{"9091:9091"}, make(chan struct{}), make(chan struct{}))

	assert.NotNil(t, err)
	assert.Contains(t, err.Error(), "failed to create SPDY round tripper")
}

func TestKubernetesPortForwarder_RoundTripperFailure(t *testing.T) {
	mockDialer := &FailingSPDYManager{}
	config := &k8srest.Config{}
	failingSPDYProvider := &FailingSPDYProvider{}

	// Create KubernetesPortForwarder with a failing SPDY manager
	portForwarder := &kubernetes.KubernetesPortForwarder{Config: config, DialerCreator: mockDialer, SPDYProvider: failingSPDYProvider}

	reqURL, _ := url.Parse("https://mock-url")
	err := portForwarder.Forward(reqURL, []string{"9091:9091"}, make(chan struct{}), make(chan struct{}))

	assert.NotNil(t, err)
	assert.Contains(t, err.Error(), "failed to create SPDY round tripper")
}

// Test failure in port forwarding creation.
type FailingPortForwarder struct{}

func (f *FailingPortForwarder) Forward(reqURL *url.URL, ports []string, stopChan <-chan struct{}, readyChan chan struct{}) error {
	return errors.New("port forwarding failed")
}

func TestKubernetesPortForwarder_PortForwarderFailure(t *testing.T) {

	mockDialer := &MockDialerCreator{}
	config := &k8srest.Config{
		Host: "https://127.0.0.1:6443", // Use valid Kubernetes API server
	}
	mockSpdy := MockSPDYProvider{}

	// Mock function replacing portforward.New
	mockFactory := func(dialer httpstream.Dialer, ports []string, stopChan <-chan struct{}, readyChan chan struct{}) (kubernetes.PortForwarder, error) {
		go func() {
			time.Sleep(time.Millisecond * 10)
			readyChan <- struct{}{}
		}()
		return &MockPortForwarder{}, errors.New("failed to create port forwarder") // Returns mocked forwarder
	}
	mockForwarder := &kubernetes.KubernetesPortForwarder{Config: config, DialerCreator: mockDialer, SPDYProvider: &mockSpdy, ForwarderFactory: mockFactory}

	reqURL, _ := url.Parse(config.Host) // Use Kubernetes API server
	err := mockForwarder.Forward(reqURL, []string{"9091:9091"}, make(chan struct{}), make(chan struct{}))

	assert.NotNil(t, err)
	assert.Contains(t, err.Error(), "failed to create port forwarder")
}
