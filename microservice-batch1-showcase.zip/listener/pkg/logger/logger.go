package logger

import (
	"encoding/xml"
	"fmt"
	"os"
	"strings"
	"text/template"

	"github.com/sirupsen/logrus"
)

// Structs for XML parsing
type LogTemplates struct {
	XMLName xml.Name `xml:"LogTemplates"`
	Logs    []Log    `xml:"Log"`
}

type Log struct {
	Key        string     `xml:"key,attr"`
	Message    string     `xml:"Message"`
	Properties []Property `xml:"Properties>Property"`
}

type Property struct {
	Name  string `xml:"name,attr"`
	Value string `xml:"value,attr"`
}

// Unified Logger Struct
type Logger struct {
	StandardLogger *logrus.Logger
	DetailedLogger *DetailedLogger
}

// DetailedLogger Struct
type DetailedLogger struct {
	Logger        *logrus.Logger
	LogTemplates  map[string]Log
	TemplateCache map[string]*template.Template
}

// NewLogger initializes the unified logger
func NewLogger(logLevel, xmlFile string) (*Logger, error) {
	// Standard Logger
	stdLogger := initStandardLogger(logLevel)

	// Detailed Logger
	detailLogger, err := initDetailedLogger(logLevel, xmlFile)
	if err != nil {
		return nil, err
	}

	return &Logger{
		StandardLogger: stdLogger,
		DetailedLogger: detailLogger,
	}, nil
}

// Helper to initialize StandardLogger
func initStandardLogger(logLevel string) *logrus.Logger {
	logger := logrus.New()
	logger.SetOutput(os.Stdout)
	logger.SetFormatter(&logrus.JSONFormatter{
		FieldMap: logrus.FieldMap{
			logrus.FieldKeyFile: "file",
		},
	})
	level, err := logrus.ParseLevel(logLevel)
	if err != nil {
		level = logrus.InfoLevel
	}
	logger.SetLevel(level)
	return logger
}

// Helper to initialize DetailedLogger
func initDetailedLogger(logLevel, xmlFile string) (*DetailedLogger, error) {
	logger := logrus.New()
	logger.SetOutput(os.Stdout)
	logger.SetFormatter(&logrus.JSONFormatter{})
	level, err := logrus.ParseLevel(logLevel)
	if err != nil {
		level = logrus.InfoLevel
	}
	logger.SetLevel(level)

	templates, cache, err := parseLogTemplates(xmlFile, func(name string) (*os.File, error) {
		return os.Open(name)
	})
	if err != nil {
		return nil, err
	}

	return &DetailedLogger{
		Logger:        logger,
		LogTemplates:  templates,
		TemplateCache: cache,
	}, nil
}

// Helper to parse XML templates
// func parseLogTemplates(xmlFile string) (map[string]Log, map[string]*template.Template, error) {
// 	file, err := os.Open(xmlFile)
// 	if err != nil {
// 		return nil, nil, fmt.Errorf("failed to open XML file: %v", err)
// 	}
// 	defer file.Close()

// 	var templates LogTemplates
// 	if err := xml.NewDecoder(file).Decode(&templates); err != nil {
// 		return nil, nil, fmt.Errorf("failed to parse XML file: %v", err)
// 	}

// 	logTemplateMap := make(map[string]Log)
// 	cache := make(map[string]*template.Template)
// 	for _, log := range templates.Logs {
// 		logTemplateMap[log.Key] = log
// 		compiledTemplate, err := template.New(log.Key).Parse(log.Message)
// 		if err != nil {
// 			return nil, nil, fmt.Errorf("failed to compile template for key %s: %v", log.Key, err)
// 		}
// 		cache[log.Key] = compiledTemplate
// 	}

// 	return logTemplateMap, cache, nil
// }

// Updated parseLogTemplates with dependency injection for os.Open
func parseLogTemplates(xmlFile string, openFile func(string) (*os.File, error)) (map[string]Log, map[string]*template.Template, error) {
	file, err := openFile(xmlFile)
	if err != nil {
		return nil, nil, fmt.Errorf("failed to open XML file: %v", err)
	}
	defer file.Close()

	var templates LogTemplates
	if err := xml.NewDecoder(file).Decode(&templates); err != nil {
		return nil, nil, fmt.Errorf("failed to parse XML file: %v", err)
	}

	logTemplateMap := make(map[string]Log)
	cache := make(map[string]*template.Template)
	for _, log := range templates.Logs {
		logTemplateMap[log.Key] = log
		compiledTemplate, err := template.New(log.Key).Parse(log.Message)
		if err != nil {
			return nil, nil, fmt.Errorf("failed to compile template for key %s: %v", log.Key, err)
		}
		cache[log.Key] = compiledTemplate
	}

	return logTemplateMap, cache, nil
}

func (d *DetailedLogger) LogDetailed(key string, params ...any) {
	// Fetch the template from the cache
	logTemplate, exists := d.TemplateCache[key]

	if !exists {
		d.Logger.Warnf("Log template for key %s not found", key)
		return
	}

	// Replace placeholders with actual values
	message := logTemplate.Tree.Root.String()
	for i, param := range params {
		placeholder := fmt.Sprintf("{%d}", i)
		message = strings.Replace(message, placeholder, fmt.Sprintf("%v", param), -1)
	}

	fmt.Printf("message: %v\n", message)

	// Fetch properties from the XML template
	fields := logrus.Fields{}
	template, _ := d.LogTemplates[key]
	for _, prop := range template.Properties {
		fields[prop.Name] = prop.Value
	}
	// Render the message with substituted placeholders
	fields["message"] = message

	// Log the final message with substituted parameters
	d.Logger.WithFields(fields).Info()
}
