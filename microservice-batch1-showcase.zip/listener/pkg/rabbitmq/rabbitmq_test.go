package rabbitmq

import (
	"fmt"
	"testing"

	"github.com/streadway/amqp"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
)

type MockChannel struct {
	mock.Mock
}

type MockConnection struct {
	mock.Mock
}

func (m *MockConnection) Channel() (ChannelInterface, error) {
	args := m.Called()
	return args.Get(0).(ChannelInterface), args.Error(1)
}

func (m *MockConnection) Close() error {
	args := m.Called()
	return args.Error(0)
}

func (m *MockChannel) ExchangeDeclare(name, kind string, durable, autoDelete, internal, noWait bool, args amqp.Table) error {
	argsCalled := m.Called(name, kind, durable, autoDelete, internal, noWait, args)
	return argsCalled.Error(0)
}

func (m *MockChannel) Publish(exchange, key string, mandatory, immediate bool, msg amqp.Publishing) error {
	args := m.Called(exchange, key, mandatory, immediate, msg)
	return args.Error(0)
}

func (m *MockChannel) QueueDeclare(name string, durable, autoDelete, exclusive, noWait bool, args amqp.Table) (amqp.Queue, error) {
	argsCalled := m.Called(name, durable, autoDelete, exclusive, noWait, args)
	return amqp.Queue{Name: name}, argsCalled.Error(1)
}

func (m *MockChannel) QueueBind(name, key, exchange string, noWait bool, args amqp.Table) error {
	argsCalled := m.Called(name, key, exchange, noWait, args)
	return argsCalled.Error(0)
}

func (m *MockChannel) Consume(name, consumer string, autoAck, exclusive, noLocal, noWait bool, args amqp.Table) (<-chan amqp.Delivery, error) {
	argsCalled := m.Called(name, consumer, autoAck, exclusive, noLocal, noWait, args)
	return argsCalled.Get(0).(<-chan amqp.Delivery), argsCalled.Error(1)
}

func (m *MockChannel) Get(queue string, autoAck bool) (amqp.Delivery, bool, error) {
	args := m.Called(queue, autoAck)
	return args.Get(0).(amqp.Delivery), args.Bool(1), args.Error(2)
}

func (m *MockChannel) Close() error {
	args := m.Called()
	return args.Error(0)
}

func TestCreateExchange(t *testing.T) {
	mockChannel := new(MockChannel)
	mockChannel.On("ExchangeDeclare", "test-exchange", "topic", true, false, false, false, mock.AnythingOfType("amqp.Table")).Return(nil)

	rabbitService := &RabbitMQService{
		Channel: mockChannel,
	}

	err := rabbitService.CreateExchange("test-exchange", "topic")
	assert.NoError(t, err)

	mockChannel.AssertExpectations(t)
}

func TestPublishMessage_Success(t *testing.T) {
	mockChannel := new(MockChannel)
	mockChannel.On("Publish", "test-exchange", "routing.key", false, false, mock.Anything).Return(nil)

	rabbitService := &RabbitMQService{
		Channel: mockChannel,
	}

	err := rabbitService.PublishMessage(
		"test-exchange",
		"routing.key",
		[]byte(`{"key":"value"}`),
		map[string]interface{}{"header-key": "header-value"},
		amqp.Table{"property-key": "property-value"},
	)
	assert.NoError(t, err)

	mockChannel.AssertExpectations(t)
}

func TestPublishMessage_Error(t *testing.T) {
	mockChannel := new(MockChannel)
	mockChannel.On("Publish", "test-exchange", "routing.key", false, false, mock.Anything).Return(fmt.Errorf("publish error"))

	rabbitService := &RabbitMQService{
		Channel: mockChannel,
	}

	err := rabbitService.PublishMessage(
		"test-exchange",
		"routing.key",
		[]byte(`{"key":"value"}`),
		nil,
		nil,
	)
	assert.Error(t, err)
	assert.Equal(t, "publish error", err.Error())

	mockChannel.AssertExpectations(t)
}

func TestReadMessagesFromTopicExchange(t *testing.T) {
	mockChannel := new(MockChannel)
	mockChannel.On("QueueDeclare", "test-queue", true, false, false, false, mock.AnythingOfType("amqp.Table")).Return(amqp.Queue{Name: "test-queue"}, nil)
	mockChannel.On("QueueBind", "test-queue", "routing.key", "test-exchange", false, mock.AnythingOfType("amqp.Table")).Return(nil)

	messageChannel := make(chan amqp.Delivery, 1)
	messageChannel <- amqp.Delivery{Body: []byte("test-message")}
	close(messageChannel)
	// Consume(name, consumer , autoAck, exclusive, noLocal, noWait bool, args amqp.Table)
	mockChannel.On("Consume", "test-queue", "", true, false, false, false, mock.AnythingOfType("amqp.Table")).Return((<-chan amqp.Delivery)(messageChannel), nil)

	rabbitService := &RabbitMQService{
		Channel: mockChannel,
	}

	msgs, err := rabbitService.ReadMessagesFromTopicExchange("test-exchange", "routing.key", "test-queue")
	assert.NoError(t, err)

	for msg := range msgs {
		assert.Equal(t, "test-message", string(msg.Body))
	}

	mockChannel.AssertExpectations(t)
}

func TestReadMessagesBatch_Success(t *testing.T) {
	mockChannel := new(MockChannel)
	mockChannel.On("Get", "test-queue", true).Return(amqp.Delivery{Body: []byte("message1")}, true, nil).Once()
	mockChannel.On("Get", "test-queue", true).Return(amqp.Delivery{Body: []byte("message2")}, true, nil).Once()
	mockChannel.On("Get", "test-queue", true).Return(amqp.Delivery{}, false, nil).Once()

	rabbitService := &RabbitMQService{
		Channel: mockChannel,
	}

	messages, err := rabbitService.ReadMessagesBatch("test-queue", 5)
	assert.NoError(t, err)
	assert.Len(t, messages, 2)
	assert.Equal(t, "message1", string(messages[0].Body))
	assert.Equal(t, "message2", string(messages[1].Body))

	mockChannel.AssertExpectations(t)
}

func TestReadMessagesBatch_Error(t *testing.T) {
	mockChannel := new(MockChannel)
	mockChannel.On("Get", "test-queue", true).Return(amqp.Delivery{}, false, fmt.Errorf("get error")).Once()

	rabbitService := &RabbitMQService{
		Channel: mockChannel,
	}

	messages, err := rabbitService.ReadMessagesBatch("test-queue", 5)
	assert.Error(t, err)
	assert.Nil(t, messages)
	assert.Equal(t, "get error", err.Error())

	mockChannel.AssertExpectations(t)
}

func TestReadMessage_ChannelGetError(t *testing.T) {
	mockChannel := new(MockChannel)
	mockChannel.On("Get", "test-queue", true).Return(amqp.Delivery{}, false, fmt.Errorf("channel get error")).Once()

	rabbitService := &RabbitMQService{
		Channel: mockChannel,
	}

	message, err := rabbitService.ReadMessage("test-queue")
	assert.Error(t, err)
	assert.Nil(t, message)
	assert.Equal(t, "channel get error", err.Error())

	mockChannel.AssertExpectations(t)
}

func TestReadMessage_Success(t *testing.T) {
	mockChannel := new(MockChannel)
	mockChannel.On("Get", "test-queue", true).Return(amqp.Delivery{Body: []byte("single-message")}, true, nil).Once()

	rabbitService := &RabbitMQService{
		Channel: mockChannel,
	}

	message, err := rabbitService.ReadMessage("test-queue")
	assert.NoError(t, err)
	assert.NotNil(t, message)
	assert.Equal(t, "single-message", string(message.Body))

	mockChannel.AssertExpectations(t)
}

func TestReadMessage_NoMessage(t *testing.T) {
	mockChannel := new(MockChannel)
	mockChannel.On("Get", "test-queue", true).Return(amqp.Delivery{}, false, nil).Once()

	rabbitService := &RabbitMQService{
		Channel: mockChannel,
	}

	message, err := rabbitService.ReadMessage("test-queue")
	assert.NoError(t, err)
	assert.Nil(t, message)

	mockChannel.AssertExpectations(t)
}

func TestReadMessagesFromHeaderExchange_Success(t *testing.T) {
	mockChannel := new(MockChannel)
	mockChannel.On("QueueDeclare", "header-queue", true, false, false, false, nil).Return(amqp.Queue{Name: "header-queue"}, nil)
	mockChannel.On("QueueBind", "header-queue", "", "header-exchange", false, mock.Anything).Return(nil)

	messageChannel := make(chan amqp.Delivery, 1)
	messageChannel <- amqp.Delivery{Body: []byte("header-message")}
	close(messageChannel)

	mockChannel.On("Consume", "header-queue", "", true, false, false, false, nil).Return((<-chan amqp.Delivery)(messageChannel), nil)

	rabbitService := &RabbitMQService{
		Channel: mockChannel,
	}

	msgs, err := rabbitService.ReadMessagesFromHeaderExchange("header-exchange", map[string]interface{}{"header-key": "header-value"}, "header-queue")
	assert.NoError(t, err)

	for msg := range msgs {
		assert.Equal(t, "header-message", string(msg.Body))
	}

	mockChannel.AssertExpectations(t)
}

func TestReadMessagesFromHeaderExchange_Error(t *testing.T) {
	mockChannel := new(MockChannel)
	mockChannel.On("QueueDeclare", "header-queue", true, false, false, false, nil).Return(amqp.Queue{}, fmt.Errorf("queue declare error"))

	rabbitService := &RabbitMQService{
		Channel: mockChannel,
	}

	msgs, err := rabbitService.ReadMessagesFromHeaderExchange("header-exchange", map[string]interface{}{"header-key": "header-value"}, "header-queue")
	assert.Error(t, err)
	assert.Nil(t, msgs)
	assert.Equal(t, "queue declare error", err.Error())

	mockChannel.AssertExpectations(t)
}

func TestReadMessagesFromDirectExchange_Success(t *testing.T) {
	mockChannel := new(MockChannel)
	mockChannel.On("QueueDeclare", "direct-queue", true, false, false, false, nil).Return(amqp.Queue{Name: "direct-queue"}, nil)
	mockChannel.On("QueueBind", "direct-queue", "routing.key", "direct-exchange", false, nil).Return(nil)

	messageChannel := make(chan amqp.Delivery, 1)
	messageChannel <- amqp.Delivery{Body: []byte("direct-message")}
	close(messageChannel)

	mockChannel.On("Consume", "direct-queue", "", true, false, false, false, nil).Return((<-chan amqp.Delivery)(messageChannel), nil)

	rabbitService := &RabbitMQService{
		Channel: mockChannel,
	}

	msgs, err := rabbitService.ReadMessagesFromDirectExchange("direct-exchange", "routing.key", "direct-queue")
	assert.NoError(t, err)

	for msg := range msgs {
		assert.Equal(t, "direct-message", string(msg.Body))
	}

	mockChannel.AssertExpectations(t)
}

func TestReadMessagesFromTopicExchange_QueueDeclareError(t *testing.T) {
	mockChannel := new(MockChannel)
	mockChannel.On("QueueDeclare", "topic-queue", true, false, false, false, nil).Return(amqp.Queue{}, fmt.Errorf("queue declare error"))

	rabbitService := &RabbitMQService{
		Channel: mockChannel,
	}

	msgs, err := rabbitService.ReadMessagesFromTopicExchange("topic-exchange", "routing.key", "topic-queue")
	assert.Error(t, err)
	assert.Nil(t, msgs)
	assert.Equal(t, "queue declare error", err.Error())

	mockChannel.AssertExpectations(t)
}

func TestReadMessagesFromTopicExchange_QueueBindError(t *testing.T) {
	mockChannel := new(MockChannel)
	mockChannel.On("QueueDeclare", "topic-queue", true, false, false, false, nil).Return(amqp.Queue{Name: "topic-queue"}, nil)
	mockChannel.On("QueueBind", "topic-queue", "routing.key", "topic-exchange", false, nil).Return(fmt.Errorf("queue bind error"))

	rabbitService := &RabbitMQService{
		Channel: mockChannel,
	}

	msgs, err := rabbitService.ReadMessagesFromTopicExchange("topic-exchange", "routing.key", "topic-queue")
	assert.Error(t, err)
	assert.Nil(t, msgs)
	assert.Equal(t, "queue bind error", err.Error())

	mockChannel.AssertExpectations(t)
}

func TestNewRabbitMQService_Success(t *testing.T) {
	mockConnection := new(MockConnection)
	mockChannel := new(MockChannel)

	mockConnection.On("Channel").Return(mockChannel, nil)

	rabbitService, err := NewRabbitMQService(mockConnection)
	assert.NoError(t, err)
	assert.NotNil(t, rabbitService)
	assert.Equal(t, mockConnection, rabbitService.Connection)
	assert.Equal(t, mockChannel, rabbitService.Channel)

	mockConnection.AssertExpectations(t)
}

func TestNewRabbitMQService_ChannelError(t *testing.T) {
	mockConnection := new(MockConnection)
	mockConnection.On("Channel").Return(nil, fmt.Errorf("channel error"))

	rabbitService, err := NewRabbitMQService(mockConnection)
	assert.Error(t, err)
	assert.Nil(t, rabbitService)

	mockConnection.AssertExpectations(t)
}

func TestCreateExchange_Success(t *testing.T) {
	mockChannel := new(MockChannel)
	mockChannel.On("ExchangeDeclare", "test-exchange", "topic", true, false, false, false, mock.AnythingOfType("amqp.Table")).Return(nil)

	rabbitService := &RabbitMQService{
		Channel: mockChannel,
	}

	err := rabbitService.CreateExchange("test-exchange", "topic")
	assert.NoError(t, err)

	mockChannel.AssertExpectations(t)
}

func TestCreateExchange_Error(t *testing.T) {
	mockChannel := new(MockChannel)
	mockChannel.On("ExchangeDeclare", "test-exchange", "topic", true, false, false, false, mock.AnythingOfType("amqp.Table")).Return(fmt.Errorf("exchange declare error"))

	rabbitService := &RabbitMQService{
		Channel: mockChannel,
	}

	err := rabbitService.CreateExchange("test-exchange", "topic")
	assert.Error(t, err)
	assert.Equal(t, "exchange declare error", err.Error())

	mockChannel.AssertExpectations(t)
}

func TestRabbitMQService_Close_Success(t *testing.T) {
	mockConnection := new(MockConnection)
	mockChannel := new(MockChannel)

	mockChannel.On("Close").Return(nil)
	mockConnection.On("Close").Return(nil)

	rabbitService := &RabbitMQService{
		Connection: mockConnection,
		Channel:    mockChannel,
	}

	err := rabbitService.Close()
	assert.NoError(t, err)

	mockChannel.AssertExpectations(t)
	mockConnection.AssertExpectations(t)
}

func TestRabbitMQService_Close_ChannelError(t *testing.T) {
	mockConnection := new(MockConnection)
	mockChannel := new(MockChannel)

	mockChannel.On("Close").Return(fmt.Errorf("channel close error"))
	mockConnection.On("Close").Return(nil)

	rabbitService := &RabbitMQService{
		Connection: mockConnection,
		Channel:    mockChannel,
	}

	err := rabbitService.Close()
	assert.Error(t, err)
	assert.Equal(t, "channel close error", err.Error())

	mockChannel.AssertExpectations(t)
	mockConnection.AssertExpectations(t)
}

func TestRabbitMQService_Close_ConnectionError(t *testing.T) {
	mockConnection := new(MockConnection)
	mockChannel := new(MockChannel)

	mockChannel.On("Close").Return(nil)
	mockConnection.On("Close").Return(fmt.Errorf("connection close error"))

	rabbitService := &RabbitMQService{
		Connection: mockConnection,
		Channel:    mockChannel,
	}

	err := rabbitService.Close()
	assert.Error(t, err)
	assert.Equal(t, "connection close error", err.Error())

	mockChannel.AssertExpectations(t)
	mockConnection.AssertExpectations(t)
}
