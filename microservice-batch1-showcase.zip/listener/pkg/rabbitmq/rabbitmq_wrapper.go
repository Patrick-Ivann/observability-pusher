package rabbitmq

import (
	"github.com/streadway/amqp"
)

// ConnectionWrapper wraps *amqp.Connection to implement ConnectionInterface
type ConnectionWrapper struct {
	*amqp.Connection
}

// Implement Channel() method
func (cw *ConnectionWrapper) Channel() (ChannelInterface, error) {
	ch, err := cw.Connection.Channel()
	if err != nil {
		return nil, err
	}
	return &ChannelWrapper{Channel: ch}, nil
}

// Ensure Close() is compatible
func (cw *ConnectionWrapper) Close() error {
	return cw.Connection.Close()
}

type ChannelWrapper struct {
	*amqp.Channel
}

// Implement the methods of ChannelInterface
func (cw *ChannelWrapper) ExchangeDeclare(name, kind string, durable, autoDelete, internal, noWait bool, args amqp.Table) error {
	return cw.Channel.ExchangeDeclare(name, kind, durable, autoDelete, internal, noWait, args)
}

func (cw *ChannelWrapper) Publish(exchange, key string, mandatory, immediate bool, msg amqp.Publishing) error {
	return cw.Channel.Publish(exchange, key, mandatory, immediate, msg)
}

func (cw *ChannelWrapper) QueueDeclare(name string, durable, autoDelete, exclusive, noWait bool, args amqp.Table) (amqp.Queue, error) {
	return cw.Channel.QueueDeclare(name, durable, autoDelete, exclusive, noWait, args)
}

func (cw *ChannelWrapper) QueueBind(name, key, exchange string, noWait bool, args amqp.Table) error {
	return cw.Channel.QueueBind(name, key, exchange, noWait, args)
}

func (cw *ChannelWrapper) Consume(name, consumer string, autoAck, exclusive, noLocal, noWait bool, args amqp.Table) (<-chan amqp.Delivery, error) {
	return cw.Channel.Consume(name, consumer, autoAck, exclusive, noLocal, noWait, args)
}

func (cw *ChannelWrapper) Get(queue string, autoAck bool) (amqp.Delivery, bool, error) {
	return cw.Channel.Get(queue, autoAck)
}

func (cw *ChannelWrapper) Close() error {
	return cw.Channel.Close()
}
