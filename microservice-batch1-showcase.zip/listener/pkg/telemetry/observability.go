package observability

import (
	"context"
	"log"

	"github.com/spf13/viper"
	"go.opentelemetry.io/otel"
	"go.opentelemetry.io/otel/exporters/otlp/otlptrace/otlptracehttp"
	"go.opentelemetry.io/otel/exporters/stdout/stdouttrace"
	"go.opentelemetry.io/otel/sdk/resource"
	"go.opentelemetry.io/otel/sdk/trace"
	semconv "go.opentelemetry.io/otel/semconv/v1.4.0"
)

// observability:
//   tracing:
//     enabled: true
//     consoleExporter: true
//     jaegerExporter:
//       enabled: true
//       endpoint: "http://localhost:14268/api/traces"
//     tempoExporter:
//       enabled: false
//       endpoint: "http://tempo-instance:4318/v1/traces"

type ObservabilityConfig struct {
	Tracing struct {
		Enabled         bool `mapstructure:"enabled"`
		ConsoleExporter bool `mapstructure:"consoleExporter"`
		JaegerExporter  struct {
			Enabled  bool   `mapstructure:"enabled"`
			Endpoint string `mapstructure:"endpoint"`
		} `mapstructure:"jaegerExporter"`
		TempoExporter struct {
			Enabled  bool   `mapstructure:"enabled"`
			Endpoint string `mapstructure:"endpoint"`
		} `mapstructure:"tempoExporter"`
	} `mapstructure:"tracing"`
}

func LoadObservabilityConfig(configPath string) *ObservabilityConfig {
	viper.SetConfigFile(configPath)
	if err := viper.ReadInConfig(); err != nil {
		log.Fatalf("Error reading config file: %v", err)
	}

	var config ObservabilityConfig
	if err := viper.Unmarshal(&config); err != nil {
		log.Fatalf("Error parsing observability config: %v", err)
	}

	return &config
}

func InitTracer(config *ObservabilityConfig) {
	if !config.Tracing.Enabled {
		log.Println("Tracing is disabled in the configuration.")
		return
	}

	var tracerProvider *trace.TracerProvider

	// Create Resource with service information
	res := resource.NewWithAttributes(
		semconv.SchemaURL,
		semconv.ServiceNameKey.String("your-service-name"),
		semconv.ServiceVersionKey.String("1.0.0"),
	)

	// Setup Tracer Providers
	var exporters []trace.SpanExporter

	if config.Tracing.ConsoleExporter {
		exporter, err := stdouttrace.New(stdouttrace.WithPrettyPrint())
		if err != nil {
			log.Fatalf("Failed to create console exporter: %v", err)
		}
		exporters = append(exporters, exporter)
		log.Println("Console tracing exporter initialized.")
	}

	if config.Tracing.JaegerExporter.Enabled {
		exporter, err := otlptracehttp.New(context.Background(),
			otlptracehttp.WithEndpoint(config.Tracing.JaegerExporter.Endpoint),
			otlptracehttp.WithInsecure(),
		)
		if err != nil {
			log.Fatalf("Failed to initialize Jaeger exporter: %v", err)
		}
		exporters = append(exporters, exporter)
		log.Printf("Jaeger tracing exporter initialized with endpoint: %s\n", config.Tracing.JaegerExporter.Endpoint)
	}

	if config.Tracing.TempoExporter.Enabled {
		exporter, err := otlptracehttp.New(context.Background(),
			otlptracehttp.WithEndpoint(config.Tracing.TempoExporter.Endpoint),
			otlptracehttp.WithInsecure(),
		)
		if err != nil {
			log.Fatalf("Failed to initialize Tempo exporter: %v", err)
		}
		exporters = append(exporters, exporter)
		log.Printf("Tempo tracing exporter initialized with endpoint: %s\n", config.Tracing.TempoExporter.Endpoint)
	}

	if len(exporters) == 0 {
		log.Fatalf("No tracing exporters were enabled in the configuration.")
	}

	// Initialize Tracer Provider with multiple exporters
	tracerProvider = trace.NewTracerProvider(
		trace.WithBatcher(multiSpanExporter{exporters}),
		trace.WithResource(res),
	)

	otel.SetTracerProvider(tracerProvider)
	log.Println("Tracer provider initialized.")
}

type multiSpanExporter struct {
	exporters []trace.SpanExporter
}

func (m multiSpanExporter) ExportSpans(ctx context.Context, spans []trace.ReadOnlySpan) error {
	for _, exporter := range m.exporters {
		err := exporter.ExportSpans(ctx, spans)
		if err != nil {
			log.Printf("Error exporting spans: %v", err)
		}
	}
	return nil
}

func (m multiSpanExporter) Shutdown(ctx context.Context) error {
	for _, exporter := range m.exporters {
		err := exporter.Shutdown(ctx)
		if err != nil {
			log.Printf("Error shutting down exporter: %v", err)
		}
	}
	return nil
}

func SetupTracing() context.Context {
	// Load configuration
	config := LoadObservabilityConfig("config/config.yaml")

	// Initialize Tracer
	InitTracer(config)

	// Example of creating a trace
	tracer := otel.Tracer("example-tracer")
	ctx, span := tracer.Start(context.Background(), "example-span")
	defer span.End()

	log.Println("Service is running with observability enabled.")

	return ctx
}
