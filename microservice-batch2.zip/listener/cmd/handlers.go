package cmd

import (
	"net"

	"github.com/Patrick-Ivann/go-microservice-playground/pkg/logger"
)

func StartUDPListener(ip string, port int, messageChannel chan<- string, log logger.Logger) {
	addr := &net.UDPAddr{IP: net.ParseIP(ip), Port: port}
	conn, err := net.ListenUDP("udp", addr)
	if err != nil {
		log.StandardLogger.Fatal("Failed to start UDP listener: ", err)
	}
	defer conn.Close()

	buffer := make([]byte, 1024)
	for {
		n, remoteAddr, err := conn.ReadFromUDP(buffer)
		if err != nil {
			log.StandardLogger.Error("Error reading UDP packet from ", remoteAddr, ": ", err)
			continue
		}
		message := string(buffer[:n])
		messageChannel <- message
		log.StandardLogger.Info("Received message from ", remoteAddr, ": ", message)
	}
}
