package cmd

import (
	"context"
	"log"
	"os"
	"os/signal"
	"syscall"

	"github.com/Patrick-Ivann/go-microservice-playground/pkg/config"
	"github.com/Patrick-Ivann/go-microservice-playground/pkg/logger"
	"github.com/Patrick-Ivann/go-microservice-playground/pkg/rabbitmq"
	"github.com/streadway/amqp"
)

func main() {

	// Load configuration
	cfg := config.LoadConfig("config/config.yaml")

	// Initialize the standard logger
	logger, err := logger.NewLogger("TRACE", "config/log_templates.xml")

	if err != nil {
		log.Fatalf("Failed to connect to read log configuration: %v", err)

	}

	// Establish a RabbitMQ connection
	connectionString := "amqp://guest:guest@localhost:5672/"
	conn, err := amqp.Dial(connectionString)
	if err != nil {
		log.Fatalf("Failed to connect to RabbitMQ: %v", err)
	}
	defer conn.Close()

	// Wrap the connection
	wrappedConn := &rabbitmq.ConnectionWrapper{Connection: conn}
	// Create the RabbitMQ service instance
	rabbitService, err := rabbitmq.NewRabbitMQService(wrappedConn)
	if err != nil {
		logger.StandardLogger.Info("Failed to initialize RabbitMQ: ", err)
	}
	defer rabbitService.Connection.Close()

	// err = rabbitService.PublishMessage(
	// 	"my-exchange",
	// 	"routing.key",
	// 	[]byte(`{"key":"value"}`),
	// 	map[string]interface{}{"header-key": "header-value"},
	// 	amqp.Table{"property-key": "property-value"},
	// )
	// if err != nil {
	// 	log.Fatalf("Failed to publish message: %v", err)
	// }

	// msgs, err := rabbitService.ReadMessagesFromTopicExchange("my-exchange", "routing.key", "my-queue")
	// if err != nil {
	// 	log.Fatalf("Failed to read messages: %v", err)
	// }

	// for msg := range msgs {
	// 	log.Printf("Received message: %s", msg.Body)
	// }

	// Start UDP listeners
	messageChannel := make(chan string)
	for _, ip := range cfg.IPs {
		for _, port := range cfg.Ports {
			go StartUDPListener(ip, port, messageChannel, *logger)
		}
	}

	// Graceful shutdown
	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer func() {
		stop()

	}()

	// Handle incoming messages and publish to RabbitMQ
	go func() {
		for msg := range messageChannel {

			err := rabbitService.PublishMessage(cfg.MessageBrokerAMQP.Input.Exchanges["FIRST_EXCHANGE"].Name, cfg.MessageBrokerAMQP.Input.Exchanges["FIRST_EXCHANGE"].RoutingKey, []byte(msg), make(map[string]interface{}), make(amqp.Table))
			if err != nil {
				logger.StandardLogger.Error("Failed to publish message to RabbitMQ: ", err)
			} else {
				logger.StandardLogger.Info("Message published to RabbitMQ: ", msg)
			}
		}
	}()

	<-ctx.Done()
	logger.StandardLogger.Info("Shutting down microservice gracefully")
}
