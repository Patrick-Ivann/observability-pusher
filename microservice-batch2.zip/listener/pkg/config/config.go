package config

import (
	"log"

	"github.com/spf13/viper"
)

type Config struct {
	IPs               []string                `mapstructure:"ips"`
	Ports             []int                   `mapstructure:"ports"`
	MessageBrokerAMQP MessageBrokerAMQPConfig `mapstructure:"message-broker-amqp"`
	LogLevel          string                  `mapstructure:"log_level"`
}

func LoadConfig(configPath string) *Config {
	viper.SetConfigFile(configPath)
	viper.AutomaticEnv()

	if err := viper.ReadInConfig(); err != nil {
		log.Fatalf("Error reading config file: %v", err)
	}

	var config Config
	if err := viper.Unmarshal(&config); err != nil {
		log.Fatalf("Error parsing config: %v", err)
	}

	return &config
}
