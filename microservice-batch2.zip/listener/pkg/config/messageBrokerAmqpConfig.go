package config

type MessageBrokerAMQPConfig struct {
	Host     string `mapstructure:"host"`
	Port     int    `mapstructure:"port"`
	Login    string `mapstructure:"login"`
	Password string `mapstructure:"password"`
	Input    struct {
		Exchanges map[string]struct {
			Name             string            `mapstructure:"name"`
			QueueName        string            `mapstructure:"queueName"`
			Type             string            `mapstructure:"type"`
			RoutingKey       string            `mapstructure:"routingKey"`
			BindingArguments map[string]string `mapstructure:"bindingArguments"`
		} `mapstructure:"exchanges"`
	} `mapstructure:"input"`
	Output struct {
		Exchanges map[string]struct {
			Name        string `mapstructure:"name"`
			Type        string `mapstructure:"type"`
			RoutingKeys []struct {
				RoutingKeyName string `mapstructure:"routing_key_name"`
			} `mapstructure:"routingKeys"`
			ExtraHeaders map[string]string `mapstructure:"extraHeaders"`
		} `mapstructure:"exchanges"`
	} `mapstructure:"output"`
}
