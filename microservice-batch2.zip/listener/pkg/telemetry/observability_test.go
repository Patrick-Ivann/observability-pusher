package observability

import (
	"bytes"
	"context"
	"testing"

	"github.com/spf13/viper"
	"github.com/stretchr/testify/assert"
	"go.opentelemetry.io/otel"
)

func setupTestConfig(yamlContent string) *ObservabilityConfig {
	viper.SetConfigType("yaml")
	err := viper.ReadConfig(bytes.NewBuffer([]byte(yamlContent)))
	if err != nil {
		panic("Failed to load test configuration: " + err.Error())
	}

	var config ObservabilityConfig
	err = viper.Unmarshal(&config)
	if err != nil {
		panic("Failed to parse test configuration: " + err.Error())
	}

	return &config
}

func TestInitTracer_TracingDisabled(t *testing.T) {
	configContent := `
observability:
  tracing:
    enabled: false
    consoleExporter: false
    jaegerExporter:
      enabled: false
    tempoExporter:
      enabled: false
`
	config := setupTestConfig(configContent)

	// Initialize tracer
	InitTracer(config)

	// Verify that no tracer provider was set
	tracer := otel.Tracer("test-tracer")
	_, span := tracer.Start(context.Background(), "test-span")
	defer span.End()

	assert.NotEqual(t, "test-span", span.SpanContext().SpanID().String(), "Tracing should be disabled.")
}

func TestInitTracer_ConsoleExporterEnabled(t *testing.T) {
	configContent := `
observability:
  tracing:
    enabled: true
    consoleExporter: true
    jaegerExporter:
      enabled: false
    tempoExporter:
      enabled: false
`
	config := setupTestConfig(configContent)

	// Initialize tracer
	InitTracer(config)

	// Verify that a tracer provider is set
	tracer := otel.Tracer("test-tracer")
	_, span := tracer.Start(context.Background(), "test-span")
	defer span.End()

	assert.NotNil(t, span.SpanContext().TraceID(), "Tracing should be enabled with a console exporter.")
}

func TestInitTracer_JaegerExporterEnabled(t *testing.T) {
	configContent := `
observability:
  tracing:
    enabled: true
    consoleExporter: false
    jaegerExporter:
      enabled: true
      endpoint: "http://localhost:14268/api/traces"
    tempoExporter:
      enabled: false
`
	config := setupTestConfig(configContent)

	// Initialize tracer
	InitTracer(config)

	// Verify that a tracer provider is set
	tracer := otel.Tracer("test-tracer")
	_, span := tracer.Start(context.Background(), "test-span")
	defer span.End()

	assert.NotNil(t, span.SpanContext().TraceID(), "Tracing should be enabled with a Jaeger exporter.")
}

func TestInitTracer_TempoExporterEnabled(t *testing.T) {
	configContent := `
observability:
  tracing:
    enabled: true
    consoleExporter: false
    jaegerExporter:
      enabled: false
    tempoExporter:
      enabled: true
      endpoint: "http://tempo-instance:4318/v1/traces"
`
	config := setupTestConfig(configContent)

	// Initialize tracer
	InitTracer(config)

	// Verify that a tracer provider is set
	tracer := otel.Tracer("test-tracer")
	_, span := tracer.Start(context.Background(), "test-span")
	defer span.End()

	assert.NotNil(t, span.SpanContext().TraceID(), "Tracing should be enabled with a Tempo exporter.")
}

func TestInitTracer_NoExportersEnabled(t *testing.T) {
	configContent := `
observability:
  tracing:
    enabled: true
    consoleExporter: false
    jaegerExporter:
      enabled: false
    tempoExporter:
      enabled: false
`
	config := setupTestConfig(configContent)

	// Initialize tracer and ensure it exits gracefully without exporters
	assert.Panics(t, func() {
		InitTracer(config)
	}, "No exporters should cause a panic in InitTracer.")
}
