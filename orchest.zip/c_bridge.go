package core

/*
#cgo LDFLAGS: -L/usr/local/lib -lgnss_core
#include "gnss_core.h"
#include <stdlib.h>
#include <string.h>
*/
import "C"
import (
	"errors"
	"fmt"
	"sync"
	"unsafe"

	"github.com/yourorg/gnss-processor/internal/domain"
)

// CBridge is the real GNSSCore backed by the C shared library.
//
// It owns all C-side state structs and serialises every access through a single
// mutex. The CBridge may be shared by the FNAV and INAV service lanes — the
// mutex prevents concurrent calls from corrupting the C global state.
//
// Memory layout:
//
//	measDB      — MEASUREMENT_DATABASE   : per-station, per-satellite measurements
//	navDB       — NAVIGATION_DATABASE    : broadcast ephemeris for all SVs
//	losDB       — LOS_DATABASE           : pre-processed LoS residuals from PP
//	residualDB  — RESIDUAL_DATABASE      : temporal residuals updated by Execute
//	kalman      — KALMAN_STATUS          : Kalman filter state (updated by Execute)
//	stationNet  — STATION_NETWORK        : static GSS station topology
//	positions   — [MaxStations]POSITION  : ECEF positions updated by ComputeStationPositions
//	config      — CONFIG                 : static algorithm parameters
type CBridge struct {
	mu          sync.Mutex
	measDB      C.MEASUREMENT_DATABASE
	navDB       C.NAVIGATION_DATABASE
	losDB       C.LOS_DATABASE
	residualDB  C.RESIDUAL_DATABASE
	kalman      C.KALMAN_STATUS
	stationNet  C.STATION_NETWORK
	positions   [domain.MaxStations]C.POSITION
	config      C.CONFIG
	initialised bool
}

// NewCBridge constructs a CBridge with the given static config and station topology.
// Call InitMeasurementDatabase() before any other method.
func NewCBridge(config C.CONFIG, network C.STATION_NETWORK) *CBridge {
	return &CBridge{
		config:     config,
		stationNet: network,
	}
}

// ─── GNSSCore implementation ──────────────────────────────────────────────────

// InitMeasurementDatabase zero-initialises the C measurement database.
// Must be called before AddMeasurement; safe to call again after LoadSnapshot.
func (b *CBridge) InitMeasurementDatabase() error {
	b.mu.Lock()
	defer b.mu.Unlock()
	C.InitMeasurementDatabase(&b.measDB)
	b.initialised = true
	return nil
}

// AddMeasurement converts p to the C representation and calls C.AddMeasurement.
func (b *CBridge) AddMeasurement(p AddMeasurementParams) error {
	b.mu.Lock()
	defer b.mu.Unlock()
	if !b.initialised {
		return errors.New("measurement database not initialised — call InitMeasurementDatabase first")
	}
	cMeas := domainMeasDataToCArray(p.MeasData)
	C.AddMeasurement(
		&b.measDB,
		C.UINT16(p.StationID),
		C.UINT16(p.SatelliteID),
		C.UINT64(p.Epoch),
		&cMeas[0],
		domainBoolToC(p.SecMeas),
		C.DOUBLE(p.RecClkOffset),
	)
	return nil
}

// RemoveUnhealthySat prunes unhealthy SVs from the measurement database.
// health is indexed 0..MaxSV-1; true means the SV should be kept.
func (b *CBridge) RemoveUnhealthySat(health [domain.MaxSV]bool, epoch int64) error {
	b.mu.Lock()
	defer b.mu.Unlock()
	cHealth := domainHealthToCArray(health)
	C.RemoveUnhealhySat(&b.measDB, &cHealth[0], C.INT64(epoch))
	return nil
}

// ComputeStationPositions computes ECEF positions for all GSS stations at epoch.
func (b *CBridge) ComputeStationPositions(epoch float64) error {
	b.mu.Lock()
	defer b.mu.Unlock()
	C.ComputePositionStation(C.DOUBLE(epoch), &b.stationNet, &b.positions[0])
	return nil
}

// PP runs the per-second pre-processing step (cycle-slip detection, LoS residuals).
// It reads from measDB and navDB, writes to losDB.
func (b *CBridge) PP(epoch int64) error {
	b.mu.Lock()
	defer b.mu.Unlock()
	avail := buildAvailArray(b.stationNet)
	C.PP(
		C.UINT64(epoch),
		&b.navDB,
		&b.measDB,
		&b.positions[0],
		&avail[0],
		&b.losDB,
		&b.config,
	)
	return nil
}

// Execute runs the Kalman filter integrity computation.
// It reads from measDB, navDB, losDB; updates residualDB and kalman; writes to output.
func (b *CBridge) Execute(epoch int64) (*ExecuteOutput, error) {
	b.mu.Lock()
	defer b.mu.Unlock()
	var cOutput C.OUTPUT
	avail := buildAvailArray(b.stationNet)
	C.Execute(
		b.config,
		b.positions[0],
		&avail[0],
		&b.measDB,
		&b.navDB,
		C.UINT64(epoch),
		&b.residualDB,
		&b.kalman,
		&cOutput,
	)
	return mapCOutputToGo(&cOutput, &b.residualDB, &b.kalman), nil
}

// ─── Snapshot ─────────────────────────────────────────────────────────────────

// DumpSnapshot serialises all mutable C state to a byte-blob snapshot.
// The snapshot can be passed to LoadSnapshot to restore the state exactly.
func (b *CBridge) DumpSnapshot() (*Snapshot, error) {
	b.mu.Lock()
	defer b.mu.Unlock()

	measBytes, err := serializeC(unsafe.Pointer(&b.measDB), C.sizeof_MEASUREMENT_DATABASE)
	if err != nil {
		return nil, fmt.Errorf("dump measDB: %w", err)
	}
	navBytes, err := serializeC(unsafe.Pointer(&b.navDB), C.sizeof_NAVIGATION_DATABASE)
	if err != nil {
		return nil, fmt.Errorf("dump navDB: %w", err)
	}
	losBytes, err := serializeC(unsafe.Pointer(&b.losDB), C.sizeof_LOS_DATABASE)
	if err != nil {
		return nil, fmt.Errorf("dump losDB: %w", err)
	}
	residualBytes, err := serializeC(unsafe.Pointer(&b.residualDB), C.sizeof_RESIDUAL_DATABASE)
	if err != nil {
		return nil, fmt.Errorf("dump residualDB: %w", err)
	}
	kalmanBytes, err := serializeC(unsafe.Pointer(&b.kalman), C.sizeof_KALMAN_STATUS)
	if err != nil {
		return nil, fmt.Errorf("dump kalman: %w", err)
	}
	return &Snapshot{
		MeasDB:       measBytes,
		NavDB:        navBytes,
		LosDB:        losBytes,
		ResidualDB:   residualBytes,
		KalmanStatus: kalmanBytes,
	}, nil
}

// LoadSnapshot restores all mutable C state from snap.
// After a successful load, the CBridge state is byte-for-byte identical to
// the state when DumpSnapshot was called.
func (b *CBridge) LoadSnapshot(snap *Snapshot) error {
	b.mu.Lock()
	defer b.mu.Unlock()
	if err := deserializeC(snap.MeasDB, unsafe.Pointer(&b.measDB), C.sizeof_MEASUREMENT_DATABASE); err != nil {
		return fmt.Errorf("load measDB: %w", err)
	}
	if err := deserializeC(snap.NavDB, unsafe.Pointer(&b.navDB), C.sizeof_NAVIGATION_DATABASE); err != nil {
		return fmt.Errorf("load navDB: %w", err)
	}
	if err := deserializeC(snap.LosDB, unsafe.Pointer(&b.losDB), C.sizeof_LOS_DATABASE); err != nil {
		return fmt.Errorf("load losDB: %w", err)
	}
	if err := deserializeC(snap.ResidualDB, unsafe.Pointer(&b.residualDB), C.sizeof_RESIDUAL_DATABASE); err != nil {
		return fmt.Errorf("load residualDB: %w", err)
	}
	if err := deserializeC(snap.KalmanStatus, unsafe.Pointer(&b.kalman), C.sizeof_KALMAN_STATUS); err != nil {
		return fmt.Errorf("load kalman: %w", err)
	}
	b.initialised = true
	return nil
}

// ─── C serialisation helpers ──────────────────────────────────────────────────

// serializeC copies size bytes from the C struct at ptr into a Go byte slice.
// The slice is a fresh allocation — it does not alias the C memory.
//
// C.GoBytes performs a real copy and handles platforms where Go's GC might
// move memory. C.int(size) is safe: C struct sizes never exceed MaxInt32.
func serializeC(ptr unsafe.Pointer, size C.size_t) ([]byte, error) {
	if ptr == nil {
		return nil, errors.New("serializeC: nil pointer")
	}
	// #nosec G103 — ptr points to a CBridge field; scope is bounded by mu.
	// #nosec G115 — C struct size always fits in C.int on supported platforms.
	buf := C.GoBytes(ptr, C.int(size))
	return buf, nil
}

// deserializeC copies len(data) bytes into the C struct at dst via C.memcpy.
// Returns an error when the payload length does not match the expected size.
func deserializeC(data []byte, dst unsafe.Pointer, size C.size_t) error {
	if uintptr(len(data)) != uintptr(size) {
		return fmt.Errorf("deserializeC: size mismatch: got %d want %d", len(data), int(size))
	}
	// #nosec G103 — dst is a CBridge field; data is caller-owned.
	C.memcpy(dst, unsafe.Pointer(&data[0]), size)
	return nil
}
