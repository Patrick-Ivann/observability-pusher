package core

/*
#cgo LDFLAGS: -L/usr/local/lib -lgnss_core
#include "gnss_core.h"
*/
import "C"
import (
	"github.com/yourorg/gnss-processor/internal/domain"
)

// ─── domain → C conversions ───────────────────────────────────────────────────
//
// Each helper takes a Go domain value and returns the equivalent C type.
// These functions are separate from c_bridge.go so they can be reviewed and
// tested independently of the full bridge lifecycle.

// domainMeasDataToCArray converts the two-slot Go MeasurementData array to the
// C MEASUREMENT_DATA[2] array expected by C.AddMeasurement.
//
// Slot mapping:
//
//	[0] → FNAV / L1B primary signal
//	[1] → INAV / E5A or E5B secondary signal
//
// Field mapping (Go → C):
//
//	Wavelength  → MEASUREMENT_DATA.wavelength
//	Phase       → MEASUREMENT_DATA.phase
//	CN0         → MEASUREMENT_DATA.cn0
//	PseudoRange → MEASUREMENT_DATA.pseudorange
func domainMeasDataToCArray(m [2]MeasurementData) [2]C.MEASUREMENT_DATA {
	var arr [2]C.MEASUREMENT_DATA
	for i := 0; i < 2; i++ {
		arr[i].wavelength = C.DOUBLE(m[i].Wavelength)
		arr[i].phase = C.DOUBLE(m[i].Phase)
		arr[i].cn0 = C.DOUBLE(m[i].CN0)
		arr[i].pseudorange = C.DOUBLE(m[i].PseudoRange)
	}
	return arr
}

// domainHealthToCArray converts the Go boolean health array to the C BOOLEAN
// array expected by C.RemoveUnhealthySat.
// Index i=true means SV slot i is healthy and should be retained.
func domainHealthToCArray(health [domain.MaxSV]bool) [domain.MaxSV]C.BOOLEAN {
	var arr [domain.MaxSV]C.BOOLEAN
	for i, h := range health {
		if h {
			arr[i] = 1
		}
	}
	return arr
}

// domainBoolToC converts a Go bool to the C BOOLEAN type (0 or 1).
func domainBoolToC(b bool) C.BOOLEAN {
	if b {
		return 1
	}
	return 0
}

// buildAvailArray derives the per-station availability array from the station
// network topology. A station is available when its status flag is non-zero.
// Stations beyond net.count are always marked unavailable.
func buildAvailArray(net C.STATION_NETWORK) [domain.MaxStations]C.BOOLEAN {
	var arr [domain.MaxStations]C.BOOLEAN
	count := int(net.count)
	if count > domain.MaxStations {
		count = domain.MaxStations
	}
	for i := 0; i < count; i++ {
		if net.status[i] != 0 {
			arr[i] = 1
		}
	}
	return arr
}

// ─── C → domain conversions ───────────────────────────────────────────────────

// mapCOutputToGo converts the C OUTPUT struct and associated RESIDUAL_DATABASE
// and KALMAN_STATUS to the Go ExecuteOutput.
//
// C OUTPUT field mapping (C → Go):
//
//	OUTPUT.clock_error[i]           → ClockError[i]
//	OUTPUT.orbit_error[i]           → OrbitError[i]
//	OUTPUT.sigma_mon[i]             → SigmaMon[i]
//	OUTPUT.wul_vector[i]            → WULVector[i]
//	OUTPUT.sis_ranging_error[i]     → SISRangingError[i]
//	OUTPUT.sis_error[i]             → SISError[i]
//	OUTPUT.confidence[i]            → Confidence[i]
//	OUTPUT.station_clock_synchro[s] → StationClockSynchro[s]
//
// KALMAN_STATUS field mapping:
//
//	KALMAN_STATUS.state[i]          → KalmanState[i]
//	KALMAN_STATUS.iod[i]            → IOD[i]
//
// RESIDUAL_DATABASE field mapping (indexed [station][sv]):
//
//	RESIDUAL_DATABASE.residual[s][v]   → ResidualTemporal[s][v]
//	RESIDUAL_DATABASE.cycle_slip[s][v] → CycleSlipFlag[s][v]
func mapCOutputToGo(o *C.OUTPUT, res *C.RESIDUAL_DATABASE, kal *C.KALMAN_STATUS) *ExecuteOutput {
	out := &ExecuteOutput{}

	// ── Per-satellite integrity outputs ──────────────────────────────────
	for i := 0; i < domain.MaxSV; i++ {
		out.ClockError[i] = float64(o.clock_error[i])
		out.OrbitError[i] = float64(o.orbit_error[i])
		out.SigmaMon[i] = float64(o.sigma_mon[i])
		out.WULVector[i] = float64(o.wul_vector[i])
		out.SISRangingError[i] = float64(o.sis_ranging_error[i])
		out.SISError[i] = float64(o.sis_error[i])
		out.Confidence[i] = float64(o.confidence[i])
	}

	// ── Kalman filter state and IOD (per satellite) ───────────────────────
	for i := 0; i < domain.MaxSV; i++ {
		out.KalmanState[i] = int32(kal.state[i])
		out.IOD[i] = int32(kal.iod[i])
	}

	// ── Per-station clock synchronisation ────────────────────────────────
	for s := 0; s < domain.MaxStations; s++ {
		out.StationClockSynchro[s] = float64(o.station_clock_synchro[s])
	}

	// ── Per-LoS residuals and cycle-slip flags ────────────────────────────
	for s := 0; s < domain.MaxStations; s++ {
		for v := 0; v < domain.MaxSV; v++ {
			out.ResidualTemporal[s][v] = float64(res.residual[s][v])
			out.CycleSlipFlag[s][v] = res.cycle_slip[s][v] != 0
		}
	}

	return out
}

// ─── domain.MessageInput → AddMeasurementParams ───────────────────────────────

// DomainMsgToAddParams converts a matched signal pair to the AddMeasurementParams
// expected by GNSSCore.AddMeasurement.
//
// This helper is the single source of truth for the field mapping between
// domain.MessageMeasurement and core.MeasurementData so both the real CBridge
// and the FakeCore used in tests apply identical semantics.
//
// stationIdx must be resolved from the station registry before calling.
//
// Channel mapping:
//
//	primary  (L1B)  → MeasData[0]   FNAV slot
//	secondary(E5A/B)→ MeasData[1]   INAV slot; SecMeas=true when present
func DomainMsgToAddParams(
	primary *domain.MessageMeasurement,
	secondary *domain.MessageMeasurement,
	sv int32,
	epoch int64,
	stationIdx uint16,
) AddMeasurementParams {
	p := AddMeasurementParams{
		StationID:   stationIdx,
		SatelliteID: uint16(sv),
		Epoch:       uint64(epoch),
		SecMeas:     secondary != nil,
	}
	if primary != nil {
		p.MeasData[0] = MeasurementData{
			Phase:       float64(primary.CodePhase),
			CN0:         float64(primary.SignalCtoN),
			PseudoRange: float64(primary.AccDoppler),
		}
	}
	if secondary != nil {
		p.MeasData[1] = MeasurementData{
			Phase:       float64(secondary.CodePhase),
			CN0:         float64(secondary.SignalCtoN),
			PseudoRange: float64(secondary.AccDoppler),
		}
	}
	return p
}
