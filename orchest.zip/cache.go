package cache

import (
	"context"
	"fmt"
	"time"

	"github.com/redis/go-redis/v9"
)

// CacheManager is the interface all cache access goes through.
// No direct redis.Client calls escape this boundary — everything is testable
// via a map-backed stub without a running Redis.
//
//go:generate mockery --name=CacheManager --output=../mocks --outpkg=mocks
type CacheManager interface {
	// Set stores value at key with the given TTL. TTL=0 means no expiry.
	Set(key, value string, ttl time.Duration) error
	// Get retrieves the value at key. Returns ErrCacheMiss if not found.
	Get(key string) (string, error)
	// GetAll returns all key→value pairs whose keys match the glob pattern.
	// Uses SCAN to avoid blocking the server on large key spaces.
	GetAll(pattern string) (map[string]string, error)
	// IsExists reports whether key is present in the cache.
	IsExists(key string) (bool, error)
	// Delete removes the key. No-op if not present.
	Delete(key string) error
}

// ErrCacheMiss is returned by Get when the key does not exist.
var ErrCacheMiss = fmt.Errorf("cache miss")

// ─── RedisCacheManager ────────────────────────────────────────────────────────

// RedisCacheManager is a CacheManager backed by a Redis client.
// All methods use context.Background() internally — add ctx variants if needed.
type RedisCacheManager struct {
	client *redis.Client
}

// NewRedisCacheManager wraps client in a CacheManager.
func NewRedisCacheManager(client *redis.Client) *RedisCacheManager {
	return &RedisCacheManager{client: client}
}

// Set stores value at key. TTL=0 means no expiry.
func (m *RedisCacheManager) Set(key, value string, ttl time.Duration) error {
	if err := m.client.Set(context.Background(), key, value, ttl).Err(); err != nil {
		return fmt.Errorf("cache set %q: %w", key, err)
	}
	return nil
}

// Get retrieves the value at key. Returns ErrCacheMiss when the key is absent.
func (m *RedisCacheManager) Get(key string) (string, error) {
	val, err := m.client.Get(context.Background(), key).Result()
	if err == redis.Nil {
		return "", ErrCacheMiss
	}
	if err != nil {
		return "", fmt.Errorf("cache get %q: %w", key, err)
	}
	return val, nil
}

// GetAll returns all key→value pairs whose keys match the glob pattern.
// Uses SCAN to avoid blocking Redis on large key spaces.
func (m *RedisCacheManager) GetAll(pattern string) (map[string]string, error) {
	ctx := context.Background()
	var keys []string
	iter := m.client.Scan(ctx, 0, pattern, 0).Iterator()
	for iter.Next(ctx) {
		keys = append(keys, iter.Val())
	}
	if err := iter.Err(); err != nil {
		return nil, fmt.Errorf("cache scan %q: %w", pattern, err)
	}
	if len(keys) == 0 {
		return map[string]string{}, nil
	}
	vals, err := m.client.MGet(ctx, keys...).Result()
	if err != nil {
		return nil, fmt.Errorf("cache mget: %w", err)
	}
	result := make(map[string]string, len(keys))
	for i, k := range keys {
		if vals[i] != nil {
			result[k] = fmt.Sprint(vals[i])
		}
	}
	return result, nil
}

// IsExists reports whether key is present.
func (m *RedisCacheManager) IsExists(key string) (bool, error) {
	n, err := m.client.Exists(context.Background(), key).Result()
	if err != nil {
		return false, fmt.Errorf("cache exists %q: %w", key, err)
	}
	return n > 0, nil
}

// Delete removes the key. No-op if not present.
func (m *RedisCacheManager) Delete(key string) error {
	if err := m.client.Del(context.Background(), key).Err(); err != nil {
		return fmt.Errorf("cache delete %q: %w", key, err)
	}
	return nil
}
