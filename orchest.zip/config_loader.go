package config

import (
	"context"
	"fmt"
	"log/slog"
	"time"

	"github.com/yourorg/gnss-processor/internal/cache"
	"github.com/yourorg/gnss-processor/internal/domain"
)

// RemoteConfig holds all parameters that can be updated at runtime via the
// cache without a service restart.
//
// Values are loaded:
//   - Once at startup via LoadRemoteConfig.
//   - After every successful Execute() (epoch-done hook) to pick up any
//     parameter changes that took effect during the epoch.
//   - Immediately when the instance loses leader election, so a newly-promoted
//     leader always starts with fresh config.
type RemoteConfig struct {
	// GSSReadinessRatio overrides the static value from AppConfig when non-zero.
	GSSReadinessRatio float64
	// PPStep overrides the static value when > 0.
	PPStep int64
	// ExecuteStep overrides the static value when > 0.
	ExecuteStep int64
	// SVBlacklist lists SVIDs that must be treated as unhealthy regardless of
	// the SV mask XML, e.g. for operational NOTAMs received after deployment.
	SVBlacklist []int32
}

// cacheKeys used for RemoteConfig values.
const (
	CacheKeyGSSRatio    = "gnss:config:gss_readiness_ratio"
	CacheKeyPPStep      = "gnss:config:pp_step"
	CacheKeyExecuteStep = "gnss:config:execute_step"
	CacheKeySVBlacklist = "gnss:config:sv_blacklist"
)

// ConfigLoader loads RemoteConfig from the cache and applies it to the running
// orchestrator. It is stateless — callers decide when to invoke Reload.
type ConfigLoader struct {
	cache cache.CacheManager
	log   *slog.Logger
}

// NewConfigLoader creates a loader backed by the given CacheManager.
func NewConfigLoader(c cache.CacheManager, log *slog.Logger) *ConfigLoader {
	return &ConfigLoader{cache: c, log: log}
}

// Reload reads all remote-config keys from the cache and returns the current
// RemoteConfig. Missing keys are silently skipped (zero value preserved).
// Reload is safe to call from any goroutine.
func (l *ConfigLoader) Reload(_ context.Context) RemoteConfig {
	var cfg RemoteConfig

	if v, err := l.cache.Get(CacheKeyGSSRatio); err == nil {
		if f := parseFloat(v); f > 0 {
			cfg.GSSReadinessRatio = f
		}
	}
	if v, err := l.cache.Get(CacheKeyPPStep); err == nil {
		if n := parseInt64(v); n > 0 {
			cfg.PPStep = n
		}
	}
	if v, err := l.cache.Get(CacheKeyExecuteStep); err == nil {
		if n := parseInt64(v); n > 0 {
			cfg.ExecuteStep = n
		}
	}
	// SVBlacklist is a JSON-encoded []int32 stored under a single key.
	if v, err := l.cache.Get(CacheKeySVBlacklist); err == nil {
		cfg.SVBlacklist = parseSVBlacklist(v)
	}
	return cfg
}

// WatchAndReload polls the cache every interval and calls onReload whenever
// any remote-config value has changed. Blocks until ctx is cancelled.
//
// This covers the "non-leader" path: a standby instance calls WatchAndReload
// so it has fresh config if it is promoted to leader.
func (l *ConfigLoader) WatchAndReload(ctx context.Context, interval time.Duration, onReload func(RemoteConfig)) {
	ticker := time.NewTicker(interval)
	defer ticker.Stop()
	for {
		select {
		case <-ctx.Done():
			return
		case <-ticker.C:
			cfg := l.Reload(ctx)
			onReload(cfg)
			l.log.Debug("remote config reloaded",
				"gss_ratio", cfg.GSSReadinessRatio,
				"pp_step", cfg.PPStep,
				"execute_step", cfg.ExecuteStep)
		}
	}
}

// ApplyToMask merges cfg.SVBlacklist into mask by marking those SVs unhealthy.
// Returns a new mask — the original is not mutated.
func ApplyToMask(mask *domain.SVMask, cfg RemoteConfig) *domain.SVMask {
	if len(cfg.SVBlacklist) == 0 {
		return mask
	}
	merged := &domain.SVMask{Satellites: make(map[int32]domain.SVHealth, len(mask.Satellites))}
	for k, v := range mask.Satellites {
		merged.Satellites[k] = v
	}
	for _, svid := range cfg.SVBlacklist {
		merged.Satellites[svid] = domain.SVHealth{SVID: svid, Status: 1} // unhealthy
	}
	return merged
}

// ─── parsing helpers (no external deps) ─────────────────────────────────────

func parseFloat(s string) float64 {
	var f float64
	if _, err := fmt.Sscanf(s, "%f", &f); err != nil {
		return 0
	}
	return f
}

func parseInt64(s string) int64 {
	var n int64
	if _, err := fmt.Sscanf(s, "%d", &n); err != nil {
		return 0
	}
	return n
}

func parseSVBlacklist(s string) []int32 {
	// Format: "1,3,7,22"
	if s == "" {
		return nil
	}
	var svids []int32
	for len(s) > 0 {
		var n int32
		var consumed int
		if _, err := fmt.Sscanf(s, "%d%n", &n, &consumed); err != nil {
			break
		}
		svids = append(svids, n)
		if consumed >= len(s) {
			break
		}
		s = s[consumed:]
		// skip separator
		for len(s) > 0 && (s[0] == ',' || s[0] == ' ') {
			s = s[1:]
		}
	}
	return svids
}
