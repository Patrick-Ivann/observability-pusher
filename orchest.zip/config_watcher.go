package config

import (
	"context"
	"encoding/xml"
	"fmt"
	"os"
	"time"

	"github.com/yourorg/gnss-processor/internal/domain"
)

// SVMaskXML is the XML representation of the SV mask.
type SVMaskXML struct {
	XMLName    xml.Name     `xml:"SVMask"`
	Satellites []SVEntryXML `xml:"Satellite"`
}

// SVEntryXML is one satellite entry in the mask XML.
type SVEntryXML struct {
	SVID   int32 `xml:"svid,attr"`
	Status int32 `xml:"health,attr"`
}

// ParseSVMask reads and parses the SV mask XML file at path.
// path must originate from operator-controlled configuration.
func ParseSVMask(path string) (*domain.SVMask, error) {
	data, err := os.ReadFile(path) // #nosec G304 — path is from trusted operator config
	if err != nil {
		return nil, fmt.Errorf("read mask: %w", err)
	}
	return parseSVMaskBytes(data)
}

func parseSVMaskBytes(data []byte) (*domain.SVMask, error) {
	var raw SVMaskXML
	if err := xml.Unmarshal(data, &raw); err != nil {
		return nil, fmt.Errorf("unmarshal mask: %w", err)
	}
	mask := &domain.SVMask{Satellites: make(map[int32]domain.SVHealth, len(raw.Satellites))}
	for _, s := range raw.Satellites {
		mask.Satellites[s.SVID] = domain.SVHealth{SVID: s.SVID, Status: s.Status}
	}
	return mask, nil
}

// MaskWatcher polls the mask file and notifies on changes via a channel.
type MaskWatcher struct {
	path     string
	interval time.Duration
	updates  chan *domain.SVMask
	lastMod  time.Time
}

// NewMaskWatcher creates a watcher that polls every interval.
func NewMaskWatcher(path string, interval time.Duration) *MaskWatcher {
	return &MaskWatcher{
		path:     path,
		interval: interval,
		updates:  make(chan *domain.SVMask, 1),
	}
}

// Updates returns the channel that receives new masks on file change.
func (w *MaskWatcher) Updates() <-chan *domain.SVMask {
	return w.updates
}

// Run starts the polling loop. Blocks until ctx is cancelled.
func (w *MaskWatcher) Run(ctx context.Context) {
	ticker := time.NewTicker(w.interval)
	defer ticker.Stop()
	for {
		select {
		case <-ctx.Done():
			return
		case <-ticker.C:
			w.checkAndEmit()
		}
	}
}

func (w *MaskWatcher) checkAndEmit() {
	info, err := os.Stat(w.path)
	if err != nil || !info.ModTime().After(w.lastMod) {
		return
	}
	mask, err := ParseSVMask(w.path)
	if err != nil {
		return
	}
	w.lastMod = info.ModTime()
	select {
	case w.updates <- mask:
	default: // drop if consumer is slow
	}
}
