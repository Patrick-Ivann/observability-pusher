package config

import (
	"context"
	"os"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

const validMaskXML = `<SVMask>
  <Satellite svid="1" health="0"/>
  <Satellite svid="2" health="1"/>
  <Satellite svid="3" health="0"/>
</SVMask>`

func TestParseSVMask_ValidXML(t *testing.T) {
	mask, err := parseSVMaskBytes([]byte(validMaskXML))
	require.NoError(t, err)
	require.NotNil(t, mask)
	assert.Len(t, mask.Satellites, 3)
	assert.True(t, mask.IsHealthy(1))
	assert.False(t, mask.IsHealthy(2)) // status = 1 → unhealthy
	assert.True(t, mask.IsHealthy(3))
}

func TestParseSVMask_UnknownSVUnhealthy(t *testing.T) {
	mask, _ := parseSVMaskBytes([]byte(validMaskXML))
	assert.False(t, mask.IsHealthy(99))
}

func TestParseSVMask_InvalidXML(t *testing.T) {
	_, err := parseSVMaskBytes([]byte("not-xml"))
	assert.Error(t, err)
}

func TestMaskWatcher_EmitsOnFileChange(t *testing.T) {
	f, err := os.CreateTemp(t.TempDir(), "mask*.xml")
	require.NoError(t, err)
	_, err = f.WriteString(validMaskXML)
	require.NoError(t, err)
	require.NoError(t, f.Close())

	w := NewMaskWatcher(f.Name(), 20*time.Millisecond)
	ctx, cancel := context.WithTimeout(context.Background(), 500*time.Millisecond)
	defer cancel()
	go w.Run(ctx)

	// Modify the file to trigger the watcher.
	time.Sleep(30 * time.Millisecond)
	require.NoError(t, os.WriteFile(f.Name(), []byte(validMaskXML), 0o600))

	select {
	case mask := <-w.Updates():
		assert.NotNil(t, mask)
	case <-ctx.Done():
		t.Fatal("expected mask update, got timeout")
	}
}
