// Package bench provides benchmarks that measure:
//
//  1. The cost of each C-bridge method in isolation — using a NoopCore that
//     returns immediately, so the number represents pure Go→C dispatch overhead
//     when swapped for the real CBridge.
//
//  2. The Go-side orchestration overhead (mask check, pair buffer, mutex,
//     epoch window) independently of the C library.
//
//  3. Realistic epoch scenarios at varying scales (SVs × GSS stations).
//
//  4. Snapshot serialisation/deserialisation cost (FileStore round-trip).
//
// How to interpret results
// ────────────────────────
// Run with the FakeCore (default, no CGo needed):
//
//	go test ./test/bench/... -bench=. -benchmem -benchtime=5s
//
// Run with the real CBridge (requires the .so):
//
//	CGO_ENABLED=1 go test ./test/bench/... -bench=. -benchmem -benchtime=5s \
//	    -tags=real_cbridge
//
// Diff the ns/op between the two runs for each BenchmarkCore_* function.
// The delta is the actual C library cost per call.
//
// Sub-benchmark naming convention:
//
//	BenchmarkCore_<Method>           — raw method cost
//	BenchmarkOrch_<Scenario>         — orchestration overhead
//	BenchmarkPipeline_<Scale>        — full epoch pipeline end-to-end
//	BenchmarkSnapshot_<Operation>    — snapshot I/O cost
package bench

import (
	"context"
	"fmt"
	"io"
	"log/slog"
	"testing"

	"github.com/yourorg/gnss-processor/internal/alert"
	"github.com/yourorg/gnss-processor/internal/core"
	"github.com/yourorg/gnss-processor/internal/domain"
	"github.com/yourorg/gnss-processor/internal/orchestrator"
	"github.com/yourorg/gnss-processor/internal/snapshot"
)

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// NoopCore — zero-overhead baseline for Go→C call isolation
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

// NoopCore implements GNSSCore with bodies that do absolutely nothing.
// Benchmarks using NoopCore measure only:
//   - Go function call dispatch
//   - Interface method resolution
//   - Argument passing / struct copy
//
// Subtracting NoopCore ns/op from real CBridge ns/op gives net C library cost.
type NoopCore struct{}

func (NoopCore) InitMeasurementDatabase() error                             { return nil }
func (NoopCore) AddMeasurement(_ core.AddMeasurementParams) error           { return nil }
func (NoopCore) RemoveUnhealthySat(_ [domain.MaxSV]bool, _ int64) error     { return nil }
func (NoopCore) ComputeStationPositions(_ float64) error                    { return nil }
func (NoopCore) PP(_ int64) error                                           { return nil }
func (NoopCore) Execute(_ int64) (*core.ExecuteOutput, error)               { return &core.ExecuteOutput{}, nil }
func (NoopCore) LoadSnapshot(_ *core.Snapshot) error                        { return nil }
func (NoopCore) DumpSnapshot() (*core.Snapshot, error)                      { return &core.Snapshot{}, nil }

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// CountingCore — NoopCore that counts calls, used to verify b.N iterations
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

type CountingCore struct {
	NoopCore
	AddMeasurementCalls int
	PPCalls             int
	ExecuteCalls        int
}

func (c *CountingCore) AddMeasurement(p core.AddMeasurementParams) error {
	c.AddMeasurementCalls++
	return nil
}
func (c *CountingCore) PP(_ int64) error {
	c.PPCalls++
	return nil
}
func (c *CountingCore) Execute(_ int64) (*core.ExecuteOutput, error) {
	c.ExecuteCalls++
	return &core.ExecuteOutput{}, nil
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// Noop Publisher / Alerter / SnapStore for pipeline benchmarks
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

type noopPublisher struct{}

func (noopPublisher) Publish(_ context.Context, _ domain.EpochResult) error { return nil }

type noopAlerter struct{}

func (noopAlerter) Alert(_ context.Context, _ alert.AlertKind, _ string) {}

// noopStore discards snapshots — removes FileStore I/O from pipeline benchmarks
// so we measure pure compute cost. See BenchmarkSnapshot_* for I/O cost.
type noopStore struct{}

func (noopStore) Save(_ context.Context, _ *core.Snapshot) error      { return nil }
func (noopStore) Load(_ context.Context) (*core.Snapshot, error)       { return nil, nil }
func (noopStore) LatestEpoch(_ context.Context) (int64, error)         { return 0, nil }

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// Shared fixtures
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

var (
	nullLog = slog.New(slog.NewTextHandler(io.Discard, nil))
	benchCtx = context.Background()
)

// fullMask returns a mask with all SVs 1..n healthy.
func fullMask(n int) *domain.SVMask {
	m := &domain.SVMask{Satellites: make(map[int32]domain.SVHealth, n)}
	for i := 1; i <= n; i++ {
		m.Satellites[int32(i)] = domain.SVHealth{SVID: int32(i), Status: 0}
	}
	return m
}

// baseParams builds a canonical AddMeasurementParams for benchmarks.
func baseParams(sv uint16, epoch uint64) core.AddMeasurementParams {
	return core.AddMeasurementParams{
		StationID:   0,
		SatelliteID: sv,
		Epoch:       epoch,
		SecMeas:     true,
		MeasData: [domain.NumServices]core.MeasurementData{
			{Wavelength: 0.19, Phase: 1234.5, CN0: 42.0, PseudoRange: 20_200_000.0},
			{Wavelength: 0.25, Phase: 5678.9, CN0: 38.5, PseudoRange: 20_200_100.0},
		},
	}
}

// l1bMsg / e5aMsg build matching message pairs for HandleMessage benchmarks.
func l1bMsg(sv int32, gss string, epoch int64) domain.MessageInput {
	return domain.MessageInput{
		Sv: sv, GSSId: gss, Epoch: epoch,
		Measurement: domain.MessageMeasurement{
			ChannelId: domain.ChannelL1B, SignalCtoN: 42, CodePhase: 0.1,
		},
		ShsDvs: domain.ShsDvsMessage{SignalHealthStatus: 0, DataValidityStatus: true},
	}
}

func e5aMsg(sv int32, gss string, epoch int64) domain.MessageInput {
	m := l1bMsg(sv, gss, epoch)
	m.Measurement.ChannelId = domain.ChannelE5A
	return m
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
//
// GROUP 1: C method isolation — raw per-call cost
//
// These use NoopCore so the reported ns/op is the cost of:
//   - Go interface dispatch
//   - argument struct copy (important: AddMeasurementParams is 72 bytes)
//   - any bookkeeping added by the real CBridge (mutex, cgo runtime park/resume)
//
// When you swap NoopCore for the real CBridge, the delta in ns/op is
// the pure C library execution cost for that function.
//
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

// BenchmarkCore_AddMeasurement measures the per-call cost of AddMeasurement.
// AddMeasurementParams is 72 bytes — important to see if the struct copy matters.
func BenchmarkCore_AddMeasurement(b *testing.B) {
	var c core.GNSSCore = NoopCore{}
	p := baseParams(1, 1000)
	b.ResetTimer()
	b.ReportAllocs()
	for i := 0; i < b.N; i++ {
		_ = c.AddMeasurement(p)
	}
}

// BenchmarkCore_AddMeasurement_AllSVs sweeps all 36 SV slots per iteration,
// mirroring a full epoch where every satellite sends a measurement.
func BenchmarkCore_AddMeasurement_AllSVs(b *testing.B) {
	var c core.GNSSCore = NoopCore{}
	params := make([]core.AddMeasurementParams, domain.MaxSV)
	for i := range params {
		params[i] = baseParams(uint16(i), 1000)
	}
	b.ResetTimer()
	b.ReportAllocs()
	for i := 0; i < b.N; i++ {
		for _, p := range params {
			_ = c.AddMeasurement(p)
		}
	}
}

// BenchmarkCore_PP measures the per-call cost of PP().
// In production PP is called once per completed SV pair — could be up to
// 36×40 = 1440 times per epoch if all SVs × stations are visible.
func BenchmarkCore_PP(b *testing.B) {
	var c core.GNSSCore = NoopCore{}
	b.ResetTimer()
	b.ReportAllocs()
	for i := 0; i < b.N; i++ {
		_ = c.PP(1000)
	}
}

// BenchmarkCore_Execute measures the Kalman/integrity computation cost.
// Execute is called once per minute — but its cost determines whether the
// 60-second window is tight or comfortable.
func BenchmarkCore_Execute(b *testing.B) {
	var c core.GNSSCore = NoopCore{}
	b.ResetTimer()
	b.ReportAllocs()
	for i := 0; i < b.N; i++ {
		_, _ = c.Execute(1000)
	}
}

// BenchmarkCore_RemoveUnhealthySat measures the health-sweep cost.
// The [36]bool health array is passed by value — this benchmark
// also validates that the 36-byte copy is not a bottleneck.
func BenchmarkCore_RemoveUnhealthySat(b *testing.B) {
	var c core.GNSSCore = NoopCore{}
	var health [domain.MaxSV]bool
	for i := range health {
		health[i] = true
	}
	b.ResetTimer()
	b.ReportAllocs()
	for i := 0; i < b.N; i++ {
		_ = c.RemoveUnhealthySat(health, 1000)
	}
}

// BenchmarkCore_ComputeStationPositions measures ECEF position computation.
func BenchmarkCore_ComputeStationPositions(b *testing.B) {
	var c core.GNSSCore = NoopCore{}
	b.ResetTimer()
	b.ReportAllocs()
	for i := 0; i < b.N; i++ {
		_ = c.ComputeStationPositions(1000.0)
	}
}

// BenchmarkCore_DumpSnapshot measures snapshot serialisation.
// The real CBridge does a memcpy of several large C structs — this is a
// potential bottleneck on fast epoch-close paths.
func BenchmarkCore_DumpSnapshot(b *testing.B) {
	var c core.GNSSCore = NoopCore{}
	b.ResetTimer()
	b.ReportAllocs()
	for i := 0; i < b.N; i++ {
		_, _ = c.DumpSnapshot()
	}
}

// BenchmarkCore_LoadSnapshot measures snapshot deserialisation.
func BenchmarkCore_LoadSnapshot(b *testing.B) {
	var c core.GNSSCore = NoopCore{}
	snap := &core.Snapshot{
		MeasDB:       make([]byte, 4096),
		KalmanStatus: make([]byte, 4096),
		LosDB:        make([]byte, 8192),
		ResidualDB:   make([]byte, 2048),
	}
	b.ResetTimer()
	b.ReportAllocs()
	for i := 0; i < b.N; i++ {
		_ = c.LoadSnapshot(snap)
	}
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
//
// GROUP 2: Go orchestration overhead
//
// These benchmarks keep NoopCore but measure the Go-side work:
//   - SVMask.IsHealthy (map lookup)
//   - PairBuffer.Add (mutex + map insert/delete)
//   - EpochWindow create / RecordSV / IsFinalized
//   - HandleMessage full path (validate + mask + pair + core dispatch)
//
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

// BenchmarkOrch_MaskLookup_Hit benchmarks a healthy SV lookup (the common path).
func BenchmarkOrch_MaskLookup_Hit(b *testing.B) {
	mask := fullMask(36)
	b.ResetTimer()
	b.ReportAllocs()
	for i := 0; i < b.N; i++ {
		_ = mask.IsHealthy(18) // middle of the map — average case
	}
}

// BenchmarkOrch_MaskLookup_Miss benchmarks a missing SV lookup (filter path).
func BenchmarkOrch_MaskLookup_Miss(b *testing.B) {
	mask := fullMask(36)
	b.ResetTimer()
	b.ReportAllocs()
	for i := 0; i < b.N; i++ {
		_ = mask.IsHealthy(99) // not in map
	}
}

// BenchmarkOrch_PairBuffer_L1B_Only benchmarks the half-pair (L1B arrives, no emit).
// This is the dominant case — every message incurs this cost before pairing.
func BenchmarkOrch_PairBuffer_L1B_Only(b *testing.B) {
	buf := orchestrator.NewPairBuffer()
	msg := l1bMsg(1, "GSS1", 1000)
	b.ResetTimer()
	b.ReportAllocs()
	for i := 0; i < b.N; i++ {
		// Use a unique epoch each iteration to keep the buffer from accumulating.
		msg.Epoch = int64(i + 1)
		_, _ = buf.Add(msg)
	}
}

// BenchmarkOrch_PairBuffer_Complete benchmarks the full pair completion path:
// L1B insert (no emit) + E5A insert (emits params). This is called once per
// SV pair per epoch.
func BenchmarkOrch_PairBuffer_Complete(b *testing.B) {
	buf := orchestrator.NewPairBuffer()
	b.ResetTimer()
	b.ReportAllocs()
	for i := 0; i < b.N; i++ {
		epoch := int64(i + 1)
		l1b := l1bMsg(1, "GSS1", epoch)
		e5a := e5aMsg(1, "GSS1", epoch)
		_, _ = buf.Add(l1b)
		_, _ = buf.Add(e5a)
	}
}

// BenchmarkOrch_HandleMessage_Filtered benchmarks the fast rejection path —
// message fails the mask check immediately.
func BenchmarkOrch_HandleMessage_Filtered(b *testing.B) {
	orch := orchestrator.NewOrchestrator(
		NoopCore{}, fullMask(1), // only SV1 — SV99 will be filtered
		nil, noopStore{}, noopPublisher{}, noopAlerter{},
		nil, orchestrator.ServiceLaneConfig{PPStep: 1, ExecuteStep: 60, GSSReadinessRatio: 0}, nil, nullLog,
	)
	msg := l1bMsg(99, "GSS1", 1000) // SV99 not in mask
	b.ResetTimer()
	b.ReportAllocs()
	for i := 0; i < b.N; i++ {
		_ = orch.HandleMessage(benchCtx, msg)
	}
}

// BenchmarkOrch_HandleMessage_L1B benchmarks handling the first signal of a
// pair (mask passes, pair buffer stores but does not emit — no C call).
func BenchmarkOrch_HandleMessage_L1B(b *testing.B) {
	orch := orchestrator.NewOrchestrator(
		NoopCore{}, fullMask(36),
		nil, noopStore{}, noopPublisher{}, noopAlerter{},
		nil, orchestrator.ServiceLaneConfig{PPStep: 1, ExecuteStep: 60, GSSReadinessRatio: 0}, nil, nullLog,
	)
	b.ResetTimer()
	b.ReportAllocs()
	for i := 0; i < b.N; i++ {
		msg := l1bMsg(1, "GSS1", int64(i+1)) // unique epoch to keep buffer clean
		_ = orch.HandleMessage(benchCtx, msg)
	}
}

// BenchmarkOrch_HandleMessage_Pair benchmarks the complete pair path:
// L1B arrives → stored. E5A arrives → pair complete → AddMeasurement + PP.
// This is the steady-state hot path for every SV on every epoch.
func BenchmarkOrch_HandleMessage_Pair(b *testing.B) {
	orch := orchestrator.NewOrchestrator(
		NoopCore{}, fullMask(36),
		nil, noopStore{}, noopPublisher{}, noopAlerter{},
		nil, orchestrator.ServiceLaneConfig{PPStep: 1, ExecuteStep: 60, GSSReadinessRatio: 0}, nil, nullLog,
	)
	b.ResetTimer()
	b.ReportAllocs()
	for i := 0; i < b.N; i++ {
		epoch := int64(i + 1)
		_ = orch.HandleMessage(benchCtx, l1bMsg(1, "GSS1", epoch))
		_ = orch.HandleMessage(benchCtx, e5aMsg(1, "GSS1", epoch))
	}
}

// BenchmarkOrch_EpochWindow_RecordSV benchmarks the epoch window mutex hot path.
func BenchmarkOrch_EpochWindow_RecordSV(b *testing.B) {
	w := orchestrator.NewEpochWindow(1000)
	b.ResetTimer()
	b.ReportAllocs()
	for i := 0; i < b.N; i++ {
		w.RecordSV(int32(i % domain.MaxSV))
	}
}

// BenchmarkOrch_EpochWindow_IsFinalized benchmarks the finalized check,
// called on every message for an open epoch.
func BenchmarkOrch_EpochWindow_IsFinalized(b *testing.B) {
	w := orchestrator.NewEpochWindow(1000)
	b.ResetTimer()
	b.ReportAllocs()
	for i := 0; i < b.N; i++ {
		_ = w.IsFinalized()
	}
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
//
// GROUP 3: Full epoch pipeline at varying scale
//
// These benchmarks drive the entire orchestrator for one epoch with different
// numbers of SVs and stations, then close the epoch. They answer the question:
// "how long does one complete epoch take end-to-end as scale grows?"
//
// The -benchtime flag controls how many epochs are processed (b.N iterations).
//
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

// epochScenario defines a pipeline benchmark scenario.
type epochScenario struct {
	svCount      int
	stationCount int
}

// benchmarkEpochPipeline runs one complete epoch (all pairs + ForceExecute)
// for the given scale, b.N times. b.N is controlled by -benchtime.
func benchmarkEpochPipeline(b *testing.B, sc epochScenario) {
	b.Helper()
	cc := &CountingCore{}
	orch := orchestrator.NewOrchestrator(
		cc, fullMask(sc.svCount),
		nil, noopStore{}, noopPublisher{}, noopAlerter{},
		nil, orchestrator.ServiceLaneConfig{PPStep: 1, ExecuteStep: 60, GSSReadinessRatio: 0}, nil, nullLog,
	)
	svs := make([]int32, sc.svCount)
	for i := range svs {
		svs[i] = int32(i + 1)
	}
	stations := make([]string, sc.stationCount)
	for i := range stations {
		stations[i] = fmt.Sprintf("GSS%d", i+1)
	}

	b.ResetTimer()
	b.ReportAllocs()

	for i := 0; i < b.N; i++ {
		epoch := int64(i + 1)
		// Send all pairs for this epoch.
		for _, gss := range stations {
			for _, sv := range svs {
				_ = orch.HandleMessage(benchCtx, l1bMsg(sv, gss, epoch))
				_ = orch.HandleMessage(benchCtx, e5aMsg(sv, gss, epoch))
			}
		}
		// Close the epoch — triggers RemoveUnhealthySat, ComputeStationPositions, Execute.
		_ = orch.ForceExecute(benchCtx, epoch)
	}

	// Sanity — prevent the compiler from optimising away the core calls.
	b.ReportMetric(float64(cc.AddMeasurementCalls)/float64(b.N), "add/epoch")
	b.ReportMetric(float64(cc.PPCalls)/float64(b.N), "pp/epoch")
	b.ReportMetric(float64(cc.ExecuteCalls)/float64(b.N), "exec/epoch")
}

// BenchmarkPipeline_1SV_1GSS — smallest possible epoch (one satellite, one station).
func BenchmarkPipeline_1SV_1GSS(b *testing.B) {
	benchmarkEpochPipeline(b, epochScenario{svCount: 1, stationCount: 1})
}

// BenchmarkPipeline_8SV_1GSS — typical partial constellation view from one station.
func BenchmarkPipeline_8SV_1GSS(b *testing.B) {
	benchmarkEpochPipeline(b, epochScenario{svCount: 8, stationCount: 1})
}

// BenchmarkPipeline_36SV_1GSS — full constellation, single station.
func BenchmarkPipeline_36SV_1GSS(b *testing.B) {
	benchmarkEpochPipeline(b, epochScenario{svCount: 36, stationCount: 1})
}

// BenchmarkPipeline_8SV_5GSS — partial constellation, 5 GSS stations.
func BenchmarkPipeline_8SV_5GSS(b *testing.B) {
	benchmarkEpochPipeline(b, epochScenario{svCount: 8, stationCount: 5})
}

// BenchmarkPipeline_36SV_10GSS — full constellation, 10 stations (nominal network).
func BenchmarkPipeline_36SV_10GSS(b *testing.B) {
	benchmarkEpochPipeline(b, epochScenario{svCount: 36, stationCount: 10})
}

// BenchmarkPipeline_36SV_40GSS — worst case: full constellation, all 40 stations.
func BenchmarkPipeline_36SV_40GSS(b *testing.B) {
	benchmarkEpochPipeline(b, epochScenario{svCount: 36, stationCount: 40})
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
//
// GROUP 4: Pair buffer at scale
//
// Isolates just the PairBuffer cost as message volume grows, without the
// orchestrator or core in the loop. This quantifies how much of the pipeline
// cost is attributable purely to signal pairing bookkeeping.
//
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

func benchmarkPairBuffer(b *testing.B, svCount, stationCount int) {
	b.Helper()
	svs := make([]int32, svCount)
	for i := range svs {
		svs[i] = int32(i + 1)
	}
	stations := make([]string, stationCount)
	for i := range stations {
		stations[i] = fmt.Sprintf("GSS%d", i+1)
	}

	b.ResetTimer()
	b.ReportAllocs()

	for i := 0; i < b.N; i++ {
		buf := orchestrator.NewPairBuffer()
		epoch := int64(i + 1)
		for _, gss := range stations {
			for _, sv := range svs {
				_, _ = buf.Add(l1bMsg(sv, gss, epoch))
				_, _ = buf.Add(e5aMsg(sv, gss, epoch))
			}
		}
	}
}

// BenchmarkPairBuffer_1SV_1GSS — trivial pair, one key.
func BenchmarkPairBuffer_1SV_1GSS(b *testing.B) { benchmarkPairBuffer(b, 1, 1) }

// BenchmarkPairBuffer_36SV_1GSS — all SVs, one station (36 concurrent keys).
func BenchmarkPairBuffer_36SV_1GSS(b *testing.B) { benchmarkPairBuffer(b, 36, 1) }

// BenchmarkPairBuffer_36SV_40GSS — maximum key space (1440 concurrent keys).
func BenchmarkPairBuffer_36SV_40GSS(b *testing.B) { benchmarkPairBuffer(b, 36, 40) }

// BenchmarkPairBuffer_Flush_36SV benchmarks the Flush() path:
// 36 L1B-only signals left pending, then one Flush call.
func BenchmarkPairBuffer_Flush_36SV(b *testing.B) {
	b.ReportAllocs()
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		b.StopTimer()
		buf := orchestrator.NewPairBuffer()
		epoch := int64(i + 1)
		for sv := 1; sv <= 36; sv++ {
			_, _ = buf.Add(l1bMsg(int32(sv), "GSS1", epoch))
		}
		b.StartTimer()
		_ = buf.Flush(epoch)
	}
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
//
// GROUP 5: Snapshot I/O cost
//
// Measures the full FileStore round-trip (marshal + write + rename + read +
// unmarshal) with realistic payload sizes.
// Run separately with -benchtime=3s to avoid file descriptor churn.
//
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

// Realistic snapshot sizes based on C struct dimensions:
//   MeasDB      ≈ MEASUREMENT_DATABASE   (UINT16 * 2 * 40 fields)    ≈   2 KB
//   KalmanStatus ≈ KALMAN_STATUS         (36 * (4 + 16) doubles)     ≈   6 KB
//   LosDB        ≈ LOS_DATABASE          (36*40*2 * 3 BOOLEAN arrays) ≈  34 KB
//   ResidualDB   ≈ RESIDUAL_DATABASE     (36*40*9 RESIDUAL_DATA)      ≈ 130 KB

func makeRealisticSnapshot(epoch int64) *core.Snapshot {
	return &core.Snapshot{
		Epoch:        epoch,
		MeasDB:       make([]byte, 2*1024),
		NavDB:        make([]byte, 4*1024),
		KalmanStatus: make([]byte, 6*1024),
		LosDB:        make([]byte, 34*1024),
		ResidualDB:   make([]byte, 130*1024),
	}
}

// BenchmarkSnapshot_Save benchmarks the FileStore.Save path:
// JSON marshal + write to tmpfile + rename (atomic).
func BenchmarkSnapshot_Save(b *testing.B) {
	dir := b.TempDir()
	store := snapshot.NewFileStore(dir)
	snap := makeRealisticSnapshot(1000)
	b.ResetTimer()
	b.ReportAllocs()
	for i := 0; i < b.N; i++ {
		snap.Epoch = int64(i + 1)
		_ = store.Save(benchCtx, snap)
	}
}

// BenchmarkSnapshot_Load benchmarks the FileStore.Load path:
// read file + JSON unmarshal.
func BenchmarkSnapshot_Load(b *testing.B) {
	dir := b.TempDir()
	store := snapshot.NewFileStore(dir)
	snap := makeRealisticSnapshot(1000)
	_ = store.Save(benchCtx, snap) // seed the file once

	b.ResetTimer()
	b.ReportAllocs()
	for i := 0; i < b.N; i++ {
		_, _ = store.Load(benchCtx)
	}
}

// BenchmarkSnapshot_RoundTrip benchmarks Save + Load as an atomic operation.
// This is what happens at every epoch close in production.
func BenchmarkSnapshot_RoundTrip(b *testing.B) {
	dir := b.TempDir()
	store := snapshot.NewFileStore(dir)
	snap := makeRealisticSnapshot(1000)
	b.ResetTimer()
	b.ReportAllocs()
	for i := 0; i < b.N; i++ {
		snap.Epoch = int64(i + 1)
		_ = store.Save(benchCtx, snap)
		_, _ = store.Load(benchCtx)
	}
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
//
// GROUP 6: Contention — concurrent message processing
//
// These benchmarks run HandleMessage from multiple goroutines simultaneously
// to reveal lock contention in PairBuffer and EpochWindow.
// Use -cpu=1,2,4,8 to build a scaling curve.
//
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

// BenchmarkContention_HandleMessage_Parallel benchmarks concurrent pair
// processing. Each goroutine works on its own unique (epoch, sv) key, so
// there is no pair-level contention — only the PairBuffer map mutex.
func BenchmarkContention_HandleMessage_Parallel(b *testing.B) {
	orch := orchestrator.NewOrchestrator(
		NoopCore{}, fullMask(36),
		nil, noopStore{}, noopPublisher{}, noopAlerter{},
		nil, orchestrator.ServiceLaneConfig{PPStep: 1, ExecuteStep: 60, GSSReadinessRatio: 0}, nil, nullLog,
	)
	b.ResetTimer()
	b.ReportAllocs()
	b.RunParallel(func(pb *testing.PB) {
		i := 0
		for pb.Next() {
			i++
			// Each goroutine uses a distinct epoch to avoid cross-goroutine
			// pair completion, which would race on the window RecordSV map.
			epoch := int64(i*1_000_000 + i)
			sv := int32((i % 36) + 1)
			_ = orch.HandleMessage(benchCtx, l1bMsg(sv, "GSS1", epoch))
			_ = orch.HandleMessage(benchCtx, e5aMsg(sv, "GSS1", epoch))
		}
	})
}

// BenchmarkContention_PairBuffer_Parallel isolates PairBuffer mutex contention
// without any orchestrator overhead.
func BenchmarkContention_PairBuffer_Parallel(b *testing.B) {
	buf := orchestrator.NewPairBuffer()
	b.ResetTimer()
	b.ReportAllocs()
	b.RunParallel(func(pb *testing.PB) {
		i := 0
		for pb.Next() {
			i++
			epoch := int64(i * 1_000_000)
			_, _ = buf.Add(l1bMsg(1, "GSS1", epoch))
			_, _ = buf.Add(e5aMsg(1, "GSS1", epoch))
		}
	})
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
//
// GROUP 7: Struct argument copy cost
//
// AddMeasurementParams is 72 bytes, passed by value across the interface.
// These micro-benchmarks quantify whether passing by pointer instead would
// be worth it, and whether the [2]MeasurementData array is the cost driver.
//
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

// BenchmarkArgCopy_AddMeasurementParams_ByValue benchmarks passing params by value.
func BenchmarkArgCopy_AddMeasurementParams_ByValue(b *testing.B) {
	p := baseParams(1, 1000)
	sink := core.AddMeasurementParams{}
	b.ResetTimer()
	b.ReportAllocs()
	for i := 0; i < b.N; i++ {
		sink = p // explicit value copy — mirrors interface dispatch copy
	}
	_ = sink
}

// BenchmarkArgCopy_AddMeasurementParams_ByPointer benchmarks the pointer path
// to compare with ByValue. If the delta is significant, consider changing the
// interface signature.
func BenchmarkArgCopy_AddMeasurementParams_ByPointer(b *testing.B) {
	p := baseParams(1, 1000)
	var sink *core.AddMeasurementParams
	b.ResetTimer()
	b.ReportAllocs()
	for i := 0; i < b.N; i++ {
		sink = &p
	}
	_ = sink
}

// BenchmarkArgCopy_ExecuteOutput benchmarks copying the ExecuteOutput struct.
// At 36*3 = 108 float64/int32 fields (~864 bytes), this is the largest
// struct returned by any C call.
func BenchmarkArgCopy_ExecuteOutput(b *testing.B) {
	out := &core.ExecuteOutput{}
	for i := range out.Confidence {
		out.Confidence[i] = 1.0
		out.SISError[i] = 0.001
		out.KalmanState[i] = 1
	}
	sink := core.ExecuteOutput{}
	b.ResetTimer()
	b.ReportAllocs()
	for i := 0; i < b.N; i++ {
		sink = *out
	}
	_ = sink
}
