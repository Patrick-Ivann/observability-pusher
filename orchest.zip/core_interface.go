package core

import (
	"github.com/yourorg/gnss-processor/internal/domain"
)

// Dimensional aliases — source of truth is domain/constants.go.
const (
	maxSV               = domain.MaxSV
	maxStations         = domain.MaxStations
	numServices         = domain.NumServices
	measurementsPerStat = domain.MeasurementsPerStation
)

// GNSSCore is the interface wrapping all C library calls.
// Each method maps to exactly one C function.
// The interface is declared in the orchestrator package as CoreLayer;
// GNSSCore is the definition that CBridge must satisfy.
//
//go:generate mockery --name=GNSSCore --output=../mocks --outpkg=mocks
type GNSSCore interface {
	// InitMeasurementDatabase initialises the internal measurement DB.
	InitMeasurementDatabase() error

	// AddMeasurement adds a paired measurement for a given (station, SV, epoch).
	AddMeasurement(params AddMeasurementParams) error

	// RemoveUnhealthySat prunes SVs flagged as unhealthy from the measurement DB.
	// health is a dense boolean array indexed 0..MaxSV-1.
	RemoveUnhealthySat(satelliteHealth [domain.MaxSV]bool, epoch int64) error

	// ComputeStationPositions computes ECEF positions for all GSS stations at epoch.
	ComputeStationPositions(epoch float64) error

	// PP runs the per-second pre-processing routine (cycle-slip, LoS residuals).
	PP(epoch int64) error

	// Execute runs the Kalman / integrity computation and returns the full output.
	Execute(epoch int64) (*ExecuteOutput, error)

	// LoadSnapshot restores all internal C state from a serialised snapshot.
	LoadSnapshot(snap *Snapshot) error

	// DumpSnapshot serialises all internal C state to a snapshot blob.
	DumpSnapshot() (*Snapshot, error)
}

// ─── Input types ──────────────────────────────────────────────────────────────

// AddMeasurementParams groups all inputs for AddMeasurement.
type AddMeasurementParams struct {
	StationID    uint16
	SatelliteID  uint16
	Epoch        uint64
	MeasData     [numServices]MeasurementData // [0]=FNAV/L1B  [1]=INAV/E5A/E5B
	SecMeas      bool
	RecClkOffset float64
}

// MeasurementData carries the raw signal measurement values for one service slot.
type MeasurementData struct {
	Wavelength  float64
	Phase       float64
	CN0         float64
	PseudoRange float64
}

// ─── Output types ─────────────────────────────────────────────────────────────

// ExecuteOutput is the Go-side representation of the full C OUTPUT struct.
// All arrays are indexed by satellite slot (0..MaxSV-1).
type ExecuteOutput struct {
	// Per-satellite integrity outputs.
	ClockError      [maxSV]float64
	OrbitError      [maxSV]float64
	SigmaMon        [maxSV]float64
	WULVector       [maxSV]float64
	SISRangingError [maxSV]float64
	SISError        [maxSV]float64 // SIS error bound at WUL (m)
	Confidence      [maxSV]float64 // integrity confidence level [0,1]
	KalmanState     [maxSV]int32
	IOD             [maxSV]int32

	// Per-station clock synchronisation — indexed by station slot (0..MaxStations-1).
	StationClockSynchro [maxStations]float64

	// Per-LoS residuals — indexed by [station][sv].
	ResidualTemporal [maxStations][maxSV]float64

	// Per-LoS cycle-slip flags — indexed by [station][sv].
	CycleSlipFlag [maxStations][maxSV]bool
}

// ToEpochResult converts ExecuteOutput to a domain.EpochResult for the given
// epoch and service. activeSVs and activeStations limit iteration to live slots.
func (o *ExecuteOutput) ToEpochResult(
	epoch int64,
	svc domain.ServiceID,
	activeSVs []uint16,
	activeStations []domain.StationSlot,
) domain.EpochResult {
	result := domain.EpochResult{
		Epoch:     epoch,
		ServiceID: svc,
	}
	for _, svid := range activeSVs {
		if int(svid) >= maxSV {
			continue
		}
		result.SVs = append(result.SVs, domain.SVResult{
			SVID:            svid,
			ClockError:      o.ClockError[svid],
			OrbitError:      o.OrbitError[svid],
			SigmaMon:        o.SigmaMon[svid],
			WULVector:       o.WULVector[svid],
			SISRangingError: o.SISRangingError[svid],
			KalmanState:     o.KalmanState[svid],
			IOD:             o.IOD[svid],
		})
	}
	for _, slot := range activeStations {
		if int(slot.Index) >= maxStations {
			continue
		}
		result.Stations = append(result.Stations, domain.StationResult{
			GSSId:        slot.GSSId,
			ServiceID:    svc,
			ClockSynchro: o.StationClockSynchro[slot.Index],
		})
		for _, svid := range activeSVs {
			if int(svid) >= maxSV {
				continue
			}
			result.LoS = append(result.LoS, domain.LoSResult{
				LoSKey:           domain.LoSKey{GSSId: slot.GSSId, SVID: svid},
				ServiceID:        svc,
				ResidualTemporal: o.ResidualTemporal[slot.Index][svid],
				CycleSlipFlag:    o.CycleSlipFlag[slot.Index][svid],
			})
		}
	}
	return result
}

// ─── Snapshot ─────────────────────────────────────────────────────────────────

// Snapshot holds serialisable blobs of all C state structs.
type Snapshot struct {
	Epoch        int64
	MeasDB       []byte
	NavDB        []byte
	LosDB        []byte
	ResidualDB   []byte
	KalmanStatus []byte
}
