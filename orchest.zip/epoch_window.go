package orchestrator

import (
	"sync"
	"time"
)

// EpochState is the lifecycle phase of one EpochWindow.
type EpochState int

const (
	// EpochOpen means the window is accepting measurements.
	EpochOpen EpochState = iota
	// EpochFinalized means Execute() succeeded; the window is sealed.
	EpochFinalized
)

// EpochWindow tracks signal arrival and lifecycle for one (epoch, service) pair.
//
// State machine:
//
//	EpochOpen ──[Finalize()]──► EpochFinalized   (one-way, idempotent)
//
// Concurrency: all methods are safe for concurrent use.
type EpochWindow struct {
	// Epoch is the GST epoch this window belongs to.
	Epoch int64
	// State is the current lifecycle phase (EpochOpen or EpochFinalized).
	State       EpochState
	receivedSVs map[int32]struct{}
	openedAt    time.Time
	mu          sync.Mutex
}

// NewEpochWindow creates a fresh open window for the given epoch.
func NewEpochWindow(epoch int64) *EpochWindow {
	return &EpochWindow{
		Epoch:       epoch,
		State:       EpochOpen,
		receivedSVs: make(map[int32]struct{}),
		openedAt:    time.Now(),
	}
}

// RecordSV registers that a completed pair for svID was processed.
// No-op and returns false if the window is already finalized.
func (w *EpochWindow) RecordSV(svID int32) bool {
	w.mu.Lock()
	defer w.mu.Unlock()
	if w.State == EpochFinalized {
		return false
	}
	w.receivedSVs[svID] = struct{}{}
	return true
}

// Finalize seals the window. Idempotent.
func (w *EpochWindow) Finalize() {
	w.mu.Lock()
	defer w.mu.Unlock()
	w.State = EpochFinalized
}

// IsFinalized reports whether Execute() has already run for this epoch.
func (w *EpochWindow) IsFinalized() bool {
	w.mu.Lock()
	defer w.mu.Unlock()
	return w.State == EpochFinalized
}

// Age returns how long ago this window was opened.
// openedAt is written once at construction — no lock needed.
func (w *EpochWindow) Age() time.Duration {
	return time.Since(w.openedAt)
}

// SVCount returns the number of distinct SVs recorded so far.
func (w *EpochWindow) SVCount() int {
	w.mu.Lock()
	defer w.mu.Unlock()
	return len(w.receivedSVs)
}

// ActiveSVs returns a snapshot of the SV IDs recorded in this window.
// Used at publish time to populate per-SV output slices.
func (w *EpochWindow) ActiveSVs() []uint16 {
	w.mu.Lock()
	defer w.mu.Unlock()
	svs := make([]uint16, 0, len(w.receivedSVs))
	for svID := range w.receivedSVs {
		svs = append(svs, uint16(svID))
	}
	return svs
}
