package core

import (
	"sync"

	"github.com/yourorg/gnss-processor/internal/domain"
)

// FakeCore is a test double for GNSSCore.
//
// It records every call so tests can assert:
//   - how many times AddMeasurement was called
//   - what epoch was passed to PP and Execute
//   - whether DumpSnapshot / LoadSnapshot were invoked
//
// FakeCore is safe for concurrent use. All injected error hooks are consulted
// on every call so tests can simulate failures at specific points.
//
// Usage:
//
//	fc := core.NewFakeCore()
//	fc.ExecuteErr = errors.New("C library panic")     // make Execute fail
//	fc.OnExecute = func(e int64) *ExecuteOutput { … } // inject specific output
type FakeCore struct {
	mu sync.Mutex

	// ── Call counters ────────────────────────────────────────────────────
	InitCalls          int
	AddMeasurementArgs []AddMeasurementParams
	RemoveArgs         []int64
	PPArgs             []int64
	ExecuteArgs        []int64
	SnapshotDumpCount  int
	SnapshotLoadCount  int

	// ── Injected outputs ─────────────────────────────────────────────────

	// OnExecute, when non-nil, is called to produce the return value of Execute.
	// If nil, Execute returns a zero-value ExecuteOutput with Confidence all 1.0.
	OnExecute func(epoch int64) *ExecuteOutput

	// ── Injected errors (nil = no error) ─────────────────────────────────
	InitErr        error
	AddErr         error
	RemoveErr      error
	ComputePosErr  error
	PPErr          error
	ExecuteErr     error
	DumpErr        error
	LoadErr        error

	// ── Snapshot storage (LoadSnapshot ↔ DumpSnapshot round-trip) ────────
	storedSnap *Snapshot
}

// NewFakeCore creates a FakeCore with healthy default outputs.
func NewFakeCore() *FakeCore {
	return &FakeCore{}
}

// InitMeasurementDatabase records the call and returns InitErr.
func (f *FakeCore) InitMeasurementDatabase() error {
	f.mu.Lock()
	defer f.mu.Unlock()
	f.InitCalls++
	return f.InitErr
}

// AddMeasurement records params and returns AddErr.
func (f *FakeCore) AddMeasurement(p AddMeasurementParams) error {
	f.mu.Lock()
	defer f.mu.Unlock()
	f.AddMeasurementArgs = append(f.AddMeasurementArgs, p)
	return f.AddErr
}

// RemoveUnhealthySat records the epoch and returns RemoveErr.
func (f *FakeCore) RemoveUnhealthySat(_ [domain.MaxSV]bool, epoch int64) error {
	f.mu.Lock()
	defer f.mu.Unlock()
	f.RemoveArgs = append(f.RemoveArgs, epoch)
	return f.RemoveErr
}

// ComputeStationPositions returns ComputePosErr (epoch is not recorded — it is
// equal to the Execute epoch so asserting ExecuteArgs is sufficient).
func (f *FakeCore) ComputeStationPositions(_ float64) error {
	return f.ComputePosErr
}

// PP records epoch and returns PPErr.
func (f *FakeCore) PP(epoch int64) error {
	f.mu.Lock()
	defer f.mu.Unlock()
	f.PPArgs = append(f.PPArgs, epoch)
	return f.PPErr
}

// Execute records epoch and returns either the output from OnExecute or a
// default output where Confidence[i]=1.0 for all i.
func (f *FakeCore) Execute(epoch int64) (*ExecuteOutput, error) {
	f.mu.Lock()
	defer f.mu.Unlock()
	f.ExecuteArgs = append(f.ExecuteArgs, epoch)
	if f.ExecuteErr != nil {
		return nil, f.ExecuteErr
	}
	if f.OnExecute != nil {
		return f.OnExecute(epoch), nil
	}
	out := &ExecuteOutput{}
	for i := range out.Confidence {
		out.Confidence[i] = 1.0
	}
	return out, nil
}

// DumpSnapshot records the call, stores the snapshot internally, and returns
// DumpErr. The stored snapshot can be retrieved by subsequent LoadSnapshot calls.
func (f *FakeCore) DumpSnapshot() (*Snapshot, error) {
	f.mu.Lock()
	defer f.mu.Unlock()
	f.SnapshotDumpCount++
	if f.DumpErr != nil {
		return nil, f.DumpErr
	}
	snap := &Snapshot{MeasDB: []byte("fake")}
	f.storedSnap = snap
	return snap, nil
}

// LoadSnapshot records the call and returns LoadErr.
func (f *FakeCore) LoadSnapshot(snap *Snapshot) error {
	f.mu.Lock()
	defer f.mu.Unlock()
	f.SnapshotLoadCount++
	if f.LoadErr != nil {
		return f.LoadErr
	}
	f.storedSnap = snap
	return nil
}

// AddMeasurementCount returns the number of AddMeasurement calls (thread-safe).
func (f *FakeCore) AddMeasurementCount() int {
	f.mu.Lock()
	defer f.mu.Unlock()
	return len(f.AddMeasurementArgs)
}

// PPCount returns the number of PP calls (thread-safe).
func (f *FakeCore) PPCount() int {
	f.mu.Lock()
	defer f.mu.Unlock()
	return len(f.PPArgs)
}

// ExecuteCount returns the number of Execute calls (thread-safe).
func (f *FakeCore) ExecuteCount() int {
	f.mu.Lock()
	defer f.mu.Unlock()
	return len(f.ExecuteArgs)
}
