package integration

import (
	"context"
	"log/slog"
	"os"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
	"github.com/stretchr/testify/require"
	"github.com/yourorg/gnss-processor/internal/core"
	"github.com/yourorg/gnss-processor/internal/domain"
	"github.com/yourorg/gnss-processor/internal/mocks"
	"github.com/yourorg/gnss-processor/internal/orchestrator"
)

// buildFullOrchestrator wires a fully-mocked orchestrator for integration tests.
func buildFullOrchestrator(t *testing.T, mockCore *mocks.GNSSCore) *orchestrator.Orchestrator {
	t.Helper()
	mask := &domain.SVMask{
		Satellites: map[int32]domain.SVHealth{
			1: {SVID: 1, Status: 0},
			7: {SVID: 7, Status: 0},
		},
	}
	mockLeader := &mocks.LeaderElector{}
	mockLeader.On("IsLeader").Return(true)

	snapStore := &mocks.Store{}
	snapStore.On("Save", mock.Anything, mock.Anything).Return(nil)

	pub := &mocks.Publisher{}
	pub.On("Publish", mock.Anything, mock.Anything).Return(nil)

	al := &mocks.Alerter{}
	log := slog.New(slog.NewTextHandler(os.Stdout, nil))
	laneCfg := orchestrator.ServiceLaneConfig{PPStep: 1, ExecuteStep: 60, GSSReadinessRatio: 0}
	return orchestrator.NewOrchestrator(mockCore, mask, mockLeader, snapStore, pub, al,
		nil, laneCfg, nil, log)
}

func TestPipeline_TwoMessages_SameEpoch_SameSV(t *testing.T) {
	mockCore := &mocks.GNSSCore{}
	mockCore.On("AddMeasurement", mock.Anything).Return(nil)
	mockCore.On("PP", mock.Anything).Return(nil)

	orch := buildFullOrchestrator(t, mockCore)
	ctx := context.Background()

	// L1B — first signal of the pair.
	msg1 := domain.MessageInput{
		Epoch: 5000, GSSId: "GSS1", Sv: 7,
		Measurement: domain.MessageMeasurement{ChannelId: domain.ChannelL1B, SignalCtoN: 40},
		ShsDvs:      domain.ShsDvsMessage{SignalHealthStatus: 0, DataValidityStatus: true},
	}
	require.NoError(t, orch.HandleMessage(ctx, msg1))
	mockCore.AssertNotCalled(t, "AddMeasurement", mock.Anything)

	// E5A — completes the pair.
	msg2 := msg1
	msg2.Measurement.ChannelId = domain.ChannelE5A
	require.NoError(t, orch.HandleMessage(ctx, msg2))
	mockCore.AssertCalled(t, "AddMeasurement", mock.Anything)
}

func TestPipeline_ExecuteCalledOnTicker(t *testing.T) {
	mockCore := &mocks.GNSSCore{}
	mockCore.On("AddMeasurement", mock.Anything).Return(nil)
	mockCore.On("PP", mock.Anything).Return(nil)
	mockCore.On("RemoveUnhealthySat", mock.Anything, mock.Anything).Return(nil)
	mockCore.On("ComputeStationPositions", mock.Anything).Return(nil)
	mockCore.On("Execute", mock.Anything).Return(&core.ExecuteOutput{}, nil)
	mockCore.On("DumpSnapshot").Return(&core.Snapshot{}, nil)

	orch := buildFullOrchestrator(t, mockCore)
	ctx, cancel := context.WithTimeout(context.Background(), 200*time.Millisecond)
	defer cancel()

	// Seed a pair so the epoch window exists.
	seed := domain.MessageInput{
		Epoch: 5000, GSSId: "GSS1", Sv: 7,
		Measurement: domain.MessageMeasurement{ChannelId: domain.ChannelL1B},
		ShsDvs:      domain.ShsDvsMessage{SignalHealthStatus: 0, DataValidityStatus: true},
	}
	require.NoError(t, orch.HandleMessage(ctx, seed))
	seed.Measurement.ChannelId = domain.ChannelE5A
	require.NoError(t, orch.HandleMessage(ctx, seed))

	// Force epoch close directly (ticker would fire after 60 s in prod).
	require.NoError(t, orch.ForceExecute(ctx, 5000))
	mockCore.AssertCalled(t, "Execute", int64(5000))
}

func TestPipeline_ReplayDoesNotReopenFinalizedEpoch(t *testing.T) {
	mockCore := &mocks.GNSSCore{}
	orch := buildFullOrchestrator(t, mockCore)
	ctx := context.Background()

	// Finalize the epoch externally.
	orch.FinalizeEpochForTest(5000)

	msg := domain.MessageInput{
		Epoch: 5000, GSSId: "GSS1", Sv: 7,
		Measurement: domain.MessageMeasurement{ChannelId: domain.ChannelL1B},
		ShsDvs:      domain.ShsDvsMessage{SignalHealthStatus: 0, DataValidityStatus: true},
	}
	require.NoError(t, orch.HandleMessage(ctx, msg))
	mockCore.AssertNotCalled(t, "AddMeasurement", mock.Anything)
}

// Unused import guard.
var _ = assert.New
