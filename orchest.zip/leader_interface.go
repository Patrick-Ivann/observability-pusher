package leader

import (
	"context"
	"fmt"
	"time"

	"github.com/yourorg/gnss-processor/internal/cache"
)

// LeaderElector determines if this instance is the current leader.
//
//go:generate mockery --name=LeaderElector --output=../mocks --outpkg=mocks
type LeaderElector interface {
	IsLeader() bool
	TryAcquire(ctx context.Context) (bool, error)
	Release(ctx context.Context) error
}

// RedisLeaderElector implements LeaderElector using the CacheManager as the
// distributed lock backend. No direct redis.Client calls are made — all cache
// access goes through the CacheManager interface so the elector is testable
// without a running Redis.
//
// Algorithm:
//
//   - TryAcquire:  Set(lockKey, leaderID, ttl) if not exists (uses SetNX
//     semantics via Get + conditional Set).
//   - Heartbeat:   Re-set the key with TTL on every successful TryAcquire.
//   - Release:     Delete the key only when the stored value matches leaderID.
//
// Note: CacheManager.Set always overwrites. We guard against stealing another
// leader's lock by reading the current value first and only writing when the
// key is absent or owned by this instance.
type RedisLeaderElector struct {
	cache    cache.CacheManager
	lockKey  string
	ttl      time.Duration
	leaderID string
	isLeader bool
}

// NewRedisLeaderElector creates a leader elector backed by the given CacheManager.
func NewRedisLeaderElector(c cache.CacheManager, lockKey, leaderID string, ttl time.Duration) *RedisLeaderElector {
	return &RedisLeaderElector{
		cache:    c,
		lockKey:  lockKey,
		ttl:      ttl,
		leaderID: leaderID,
	}
}

// IsLeader returns the cached leader state from the last TryAcquire call.
// Call TryAcquire to refresh the state.
func (r *RedisLeaderElector) IsLeader() bool {
	return r.isLeader
}

// TryAcquire attempts to acquire or renew the leader lock.
//
//  1. If the key does not exist (cache miss): write our leaderID with TTL and
//     become leader.
//  2. If the key exists and matches our leaderID: refresh TTL and remain leader.
//  3. If the key exists and belongs to another instance: not leader.
func (r *RedisLeaderElector) TryAcquire(ctx context.Context) (bool, error) {
	existing, err := r.cache.Get(r.lockKey)
	switch {
	case err == cache.ErrCacheMiss:
		// Key absent — try to take the lock.
		if serr := r.cache.Set(r.lockKey, r.leaderID, r.ttl); serr != nil {
			r.isLeader = false
			return false, fmt.Errorf("leader set: %w", serr)
		}
		// Verify we actually won (another instance could have raced us).
		won, verr := r.cache.Get(r.lockKey)
		if verr != nil {
			r.isLeader = false
			return false, fmt.Errorf("leader verify: %w", verr)
		}
		r.isLeader = won == r.leaderID
		return r.isLeader, nil

	case err != nil:
		r.isLeader = false
		return false, fmt.Errorf("leader get: %w", err)

	default:
		if existing != r.leaderID {
			// Another instance holds the lock.
			r.isLeader = false
			return false, nil
		}
		// We own the lock — refresh the TTL.
		if serr := r.cache.Set(r.lockKey, r.leaderID, r.ttl); serr != nil {
			// Non-fatal: log via caller. The lock will expire at the old TTL.
			_ = ctx
		}
		r.isLeader = true
		return true, nil
	}
}

// Release deletes the lock key only when it matches our leaderID.
// Safe to call even if we are not the current leader.
func (r *RedisLeaderElector) Release(ctx context.Context) error {
	_ = ctx
	existing, err := r.cache.Get(r.lockKey)
	if err != nil {
		// Key already gone (expired or deleted) — nothing to release.
		r.isLeader = false
		return nil
	}
	if existing != r.leaderID {
		r.isLeader = false
		return nil
	}
	if err := r.cache.Delete(r.lockKey); err != nil {
		return fmt.Errorf("leader release: %w", err)
	}
	r.isLeader = false
	return nil
}
