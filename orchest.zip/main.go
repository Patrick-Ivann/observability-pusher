package main

import (
	"context"
	"fmt"
	"log/slog"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/prometheus/client_golang/prometheus"
	"github.com/prometheus/client_golang/prometheus/promhttp"
	"github.com/redis/go-redis/v9"
	"github.com/yourorg/gnss-processor/internal/alert"
	"github.com/yourorg/gnss-processor/internal/cache"
	"github.com/yourorg/gnss-processor/internal/config"
	"github.com/yourorg/gnss-processor/internal/consumer"
	"github.com/yourorg/gnss-processor/internal/infrastructure"
	"github.com/yourorg/gnss-processor/internal/leader"
	"github.com/yourorg/gnss-processor/internal/messaging"
	"github.com/yourorg/gnss-processor/internal/orchestrator"
	"github.com/yourorg/gnss-processor/internal/publisher"
	"github.com/yourorg/gnss-processor/internal/snapshot"
)

func main() {
	ctx, stop := signal.NotifyContext(context.Background(), syscall.SIGTERM, syscall.SIGINT)
	defer stop()

	log := infrastructure.NewLogger(slog.LevelInfo)

	if err := run(ctx, log); err != nil {
		log.Error("fatal error", "err", err)
		os.Exit(1)
	}
}

func run(ctx context.Context, log *slog.Logger) error {
	// ── Config ───────────────────────────────────────────────────────────────
	cfg, err := loadEnvConfig()
	if err != nil {
		return fmt.Errorf("load config: %w", err)
	}

	// ── SV mask (static XML, hot-reloaded by MaskWatcher) ────────────────────
	mask, err := config.ParseSVMask(cfg.svMaskPath)
	if err != nil {
		return fmt.Errorf("parse sv mask: %w", err)
	}
	maskWatcher := config.NewMaskWatcher(cfg.svMaskPath, 30*time.Second)

	// ── Redis — used by both CacheManager and LeaderElector ──────────────────
	rdb := redis.NewClient(&redis.Options{Addr: cfg.redisAddr})
	cacheManager := cache.NewRedisCacheManager(rdb)
	leaderElector := leader.NewRedisLeaderElector(cacheManager, cfg.leaderLockKey, cfg.instanceID, 30*time.Second)

	// ── Remote config loader (reads from cache, applied on epoch-done + non-leader) ─
	cfgLoader := config.NewConfigLoader(cacheManager, log)
	remoteCfg := cfgLoader.Reload(ctx)

	// ── RabbitMQ ─────────────────────────────────────────────────────────────
	rmq, err := messaging.NewRabbitMQService(cfg.rabbitMQURL)
	if err != nil {
		return fmt.Errorf("rabbitmq connect: %w", err)
	}
	defer func() {
		if cerr := rmq.Close(); cerr != nil {
			log.Warn("rabbitmq close error", "err", cerr)
		}
	}()

	// ── Infrastructure ───────────────────────────────────────────────────────
	reg := prometheus.NewRegistry()
	_ = infrastructure.NewMetrics(reg)
	alerter := alert.NewLogAlerter(log)
	snapStore := snapshot.NewFileStore(cfg.snapshotDir)
	pub := publisher.NewRabbitMQPublisher(rmq, cfg.resultExchange, cfg.resultRoutingKey)

	// ── Core (C bridge) ──────────────────────────────────────────────────────
	// Wire the real CBridge here. Panics during development to force wiring.
	// Replace the two lines below with real loadCConfig() / loadStationNetwork().
	// gnssCore := core.NewCBridge(loadCConfig(), loadStationNetwork())
	panic("wire real CBridge before deploying — see comment in main.go")

	// ── Lane config from remote config (falls back to static defaults) ────────
	laneCfg := buildLaneConfig(cfg, remoteCfg)

	// ── Orchestrator ─────────────────────────────────────────────────────────
	orch := orchestrator.NewOrchestrator(
		nil, // replace with gnssCore
		mask,
		leaderElector,
		snapStore,
		pub,
		alerter,
		nil,     // StationRegistryLayer — wire from station network config
		laneCfg,
		nil,     // expectedGSS — populate from station network config
		log,
	)

	// ── Epoch-done hook: reload remote config after every Execute ────────────
	// This is the primary path for picking up parameter changes in production.
	// Called synchronously in the consumer goroutine, so it must be fast.
	orch.SetOnEpochDone(func(epoch int64) {
		fresh := cfgLoader.Reload(ctx)
		orch.UpdateLaneConfig(buildLaneConfig(cfg, fresh))
		if len(fresh.SVBlacklist) > 0 {
			merged := config.ApplyToMask(mask, fresh)
			orch.SetMask(merged)
		}
		log.Debug("remote config applied after epoch", "epoch", epoch,
			"pp_step", fresh.PPStep, "execute_step", fresh.ExecuteStep)
	})

	// ── Restore snapshot if available ────────────────────────────────────────
	if snap, serr := snapStore.Load(ctx); serr == nil && snap != nil {
		log.Info("restoring snapshot", "epoch", snap.Epoch)
		// gnssCore.LoadSnapshot(snap)
	}

	// ── Background workers ───────────────────────────────────────────────────
	go maskWatcher.Run(ctx)
	go applyMaskUpdates(ctx, maskWatcher, orch, log)
	go serveHTTP(ctx, reg, log)
	go leaderHeartbeat(ctx, leaderElector, log)

	// Non-leader path: keep remote config fresh so a promotion is immediate.
	// A newly-promoted leader will call runEpochClose with up-to-date parameters.
	go cfgLoader.WatchAndReload(ctx, 15*time.Second, func(rc config.RemoteConfig) {
		if !leaderElector.IsLeader() {
			orch.UpdateLaneConfig(buildLaneConfig(cfg, rc))
			log.Debug("standby: remote config reloaded",
				"gss_ratio", rc.GSSReadinessRatio)
		}
	})

	// ── Consumer ─────────────────────────────────────────────────────────────
	cons := consumer.NewRabbitMQConsumer(
		rmq,
		cfg.inputExchange,
		cfg.queueName,
		cfg.routingKey,
		cfg.headers,
		orch.HandleMessage,
		log,
	)
	return cons.Run(ctx)
}

// buildLaneConfig merges the static AppConfig with any remote overrides.
// Remote values take precedence when non-zero.
func buildLaneConfig(cfg envConfig, rc config.RemoteConfig) orchestrator.ServiceLaneConfig {
	lcfg := orchestrator.ServiceLaneConfig{
		PPStep:            cfg.staticPPStep,
		ExecuteStep:       cfg.staticExecuteStep,
		GSSReadinessRatio: cfg.staticGSSRatio,
	}
	if rc.PPStep > 0 {
		lcfg.PPStep = rc.PPStep
	}
	if rc.ExecuteStep > 0 {
		lcfg.ExecuteStep = rc.ExecuteStep
	}
	if rc.GSSReadinessRatio > 0 {
		lcfg.GSSReadinessRatio = rc.GSSReadinessRatio
	}
	return lcfg
}

// applyMaskUpdates drains the MaskWatcher channel and pushes updates to the orchestrator.
func applyMaskUpdates(ctx context.Context, w *config.MaskWatcher, orch *orchestrator.Orchestrator, log *slog.Logger) {
	for {
		select {
		case <-ctx.Done():
			return
		case mask := <-w.Updates():
			orch.SetMask(mask)
			log.Info("SV mask reloaded", "svs", len(mask.Satellites))
		}
	}
}

// leaderHeartbeat refreshes the distributed lock every 10 s.
// When we lose leadership it releases the lock and logs the event.
func leaderHeartbeat(ctx context.Context, el leader.LeaderElector, log *slog.Logger) {
	ticker := time.NewTicker(10 * time.Second)
	defer ticker.Stop()
	for {
		select {
		case <-ctx.Done():
			if err := el.Release(context.Background()); err != nil {
				log.Warn("leader release error", "err", err)
			}
			return
		case <-ticker.C:
			ok, err := el.TryAcquire(ctx)
			if err != nil {
				log.Warn("leader acquire error", "err", err)
			} else {
				log.Debug("leader state", "is_leader", ok)
			}
		}
	}
}

// serveHTTP runs the Prometheus + health endpoint on :8080.
func serveHTTP(ctx context.Context, reg *prometheus.Registry, log *slog.Logger) {
	mux := http.NewServeMux()
	mux.Handle("/metrics", promhttp.HandlerFor(reg, promhttp.HandlerOpts{}))
	mux.Handle("/", infrastructure.HealthHandler())
	srv := &http.Server{
		Addr:              ":8080",
		Handler:           mux,
		ReadHeaderTimeout: 10 * time.Second,
	}
	go func() {
		<-ctx.Done()
		if err := srv.Shutdown(context.Background()); err != nil {
			log.Warn("http server shutdown error", "err", err)
		}
	}()
	if err := srv.ListenAndServe(); err != nil && err != http.ErrServerClosed {
		log.Error("http server error", "err", err)
	}
}

// ─── Environment config ───────────────────────────────────────────────────────

// envConfig holds all values loaded from environment variables.
type envConfig struct {
	rabbitMQURL      string
	inputExchange    string
	queueName        string
	routingKey       string
	headers          map[string]any // non-nil → header-exchange routing
	resultExchange   string
	resultRoutingKey string
	redisAddr        string
	snapshotDir      string
	svMaskPath       string
	leaderLockKey    string
	instanceID       string

	// Static cadence defaults — overridden by remote config at runtime.
	staticPPStep      int64
	staticExecuteStep int64
	staticGSSRatio    float64
}

func loadEnvConfig() (envConfig, error) {
	req := func(k string) (string, error) {
		v := os.Getenv(k)
		if v == "" {
			return "", fmt.Errorf("env %s is required", k)
		}
		return v, nil
	}
	opt := func(k, def string) string {
		if v := os.Getenv(k); v != "" {
			return v
		}
		return def
	}

	rabbitURL, err := req("RABBITMQ_URL")
	if err != nil {
		return envConfig{}, err
	}
	queueName, err := req("QUEUE_NAME")
	if err != nil {
		return envConfig{}, err
	}
	redisAddr, err := req("REDIS_ADDR")
	if err != nil {
		return envConfig{}, err
	}
	snapshotDir, err := req("SNAPSHOT_DIR")
	if err != nil {
		return envConfig{}, err
	}
	svMaskPath, err := req("SV_MASK_PATH")
	if err != nil {
		return envConfig{}, err
	}
	instanceID, err := req("INSTANCE_ID")
	if err != nil {
		return envConfig{}, err
	}

	return envConfig{
		rabbitMQURL:      rabbitURL,
		inputExchange:    opt("INPUT_EXCHANGE", "gnss.input"),
		queueName:        queueName,
		routingKey:       opt("ROUTING_KEY", "gnss.measurement.#"),
		resultExchange:   opt("RESULT_EXCHANGE", "gnss.output"),
		resultRoutingKey: opt("RESULT_ROUTING_KEY", "gnss.result"),
		redisAddr:        redisAddr,
		snapshotDir:      snapshotDir,
		svMaskPath:       svMaskPath,
		leaderLockKey:    opt("LEADER_LOCK_KEY", "gnss:leader"),
		instanceID:       instanceID,
		staticPPStep:     1,
		staticExecuteStep: 60,
		staticGSSRatio:   1.0,
	}, nil
}
