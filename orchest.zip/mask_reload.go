package orchestrator

import (
	"sync/atomic"

	"github.com/yourorg/gnss-processor/internal/domain"
)

// maskAtom wraps atomic.Pointer so mask replacement is race-free without unsafe.
type maskAtom struct {
	p atomic.Pointer[domain.SVMask]
}

// load returns the current mask. Returns nil only before the first store.
func (a *maskAtom) load() *domain.SVMask {
	return a.p.Load()
}

// store atomically replaces the mask.
func (a *maskAtom) store(mask *domain.SVMask) {
	a.p.Store(mask)
}
