package domain

// ChannelID represents the signal channel type.
type ChannelID string

const (
	ChannelL1B ChannelID = "L1B" // FNAV primary signal
	ChannelE5A ChannelID = "E5A" // INAV secondary signal (option A)
	ChannelE5B ChannelID = "E5B" // INAV secondary signal (option B)
)

// ServiceForChannel maps a channel to the navigation service it belongs to.
// L1B carries FNAV; E5A and E5B carry INAV.
func ServiceForChannel(ch ChannelID) (ServiceID, bool) {
	switch ch {
	case ChannelL1B:
		return ServiceFNAV, true
	case ChannelE5A, ChannelE5B:
		return ServiceINAV, true
	default:
		return "", false
	}
}

// MessageInput is the decoded GNSS message from the broker.
type MessageInput struct {
	Sv          int32
	GSSId       string
	Epoch       int64
	Ephemeris   EphemerisModel
	GST         GSTModel
	ShsDvs      ShsDvsMessage
	Measurement MessageMeasurement
}

// Service returns the ServiceID this message belongs to, derived from the
// channel carried in the measurement. Returns ("", false) for unknown channels.
func (m MessageInput) Service() (ServiceID, bool) {
	return ServiceForChannel(m.Measurement.ChannelId)
}

// MessageMeasurement carries signal-level observables for one channel.
type MessageMeasurement struct {
	NbSvInView  int32
	SatelliteId int32
	ChannelId   ChannelID
	CodePhase   float32
	SignalCtoN  float32
	AccDoppler  float32 // Doppler-based accumulated range-rate (m/s)
}

// EphemerisModel holds the broadcast ephemeris fields used by the C core.
type EphemerisModel struct {
	IodNav int32
	T0e    int32
	M0     int32
	SISA   int32
}

// GSTModel carries the Galileo System Time fields.
type GSTModel struct {
	TOW int32
	WN  int32
}

// ShsDvsMessage carries the SIS health and data validity flags.
type ShsDvsMessage struct {
	SvId               int32
	ServiceID          string
	ChannelId          ChannelID
	ShsDvsFrequency    ChannelID
	SignalHealthStatus int32
	DataValidityStatus bool
}

// SVHealth represents a satellite's health from the mask.
type SVHealth struct {
	SVID   int32
	Status int32 // 0 = healthy
}

// SVMask is the parsed mask XML.
type SVMask struct {
	Satellites map[int32]SVHealth
}

// IsHealthy returns true if the SV is present and marked healthy (Status == 0).
func (m *SVMask) IsHealthy(svID int32) bool {
	h, ok := m.Satellites[svID]
	return ok && h.Status == 0
}
