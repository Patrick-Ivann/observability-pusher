package orchestrator

import (
	"context"
	"fmt"
	"log/slog"

	"github.com/yourorg/gnss-processor/internal/alert"
	"github.com/yourorg/gnss-processor/internal/core"
	"github.com/yourorg/gnss-processor/internal/domain"
	"github.com/yourorg/gnss-processor/internal/leader"
	"github.com/yourorg/gnss-processor/internal/publisher"
	"github.com/yourorg/gnss-processor/internal/snapshot"
)

// ─── Layer interfaces ─────────────────────────────────────────────────────────

// CoreLayer abstracts the C GNSS library (CGo bridge).
// Tests cannot link CGo; FakeCore / NoopCore are substituted.
//
//go:generate mockery --name=CoreLayer --output=../mocks --outpkg=mocks
type CoreLayer interface {
	core.GNSSCore
}

// LeaderLayer abstracts distributed leader election.
// Production uses Redis-backed CacheManager; tests use an in-memory stub.
//
//go:generate mockery --name=LeaderLayer --output=../mocks --outpkg=mocks
type LeaderLayer interface {
	leader.LeaderElector
}

// SnapshotLayer abstracts crash-recovery state persistence.
//
//go:generate mockery --name=SnapshotLayer --output=../mocks --outpkg=mocks
type SnapshotLayer interface {
	snapshot.Store
}

// PublishLayer abstracts result delivery to downstream consumers.
//
//go:generate mockery --name=PublishLayer --output=../mocks --outpkg=mocks
type PublishLayer interface {
	publisher.Publisher
}

// AlertLayer abstracts operational alerting.
//
//go:generate mockery --name=AlertLayer --output=../mocks --outpkg=mocks
type AlertLayer interface {
	alert.Alerter
}

// ─── Orchestrator ─────────────────────────────────────────────────────────────

// Orchestrator is a stateless message router.
//
// Its only responsibilities are:
//  1. Validate the message (epoch non-zero, GSSId non-empty).
//  2. Filter by SV mask and SIS health flags.
//  3. Determine service (FNAV / INAV) from the signal channel.
//  4. Route to the correct ServiceLane via Ingest().
//
// The Orchestrator owns no epoch state, no tickers, and no goroutines.
// All processing — pairing, PP, Execute, publishing — lives in ServiceLane
// and is driven synchronously by the message consumer.
//
// # Remote config
//
// ServiceLane.OnEpochDone is wired from outside (main.go) to reload remote
// config from the cache after each successful Execute. This is the
// "epoch-done" hook described in the config_loader design.
type Orchestrator struct {
	lanes map[domain.ServiceID]*ServiceLane
	mask  maskAtom
	log   *slog.Logger
}

// NewOrchestrator wires up one ServiceLane per service (FNAV + INAV).
//
// Both lanes share the same CoreLayer. The CBridge serialises C access
// internally with its own mutex, so concurrent Ingest calls from different
// lanes are safe.
//
// The LeaderLayer parameter is accepted for future heartbeat wiring but is
// currently unused by the Orchestrator itself.
func NewOrchestrator(
	c CoreLayer,
	mask *domain.SVMask,
	_ LeaderLayer, // reserved — future heartbeat wiring
	ss SnapshotLayer,
	pub PublishLayer,
	al AlertLayer,
	registry StationRegistryLayer,
	laneCfg ServiceLaneConfig,
	expectedGSS []string,
	log *slog.Logger,
) *Orchestrator {
	o := &Orchestrator{log: log}
	o.mask.store(mask)
	makeLane := func(svc domain.ServiceID) *ServiceLane {
		return NewServiceLane(svc, c, pub, al, ss, registry, expectedGSS, laneCfg, log)
	}
	o.lanes = map[domain.ServiceID]*ServiceLane{
		domain.ServiceFNAV: makeLane(domain.ServiceFNAV),
		domain.ServiceINAV: makeLane(domain.ServiceINAV),
	}
	return o
}

// ─── Public API ───────────────────────────────────────────────────────────────

// HandleMessage validates, filters, and routes one broker message.
//
// Routing: the signal channel determines the service lane.
//
//	L1B       → FNAV
//	E5A / E5B → INAV
//
// Unknown channels are dropped with a warning — never returned as errors,
// so one malformed message cannot stall the consumer.
func (o *Orchestrator) HandleMessage(ctx context.Context, msg domain.MessageInput) error {
	if err := validateMessage(msg); err != nil {
		return fmt.Errorf("invalid message: %w", err)
	}
	if !o.isSVAllowed(msg) {
		return nil
	}

	svc, ok := msg.Service()
	if !ok {
		o.log.Warn("unknown channel — message dropped",
			"channel", msg.Measurement.ChannelId,
			"sv", msg.Sv, "gss", msg.GSSId, "epoch", msg.Epoch)
		return nil
	}

	lane, ok := o.lanes[svc]
	if !ok {
		return fmt.Errorf("no lane for service %q", svc)
	}
	return lane.Ingest(ctx, msg)
}

// UpdateHealthMap broadcasts a new per-SV health bitmask to all lanes.
func (o *Orchestrator) UpdateHealthMap(health [domain.MaxSV]bool) {
	for _, lane := range o.lanes {
		lane.UpdateHealthMap(health)
	}
}

// SetMask atomically replaces the SV mask. Hot-reload path via MaskWatcher.
func (o *Orchestrator) SetMask(mask *domain.SVMask) {
	o.mask.store(mask)
}

// SetOnEpochDone registers a callback that is invoked after each successful
// Execute on every lane. Used to trigger remote-config reloads from main.
func (o *Orchestrator) SetOnEpochDone(fn func(epoch int64)) {
	for _, lane := range o.lanes {
		lane.OnEpochDone = fn
	}
}

// UpdateLaneConfig replaces the cadence configuration on all lanes at runtime.
// Called after a remote-config reload.
func (o *Orchestrator) UpdateLaneConfig(cfg ServiceLaneConfig) {
	for _, lane := range o.lanes {
		lane.UpdateConfig(cfg)
	}
}

// ─── Filtering ────────────────────────────────────────────────────────────────

func validateMessage(msg domain.MessageInput) error {
	if msg.Epoch == 0 {
		return fmt.Errorf("epoch is zero")
	}
	if msg.GSSId == "" {
		return fmt.Errorf("GSSId is empty")
	}
	return nil
}

func (o *Orchestrator) isSVAllowed(msg domain.MessageInput) bool {
	m := o.mask.load()
	if m == nil || !m.IsHealthy(msg.Sv) {
		return false
	}
	if msg.ShsDvs.SignalHealthStatus != 0 {
		return false
	}
	return msg.ShsDvs.DataValidityStatus
}
