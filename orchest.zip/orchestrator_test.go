package orchestrator

import (
	"context"
	"log/slog"
	"os"
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
	"github.com/stretchr/testify/require"
	"github.com/yourorg/gnss-processor/internal/core"
	"github.com/yourorg/gnss-processor/internal/domain"
	"github.com/yourorg/gnss-processor/internal/mocks"
)

func makeHealthyMask(svID int32) *domain.SVMask {
	return &domain.SVMask{
		Satellites: map[int32]domain.SVHealth{
			svID: {SVID: svID, Status: 0},
		},
	}
}

func makeHealthyMsg(epoch int64, sv int32, ch domain.ChannelID) domain.MessageInput {
	return domain.MessageInput{
		Epoch: epoch,
		GSSId: "GSS1",
		Sv:    sv,
		Measurement: domain.MessageMeasurement{
			ChannelId:  ch,
			CodePhase:  1.0,
			SignalCtoN: 40,
		},
		ShsDvs: domain.ShsDvsMessage{
			SignalHealthStatus: 0,
			DataValidityStatus: true,
		},
	}
}

// defaultLaneCfg returns a ServiceLaneConfig suitable for unit tests.
func defaultLaneCfg() ServiceLaneConfig {
	return ServiceLaneConfig{PPStep: 1, ExecuteStep: 60, GSSReadinessRatio: 0}
}

func newTestOrchestrator(c core.GNSSCore, mask *domain.SVMask) *Orchestrator {
	mockLeader := &mocks.LeaderElector{}
	mockLeader.On("IsLeader").Return(true)
	mockSnap := &mocks.Store{}
	mockPub := &mocks.Publisher{}
	mockAl := &mocks.Alerter{}
	log := slog.New(slog.NewTextHandler(os.Stdout, nil))
	return NewOrchestrator(c, mask, mockLeader, mockSnap, mockPub, mockAl,
		nil, defaultLaneCfg(), nil, log)
}

func TestHandleMessage_DropsUnhealthySV(t *testing.T) {
	mockCore := &mocks.GNSSCore{}
	mask := makeHealthyMask(99) // only SV 99 is healthy
	orch := newTestOrchestrator(mockCore, mask)

	msg := makeHealthyMsg(1000, 7, domain.ChannelL1B) // SV 7 not in mask
	err := orch.HandleMessage(context.Background(), msg)
	require.NoError(t, err)
	mockCore.AssertNotCalled(t, "AddMeasurement", mock.Anything)
}

func TestHandleMessage_DropsZeroEpoch(t *testing.T) {
	mockCore := &mocks.GNSSCore{}
	orch := newTestOrchestrator(mockCore, makeHealthyMask(7))
	msg := makeHealthyMsg(0, 7, domain.ChannelL1B)
	err := orch.HandleMessage(context.Background(), msg)
	assert.Error(t, err)
}

func TestHandleMessage_WaitsForPair_ThenCallsAddAndPP(t *testing.T) {
	mockCore := &mocks.GNSSCore{}
	mockCore.On("AddMeasurement", mock.Anything).Return(nil)
	mockCore.On("PP", mock.Anything).Return(nil)

	orch := newTestOrchestrator(mockCore, makeHealthyMask(7))

	// First signal — no emission.
	err := orch.HandleMessage(context.Background(), makeHealthyMsg(1000, 7, domain.ChannelL1B))
	require.NoError(t, err)
	mockCore.AssertNotCalled(t, "AddMeasurement", mock.Anything)

	// Second signal — pair complete.
	err = orch.HandleMessage(context.Background(), makeHealthyMsg(1000, 7, domain.ChannelE5A))
	require.NoError(t, err)
	mockCore.AssertCalled(t, "AddMeasurement", mock.Anything)
}

func TestHandleMessage_DropsFinalizedEpoch(t *testing.T) {
	mockCore := &mocks.GNSSCore{}
	orch := newTestOrchestrator(mockCore, makeHealthyMask(7))

	// Manually finalize the epoch via the test helper.
	orch.FinalizeEpochForTest(1000)

	msg := makeHealthyMsg(1000, 7, domain.ChannelL1B)
	err := orch.HandleMessage(context.Background(), msg)
	require.NoError(t, err)
	mockCore.AssertNotCalled(t, "AddMeasurement", mock.Anything)
}

func TestRunEpochClose_CallsFullPipeline(t *testing.T) {
	mockCore := &mocks.GNSSCore{}
	mockCore.On("AddMeasurement", mock.Anything).Return(nil)
	mockCore.On("RemoveUnhealthySat", mock.Anything, int64(1000)).Return(nil)
	mockCore.On("ComputeStationPositions", float64(1000)).Return(nil)
	mockCore.On("Execute", int64(1000)).Return(&core.ExecuteOutput{}, nil)
	mockCore.On("DumpSnapshot").Return(&core.Snapshot{}, nil)

	mockSnap := &mocks.Store{}
	mockSnap.On("Save", mock.Anything, mock.Anything).Return(nil)
	mockPub := &mocks.Publisher{}
	mockPub.On("Publish", mock.Anything, mock.Anything).Return(nil)
	mockAl := &mocks.Alerter{}
	mockLeader := &mocks.LeaderElector{}

	log := slog.New(slog.NewTextHandler(os.Stdout, nil))
	orch := NewOrchestrator(mockCore, makeHealthyMask(7), mockLeader, mockSnap, mockPub, mockAl,
		nil, defaultLaneCfg(), nil, log)

	// ForceExecute routes to the FNAV lane's runEpochClose.
	err := orch.ForceExecute(context.Background(), 1000)
	require.NoError(t, err)

	mockCore.AssertCalled(t, "RemoveUnhealthySat", mock.Anything, int64(1000))
	mockCore.AssertCalled(t, "ComputeStationPositions", float64(1000))
	mockCore.AssertCalled(t, "Execute", int64(1000))
	mockSnap.AssertCalled(t, "Save", mock.Anything, mock.Anything)
}
