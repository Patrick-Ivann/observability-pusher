package orchestrator

import (
	"fmt"
	"sync"

	"github.com/yourorg/gnss-processor/internal/core"
	"github.com/yourorg/gnss-processor/internal/domain"
)

// ─── StationRegistryLayer ─────────────────────────────────────────────────────

// StationRegistryLayer resolves GSS string identifiers to numeric station
// indices expected by the C core.
//
// Why an interface:
//   - The concrete registry is built from STATION_NETWORK config at startup and
//     lives outside the orchestrator package.
//   - Tests inject a map-backed stub so no config file is required.
//
//go:generate mockery --name=StationRegistryLayer --output=../mocks --outpkg=mocks
type StationRegistryLayer interface {
	// IndexOf returns the C-core station index for gssID.
	IndexOf(gssID string) (uint16, error)

	// AllSlots returns all known (gssID, index) pairs.
	// Used at publish time to build LoS and station result slices.
	AllSlots() ([]domain.StationSlot, error)
}

// ─── signalKey / pendingPair ──────────────────────────────────────────────────

// signalKey is the unique identity of one (epoch, station, satellite) slot.
// Both L1B and E5A/E5B for the same slot share this key within a lane.
type signalKey struct {
	epoch int64
	gssID string
	svID  int32
}

// pendingPair holds the two signal slots for one signalKey.
// Either field may be nil while the counterpart has not yet arrived.
type pendingPair struct {
	primary   *domain.MessageMeasurement // L1B  (FNAV)
	secondary *domain.MessageMeasurement // E5A / E5B (INAV)
}

func (p *pendingPair) isPaired() bool {
	return p.primary != nil && p.secondary != nil
}

// ─── PairBuffer ───────────────────────────────────────────────────────────────

// PairBuffer buffers incoming measurements by (epoch, GSS, SV) and emits a
// complete AddMeasurementParams once both signals for a slot are present.
//
// One PairBuffer exists per ServiceLane — they are never shared across services.
//
// registry may be nil; when nil, stationID is always 0 (useful in unit tests
// where the station index is not significant).
//
// Thread-safe.
type PairBuffer struct {
	mu       sync.Mutex
	pending  map[signalKey]*pendingPair
	registry StationRegistryLayer // may be nil
}

// NewPairBuffer creates an empty PairBuffer.
// Pass a StationRegistryLayer to resolve GSS IDs to station indices;
// pass nil to use stationID=0 for all entries (unit-test mode).
func NewPairBuffer(registry ...StationRegistryLayer) *PairBuffer {
	var reg StationRegistryLayer
	if len(registry) > 0 {
		reg = registry[0]
	}
	return &PairBuffer{
		pending:  make(map[signalKey]*pendingPair),
		registry: reg,
	}
}

// Add records a measurement for the (epoch, GSS, SV) slot.
//
// Returns:
//   - (params, nil)  — both signals arrived; params is ready for AddMeasurement.
//   - (nil,   nil)   — first signal stored; waiting for counterpart.
//   - (nil,   error) — station registry lookup failed.
func (b *PairBuffer) Add(msg domain.MessageInput) (*core.AddMeasurementParams, error) {
	b.mu.Lock()
	defer b.mu.Unlock()

	key := signalKey{epoch: msg.Epoch, gssID: msg.GSSId, svID: msg.Sv}
	pair := b.getOrCreate(key)
	b.store(pair, msg)

	if !pair.isPaired() {
		return nil, nil
	}
	params, err := b.buildParams(key, pair)
	if err != nil {
		return nil, err
	}
	delete(b.pending, key)
	return params, nil
}

// Flush drains all partial pairs for the given epoch, emitting one
// AddMeasurementParams per pending slot regardless of whether the counterpart
// signal arrived. Called at epoch-close so no single-signal measurement is lost.
func (b *PairBuffer) Flush(epoch int64) ([]core.AddMeasurementParams, error) {
	b.mu.Lock()
	defer b.mu.Unlock()

	var results []core.AddMeasurementParams
	for key, pair := range b.pending {
		if key.epoch != epoch {
			continue
		}
		p, err := b.buildFromPartial(key, pair)
		if err != nil {
			return nil, err
		}
		results = append(results, p)
		delete(b.pending, key)
	}
	return results, nil
}

// ─── internal helpers ─────────────────────────────────────────────────────────

func (b *PairBuffer) getOrCreate(key signalKey) *pendingPair {
	if b.pending[key] == nil {
		b.pending[key] = &pendingPair{}
	}
	return b.pending[key]
}

func (b *PairBuffer) store(pair *pendingPair, msg domain.MessageInput) {
	m := msg.Measurement
	switch m.ChannelId {
	case domain.ChannelL1B:
		pair.primary = &m
	case domain.ChannelE5A, domain.ChannelE5B:
		pair.secondary = &m
	}
}

func (b *PairBuffer) resolveStation(gssID string) (uint16, error) {
	if b.registry == nil {
		return 0, nil
	}
	idx, err := b.registry.IndexOf(gssID)
	if err != nil {
		return 0, fmt.Errorf("station registry IndexOf %q: %w", gssID, err)
	}
	return idx, nil
}

func (b *PairBuffer) buildParams(key signalKey, pair *pendingPair) (*core.AddMeasurementParams, error) {
	stationIdx, err := b.resolveStation(key.gssID)
	if err != nil {
		return nil, err
	}
	p := &core.AddMeasurementParams{
		StationID:   stationIdx,
		SatelliteID: uint16(key.svID),
		Epoch:       uint64(key.epoch),
		SecMeas:     pair.secondary != nil,
	}
	p.MeasData[0] = measToCore(pair.primary)
	p.MeasData[1] = measToCore(pair.secondary)
	return p, nil
}

func (b *PairBuffer) buildFromPartial(key signalKey, pair *pendingPair) (core.AddMeasurementParams, error) {
	stationIdx, err := b.resolveStation(key.gssID)
	if err != nil {
		return core.AddMeasurementParams{}, err
	}
	p := core.AddMeasurementParams{
		StationID:   stationIdx,
		SatelliteID: uint16(key.svID),
		Epoch:       uint64(key.epoch),
		SecMeas:     pair.secondary != nil,
	}
	p.MeasData[0] = measToCore(pair.primary)
	p.MeasData[1] = measToCore(pair.secondary)
	return p, nil
}

func measToCore(m *domain.MessageMeasurement) core.MeasurementData {
	if m == nil {
		return core.MeasurementData{}
	}
	return core.MeasurementData{
		Phase:       float64(m.CodePhase),
		CN0:         float64(m.SignalCtoN),
		PseudoRange: float64(m.AccDoppler),
	}
}
