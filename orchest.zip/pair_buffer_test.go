package orchestrator

import (
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"github.com/yourorg/gnss-processor/internal/domain"
)

func makeMsgInput(epoch int64, gssID string, sv int32, ch domain.ChannelID, phase float32) domain.MessageInput {
	return domain.MessageInput{
		Epoch: epoch,
		GSSId: gssID,
		Sv:    sv,
		Measurement: domain.MessageMeasurement{
			ChannelId:  ch,
			CodePhase:  phase,
			SignalCtoN: 42,
		},
	}
}

func TestPairBuffer_ReturnsNilOnFirstSignal(t *testing.T) {
	buf := NewPairBuffer()
	msg := makeMsgInput(1000, "GSS1", 7, domain.ChannelL1B, 1.0)
	result, err := buf.Add(msg)
	require.NoError(t, err)
	assert.Nil(t, result, "should not emit until pair complete")
}

func TestPairBuffer_EmitsOnSecondSignal(t *testing.T) {
	buf := NewPairBuffer()
	_, err := buf.Add(makeMsgInput(1000, "GSS1", 7, domain.ChannelL1B, 1.0))
	require.NoError(t, err)
	result, err := buf.Add(makeMsgInput(1000, "GSS1", 7, domain.ChannelE5A, 2.0))
	require.NoError(t, err)
	require.NotNil(t, result)
	assert.Equal(t, uint16(7), result.SatelliteID)
	assert.True(t, result.SecMeas)
	assert.InDelta(t, 1.0, result.MeasData[0].Phase, 0.001)
}

func TestPairBuffer_ClearsAfterEmit(t *testing.T) {
	buf := NewPairBuffer()
	_, _ = buf.Add(makeMsgInput(1000, "GSS1", 7, domain.ChannelL1B, 1.0))
	_, _ = buf.Add(makeMsgInput(1000, "GSS1", 7, domain.ChannelE5A, 2.0))
	// After emit, buffer should be empty for that key.
	result, err := buf.Add(makeMsgInput(1000, "GSS1", 7, domain.ChannelL1B, 3.0))
	require.NoError(t, err)
	assert.Nil(t, result, "should wait for second signal again")
}

func TestPairBuffer_DifferentSVsAreIndependent(t *testing.T) {
	buf := NewPairBuffer()
	_, _ = buf.Add(makeMsgInput(1000, "GSS1", 1, domain.ChannelL1B, 1.0))
	result, err := buf.Add(makeMsgInput(1000, "GSS1", 2, domain.ChannelL1B, 2.0))
	require.NoError(t, err)
	assert.Nil(t, result)
}

func TestPairBuffer_FlushReturnsSingleSignal(t *testing.T) {
	buf := NewPairBuffer()
	_, _ = buf.Add(makeMsgInput(1000, "GSS1", 5, domain.ChannelL1B, 9.0))
	flushed, err := buf.Flush(1000)
	require.NoError(t, err)
	assert.Len(t, flushed, 1)
	assert.Equal(t, uint16(5), flushed[0].SatelliteID)
	assert.False(t, flushed[0].SecMeas)
}

func TestPairBuffer_FlushIgnoresDifferentEpoch(t *testing.T) {
	buf := NewPairBuffer()
	_, _ = buf.Add(makeMsgInput(1000, "GSS1", 5, domain.ChannelL1B, 9.0))
	flushed, err := buf.Flush(9999)
	require.NoError(t, err)
	assert.Len(t, flushed, 0)
}
