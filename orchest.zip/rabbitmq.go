package messaging

import (
	"context"
	"encoding/json"
	"fmt"
	"sync"

	amqp "github.com/rabbitmq/amqp091-go"
)

// ─── Consumer interface ───────────────────────────────────────────────────────

// ConsumerAPI defines the contract for consuming messages from a queue.
//
// The returned delivery channel is owned by the caller until Close() is called.
// Implementations must be safe to call Consume() and Close() concurrently.
//
//go:generate mockery --name=ConsumerAPI --output=../mocks --outpkg=mocks
type ConsumerAPI interface {
	// Consume binds to the given exchange and returns a delivery channel.
	// headers is used for header-exchange routing; args are extra AMQP table args.
	Consume(exchangeName, queueName, vhost string, headers map[string]any, args amqp.Table) (<-chan amqp.Delivery, error)
	// Close tears down the underlying AMQP channel.
	Close() error
}

// ─── Producer interface ───────────────────────────────────────────────────────

// ProducerAPI defines the contract for publishing messages to an exchange.
//
//go:generate mockery --name=ProducerAPI --output=../mocks --outpkg=mocks
type ProducerAPI interface {
	// Send marshals message to JSON and publishes it to exchangeName with
	// the given routing key. headers are forwarded as AMQP message headers.
	Send(message any, exchangeName, routingKey string, headers map[string]any, vhost string) error
}

// ─── RabbitMQService ─────────────────────────────────────────────────────────

// RabbitMQService is a single AMQP connection that exposes both consumer and
// producer capabilities. One instance should be shared across the process —
// AMQP channels are cheap, connections are not.
//
// Thread-safe: channel creation is serialised by mu.
type RabbitMQService struct {
	mu   sync.Mutex
	conn *amqp.Connection
}

// NewRabbitMQService dials the broker at url and returns a ready service.
// The caller owns the service and must call Close() at shutdown.
func NewRabbitMQService(url string) (*RabbitMQService, error) {
	conn, err := amqp.Dial(url)
	if err != nil {
		return nil, fmt.Errorf("rabbitmq dial: %w", err)
	}
	return &RabbitMQService{conn: conn}, nil
}

// Close shuts down the underlying AMQP connection.
func (r *RabbitMQService) Close() error {
	return r.conn.Close()
}

// ─── Publishing ───────────────────────────────────────────────────────────────

// PublishMessage serialises body as-is and publishes it as a persistent
// message to exchange with the given routing key. properties are merged into
// the AMQP message as extra header fields.
func (r *RabbitMQService) PublishMessage(exchange, routingKey string, body []byte, headers map[string]any, properties amqp.Table) error {
	ch, err := r.openChannel()
	if err != nil {
		return err
	}
	defer func() { _ = ch.Close() }()

	amqpHeaders := amqp.Table{}
	for k, v := range headers {
		amqpHeaders[k] = v
	}
	for k, v := range properties {
		amqpHeaders[k] = v
	}

	return ch.PublishWithContext(
		context.Background(),
		exchange, routingKey,
		false, false,
		amqp.Publishing{
			ContentType:  "application/json",
			DeliveryMode: amqp.Persistent,
			Headers:      amqpHeaders,
			Body:         body,
		},
	)
}

// Send implements ProducerAPI.
// It marshals message to JSON and delegates to PublishMessage.
func (r *RabbitMQService) Send(message any, exchangeName, routingKey string, headers map[string]any, _ string) error {
	body, err := json.Marshal(message)
	if err != nil {
		return fmt.Errorf("marshal message: %w", err)
	}
	return r.PublishMessage(exchangeName, routingKey, body, headers, nil)
}

// ─── Consuming ────────────────────────────────────────────────────────────────

// ReadMessagesFromTopicExchange declares an exclusive queue bound to exchange
// with routingKey and returns the delivery channel.
func (r *RabbitMQService) ReadMessagesFromTopicExchange(exchange, routingKey, queue string) (<-chan amqp.Delivery, error) {
	ch, err := r.openChannel()
	if err != nil {
		return nil, err
	}
	if err := r.declareAndBind(ch, exchange, "topic", routingKey, queue, nil); err != nil {
		_ = ch.Close()
		return nil, err
	}
	return r.consume(ch, queue)
}

// ReadMessagesFromHeaderExchange declares an exclusive queue bound to exchange
// using header matching and returns the delivery channel.
func (r *RabbitMQService) ReadMessagesFromHeaderExchange(exchange string, headers map[string]any, queue string) (<-chan amqp.Delivery, error) {
	ch, err := r.openChannel()
	if err != nil {
		return nil, err
	}
	amqpHeaders := amqp.Table{}
	for k, v := range headers {
		amqpHeaders[k] = v
	}
	if _, ok := amqpHeaders["x-match"]; !ok {
		amqpHeaders["x-match"] = "all"
	}
	if err := r.declareAndBind(ch, exchange, "headers", "", queue, amqpHeaders); err != nil {
		_ = ch.Close()
		return nil, err
	}
	return r.consume(ch, queue)
}

// Consume implements ConsumerAPI.
// It routes to ReadMessagesFromHeaderExchange when headers is non-nil,
// otherwise to ReadMessagesFromTopicExchange using exchangeName as routing key.
func (r *RabbitMQService) Consume(exchangeName, queueName, _ string, headers map[string]any, args amqp.Table) (<-chan amqp.Delivery, error) {
	if len(headers) > 0 {
		return r.ReadMessagesFromHeaderExchange(exchangeName, headers, queueName)
	}
	routingKey := ""
	if args != nil {
		if rk, ok := args["routing_key"].(string); ok {
			routingKey = rk
		}
	}
	return r.ReadMessagesFromTopicExchange(exchangeName, routingKey, queueName)
}

// ─── internal helpers ─────────────────────────────────────────────────────────

func (r *RabbitMQService) openChannel() (*amqp.Channel, error) {
	r.mu.Lock()
	defer r.mu.Unlock()
	ch, err := r.conn.Channel()
	if err != nil {
		return nil, fmt.Errorf("open channel: %w", err)
	}
	return ch, nil
}

func (r *RabbitMQService) declareAndBind(ch *amqp.Channel, exchange, kind, routingKey, queue string, headers amqp.Table) error {
	if err := ch.ExchangeDeclarePassive(exchange, kind, true, false, false, false, nil); err != nil {
		return fmt.Errorf("exchange declare passive %q: %w", exchange, err)
	}
	q, err := ch.QueueDeclare(queue, true, false, false, false, nil)
	if err != nil {
		return fmt.Errorf("queue declare %q: %w", queue, err)
	}
	if err := ch.QueueBind(q.Name, routingKey, exchange, false, headers); err != nil {
		return fmt.Errorf("queue bind %q → %q: %w", q.Name, exchange, err)
	}
	return nil
}

func (r *RabbitMQService) consume(ch *amqp.Channel, queue string) (<-chan amqp.Delivery, error) {
	deliveries, err := ch.Consume(queue, "", false, true, false, false, nil)
	if err != nil {
		_ = ch.Close()
		return nil, fmt.Errorf("consume %q: %w", queue, err)
	}
	return deliveries, nil
}
