package orchestrator

import (
	"context"
	"fmt"
	"log/slog"
	"sync"

	"github.com/yourorg/gnss-processor/internal/alert"
	"github.com/yourorg/gnss-processor/internal/core"
	"github.com/yourorg/gnss-processor/internal/domain"
)

// ─── GSSReadinessTracker ──────────────────────────────────────────────────────

// GSSReadinessTracker records which GSS stations have contributed at least one
// measurement for the current execute-epoch in this lane.
//
// It is consulted synchronously inside Ingest() at execute-epoch boundaries.
// In offline mode every station's data for a given epoch typically arrives
// before the epoch advances, so IsReady() returns true immediately.
// In real-time mode a small fraction of late-arriving stations may be missing;
// the ratio threshold controls the minimum acceptable coverage.
type GSSReadinessTracker struct {
	mu            sync.Mutex
	expected      []string
	seenThisEpoch map[string]struct{}
	epoch         int64
	ratio         float64
}

// newGSSReadinessTracker creates a tracker for the given station list.
// ratio is the minimum fraction of expected stations that must have contributed
// before IsReady() returns true. 1.0 = all required; 0.0 = always ready.
func newGSSReadinessTracker(expected []string, ratio float64) *GSSReadinessTracker {
	if ratio < 0 {
		ratio = 0
	}
	if ratio > 1 {
		ratio = 1
	}
	return &GSSReadinessTracker{
		expected:      expected,
		seenThisEpoch: make(map[string]struct{}),
		ratio:         ratio,
	}
}

// RecordArrival marks gssID as having contributed for epoch.
// Resets the seen-set automatically when the epoch advances.
func (t *GSSReadinessTracker) RecordArrival(gssID string, epoch int64) {
	t.mu.Lock()
	defer t.mu.Unlock()
	if epoch != t.epoch {
		t.seenThisEpoch = make(map[string]struct{})
		t.epoch = epoch
	}
	t.seenThisEpoch[gssID] = struct{}{}
}

// IsReady returns true when at least ratio × len(expected) stations have
// contributed for the current epoch. If expected is empty, always true.
func (t *GSSReadinessTracker) IsReady() bool {
	t.mu.Lock()
	defer t.mu.Unlock()
	if len(t.expected) == 0 {
		return true
	}
	required := int(float64(len(t.expected)) * t.ratio)
	if required == 0 {
		return true
	}
	return len(t.seenThisEpoch) >= required
}

// Coverage returns (seen, total) for the current epoch.
func (t *GSSReadinessTracker) Coverage() (int, int) {
	t.mu.Lock()
	defer t.mu.Unlock()
	return len(t.seenThisEpoch), len(t.expected)
}

// ─── ServiceLaneConfig ────────────────────────────────────────────────────────

// ServiceLaneConfig carries all data-driven cadence parameters for a lane.
// All step values are in epoch units (seconds). No time.Duration fields —
// this keeps behaviour identical in real-time and offline replay modes.
type ServiceLaneConfig struct {
	// PPStep: call PP() whenever the incoming epoch has advanced by at least
	// this many epoch-seconds since the last PP call. Default: 1.
	PPStep int64

	// ExecuteStep: call Execute() whenever the incoming epoch has advanced by
	// at least this many epoch-seconds since the last Execute call.
	// Corresponds to one Kalman filter step. Default: 60.
	ExecuteStep int64

	// GSSReadinessRatio: fraction of expected stations required before Execute
	// is triggered at an execute-epoch boundary. Default: 1.0.
	GSSReadinessRatio float64
}

// ─── ServiceLane ──────────────────────────────────────────────────────────────

// ServiceLane is an independent, event-driven processing pipeline for one
// navigation service (FNAV or INAV).
//
// # Event-driven, not time-driven
//
// PP and Execute are triggered entirely by epoch boundaries observed in the
// incoming data stream, not by wall-clock tickers:
//
//   - PP fires when a message arrives whose epoch has advanced ≥ PPStep
//     epoch-seconds past the last PP epoch.
//   - Execute fires when a message arrives whose epoch has advanced ≥ ExecuteStep
//     epoch-seconds past the last Execute epoch, AND GSS readiness is satisfied.
//
// This makes the lane work correctly in two modes without configuration changes:
//
//	Real-time:  messages arrive at ~1 Hz. Epoch boundaries are crossed at
//	            natural cadence; PP fires every second and Execute every
//	            ExecuteStep seconds of real time.
//
//	Offline:    messages arrive as fast as possible. PP and Execute fire at the
//	            same logical rate but at whatever wall-clock speed the CPU allows.
//	            Three days of data produces three days' worth of outputs.
//
// # Post-Execute config reload
//
// The optional OnEpochDone callback is invoked synchronously after a successful
// Execute. It is the hook used by main to reload remote config from the cache
// after each epoch so parameter changes take effect promptly.
//
// # No goroutines
//
// ServiceLane spawns no goroutines. All processing is synchronous inside
// Ingest(). The consumer goroutine drives everything.
type ServiceLane struct {
	serviceID domain.ServiceID
	cfg       ServiceLaneConfig

	// Injected layer dependencies.
	core    CoreLayer
	pub     PublishLayer
	alerter AlertLayer
	snap    SnapshotLayer
	log     *slog.Logger

	// Per-lane state.
	pairs     *PairBuffer
	readiness *GSSReadinessTracker
	registry  StationRegistryLayer

	epochs  map[int64]*EpochWindow
	epochMu sync.Mutex

	// Data-epoch cursors — updated every time PP or Execute fires.
	lastPPEpoch   int64
	lastExecEpoch int64

	healthMap [domain.MaxSV]bool

	// OnEpochDone is called after each successful Execute with the epoch that
	// was just processed. Use it to trigger remote-config reloads.
	// May be nil (noop).
	OnEpochDone func(epoch int64)
}

// NewServiceLane constructs a lane for the given service with its dependencies.
func NewServiceLane(
	serviceID domain.ServiceID,
	c CoreLayer,
	pub PublishLayer,
	al AlertLayer,
	ss SnapshotLayer,
	registry StationRegistryLayer,
	expectedGSS []string,
	cfg ServiceLaneConfig,
	log *slog.Logger,
) *ServiceLane {
	return &ServiceLane{
		serviceID: serviceID,
		cfg:       cfg,
		core:      c,
		pub:       pub,
		alerter:   al,
		snap:      ss,
		pairs:     NewPairBuffer(registry),
		readiness: newGSSReadinessTracker(expectedGSS, cfg.GSSReadinessRatio),
		registry:  registry,
		epochs:    make(map[int64]*EpochWindow),
		log:       log,
	}
}

// ─── Message intake ───────────────────────────────────────────────────────────

// Ingest is the single entry point for messages into this lane.
// It is called synchronously by Orchestrator.HandleMessage — no goroutines.
//
// For every message it:
//  1. Records GSS arrival for readiness tracking.
//  2. Pairs the signal; calls AddMeasurement + records SV on a complete pair.
//  3. Checks whether the epoch boundary triggers a PP-step or Execute-step.
func (l *ServiceLane) Ingest(ctx context.Context, msg domain.MessageInput) error {
	window := l.getOrCreateWindow(msg.Epoch)
	if window.IsFinalized() {
		l.log.Warn("lane: message for finalized epoch dropped",
			"service", l.serviceID, "epoch", msg.Epoch)
		return nil
	}

	// Record arrival before pairing — station is "seen" even if its counterpart
	// signal hasn't arrived yet.
	l.readiness.RecordArrival(msg.GSSId, msg.Epoch)

	if err := l.ingestPair(ctx, msg, window); err != nil {
		return err
	}

	// Bootstrap: first message ever seen initialises the cursor and returns.
	if l.lastPPEpoch == 0 {
		l.lastPPEpoch = msg.Epoch
		return nil
	}

	if l.shouldRunPP(msg.Epoch) {
		if err := l.runPP(ctx, l.lastPPEpoch, msg.Epoch); err != nil {
			return err
		}
	}

	if l.shouldRunExecute(msg.Epoch) {
		if err := l.runEpochClose(ctx, l.lastPPEpoch); err != nil {
			l.log.Error("lane: epoch close failed",
				"service", l.serviceID, "epoch", l.lastPPEpoch, "err", err)
			l.alerter.Alert(ctx, alert.EpochFailure,
				fmt.Sprintf("[%s] epoch %d: %v", l.serviceID, l.lastPPEpoch, err))
		}
	}

	return nil
}

// UpdateHealthMap replaces the per-SV health bitmask used at epoch-close.
func (l *ServiceLane) UpdateHealthMap(health [domain.MaxSV]bool) {
	l.epochMu.Lock()
	defer l.epochMu.Unlock()
	l.healthMap = health
}

// UpdateConfig replaces the lane cadence configuration at runtime.
// Called after a remote-config reload so parameter changes are applied
// without restarting the service.
func (l *ServiceLane) UpdateConfig(cfg ServiceLaneConfig) {
	l.epochMu.Lock()
	defer l.epochMu.Unlock()
	l.cfg = cfg
}

// ─── Pair ingestion ───────────────────────────────────────────────────────────

func (l *ServiceLane) ingestPair(_ context.Context, msg domain.MessageInput, window *EpochWindow) error {
	params, err := l.pairs.Add(msg)
	if err != nil {
		return fmt.Errorf("pair buffer [%s]: %w", l.serviceID, err)
	}
	if params == nil {
		return nil
	}
	if err := l.core.AddMeasurement(*params); err != nil {
		return fmt.Errorf("[%s] AddMeasurement: %w", l.serviceID, err)
	}
	window.RecordSV(msg.Sv)
	return nil
}

// ─── Epoch-boundary trigger logic ────────────────────────────────────────────

// shouldRunPP returns true when incomingEpoch has advanced past lastPPEpoch.
func (l *ServiceLane) shouldRunPP(incomingEpoch int64) bool {
	return incomingEpoch > l.lastPPEpoch
}

// shouldRunExecute returns true when both cadence and readiness conditions
// are met: enough epoch-time has passed AND enough GSS stations have reported.
func (l *ServiceLane) shouldRunExecute(incomingEpoch int64) bool {
	if l.lastExecEpoch == 0 && l.lastPPEpoch == 0 {
		return false
	}
	execTarget := l.lastPPEpoch
	if execTarget == l.lastExecEpoch {
		return false
	}
	if incomingEpoch-l.lastExecEpoch < l.cfg.ExecuteStep {
		return false
	}
	if !l.readiness.IsReady() {
		seen, total := l.readiness.Coverage()
		l.log.Warn("lane: Execute deferred — GSS coverage below threshold",
			"service", l.serviceID, "epoch", execTarget,
			"seen", seen, "total", total,
			"ratio", l.cfg.GSSReadinessRatio)
		return false
	}
	return true
}

// ─── PP step ──────────────────────────────────────────────────────────────────

// runPP closes all epoch-seconds between closingEpoch (inclusive) and
// nextEpoch (exclusive), calling Flush + PP for each one. It advances
// lastPPEpoch one step at a time so a mid-gap failure leaves the cursor at
// the last successfully processed epoch.
func (l *ServiceLane) runPP(_ context.Context, closingEpoch, nextEpoch int64) error {
	for ep := closingEpoch; ep < nextEpoch; ep += l.cfg.PPStep {
		if err := l.flushPendingPairs(ep); err != nil {
			return err
		}
		if err := l.core.PP(ep); err != nil {
			return fmt.Errorf("[%s] PP epoch %d: %w", l.serviceID, ep, err)
		}
		l.lastPPEpoch = ep + l.cfg.PPStep
		l.log.Debug("lane: PP fired", "service", l.serviceID, "epoch", ep)
	}
	return nil
}

// ─── Execute step (epoch-close pipeline) ─────────────────────────────────────

func (l *ServiceLane) runEpochClose(ctx context.Context, epoch int64) error {
	if err := l.core.RemoveUnhealthySat(l.healthMap, epoch); err != nil {
		return fmt.Errorf("[%s] RemoveUnhealthySat: %w", l.serviceID, err)
	}
	if err := l.core.ComputeStationPositions(float64(epoch)); err != nil {
		return fmt.Errorf("[%s] ComputeStationPositions: %w", l.serviceID, err)
	}

	output, err := l.core.Execute(epoch)
	if err != nil {
		return fmt.Errorf("[%s] Execute: %w", l.serviceID, err)
	}

	l.getOrCreateWindow(epoch).Finalize()
	l.lastExecEpoch = epoch

	l.publishResult(ctx, epoch, output)
	if err := l.dumpSnapshot(ctx, epoch); err != nil {
		return err
	}

	// Notify caller (e.g. main) so it can reload remote config after each epoch.
	if l.OnEpochDone != nil {
		l.OnEpochDone(epoch)
	}
	return nil
}

func (l *ServiceLane) flushPendingPairs(epoch int64) error {
	flushed, err := l.pairs.Flush(epoch)
	if err != nil {
		return fmt.Errorf("[%s] flush pairs: %w", l.serviceID, err)
	}
	for _, p := range flushed {
		if err := l.core.AddMeasurement(p); err != nil {
			return fmt.Errorf("[%s] flush AddMeasurement: %w", l.serviceID, err)
		}
	}
	return nil
}

// publishResult is non-fatal: broker unavailability must not prevent snapshot.
func (l *ServiceLane) publishResult(ctx context.Context, epoch int64, output *core.ExecuteOutput) {
	activeSVs := l.getOrCreateWindow(epoch).ActiveSVs()
	if l.registry == nil {
		return
	}
	activeSlots, err := l.registry.AllSlots()
	if err != nil {
		l.log.Warn("lane: could not resolve station slots for publish",
			"service", l.serviceID, "epoch", epoch, "err", err)
		return
	}
	result := output.ToEpochResult(epoch, l.serviceID, activeSVs, activeSlots)
	if err := l.pub.Publish(ctx, result); err != nil {
		l.log.Warn("lane: publish failed",
			"service", l.serviceID, "epoch", epoch, "err", err)
	}
}

func (l *ServiceLane) dumpSnapshot(ctx context.Context, epoch int64) error {
	snap, err := l.core.DumpSnapshot()
	if err != nil {
		return fmt.Errorf("[%s] DumpSnapshot: %w", l.serviceID, err)
	}
	snap.Epoch = epoch
	if err := l.snap.Save(ctx, snap); err != nil {
		return fmt.Errorf("[%s] snapshot Save: %w", l.serviceID, err)
	}
	return nil
}

// ─── Epoch window management ──────────────────────────────────────────────────

const laneWindowBuffer = 3

func (l *ServiceLane) getOrCreateWindow(epoch int64) *EpochWindow {
	l.epochMu.Lock()
	defer l.epochMu.Unlock()
	if w, ok := l.epochs[epoch]; ok {
		return w
	}
	l.pruneOldWindows()
	w := NewEpochWindow(epoch)
	l.epochs[epoch] = w
	return w
}

// pruneOldWindows evicts finalized windows and any epochs that have fallen too
// far behind the current execute cursor. Keeps memory bounded in offline mode.
func (l *ServiceLane) pruneOldWindows() {
	horizon := l.lastExecEpoch - l.cfg.ExecuteStep*int64(laneWindowBuffer)
	for ep, w := range l.epochs {
		if w.IsFinalized() || ep < horizon {
			delete(l.epochs, ep)
		}
	}
}
