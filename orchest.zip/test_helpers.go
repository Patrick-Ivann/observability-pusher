package orchestrator

import (
	"context"

	"github.com/yourorg/gnss-processor/internal/domain"
)

// ForceExecute triggers runEpochClose on the FNAV lane — test/dev use only.
// In production the pipeline is driven by HandleMessage; this helper bypasses
// the epoch-boundary predicates so tests can close an epoch on demand.
func (o *Orchestrator) ForceExecute(ctx context.Context, epoch int64) error {
	return o.lanes[domain.ServiceFNAV].runEpochClose(ctx, epoch)
}

// FinalizeEpochForTest marks an epoch as finalized in the FNAV lane without
// running Execute. Used by tests to assert late-message-drop behaviour.
func (o *Orchestrator) FinalizeEpochForTest(epoch int64) {
	o.lanes[domain.ServiceFNAV].getOrCreateWindow(epoch).Finalize()
}
