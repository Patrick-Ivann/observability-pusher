package customlogger

import (
    "fmt"
    "github.com/spf13/viper"
    "github.com/clbanning/mxj"
    "io/ioutil"
)

// ✅ Load XML config once
func LoadConfig(filePath string) error {
    data, err := ioutil.ReadFile(filePath)
    if err != nil {
        return fmt.Errorf("failed to read config file: %v", err)
    }

    xmlMap, err := mxj.NewMapXml(data)
    if err != nil {
        return fmt.Errorf("failed to parse XML: %v", err)
    }

    viper.Set("config", xmlMap)
    return nil
}

// ✅ Get log level from XML config
func GetLogLevel() slog.Level {
    level := viper.GetString("config.logging.logLevel")
    if lvl, exists := LogLevels[level]; exists {
        return lvl
    }
    return slog.LevelInfo // Default level
}

// ✅ Available log levels
var LogLevels = map[string]slog.Level{
    "info":    slog.LevelInfo,
    "notice":  slog.LevelWarn,
    "warn":    slog.LevelWarn,
    "fatal":   slog.LevelError,
}
