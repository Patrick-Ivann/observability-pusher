package customlogger

import (
    "encoding/xml"
    "fmt"
    "io/ioutil"
    "sync"
)

var notificationsCache map[string]Notification
var once sync.Once

type Notification struct {
    Criticality string `xml:"criticality,attr"`
    Transient   bool   `xml:"transient,attr"`
    ID          string `xml:"ID,attr"`
    Text        string `xml:"text"`
}

func LoadNotifications(filePath string) error {
    once.Do(func() {
        data, err := ioutil.ReadFile(filePath)
        if err != nil {
            fmt.Println("Error reading notifications:", err)
            return
        }

        var notifications []Notification
        err = xml.Unmarshal(data, &notifications)
        if err != nil {
            fmt.Println("Error parsing notifications:", err)
            return
        }

        notificationsCache = make(map[string]Notification)
        for _, n := range notifications {
            notificationsCache[n.ID] = n
        }
    })

    return nil
}

func Notification(id string, placeholders ...string) {
    notif, exists := notificationsCache[id]
    if !exists {
        fmt.Println("Notification ID not found:", id)
        return
    }

    msg := fmt.Sprintf(notif.Text, placeholders...)
    notif.Text = msg // ✅ Replace placeholders

    jsonData, err := json.Marshal(notif)
    if err != nil {
        fmt.Println("Failed to marshal notification:", err)
        return
    }

    os.Stdout.Write(jsonData) // ✅ Print separate JSON output
}

func GetCachedNotification(id string) (Notification, bool) {
    notif, exists := notificationsCache[id]
    return notif, exists
}
