package customlogger

import (
    "encoding/xml"
    "os"
    "testing"

    "github.com/stretchr/testify/assert"
)

// ✅ Setup temporary test XML file
func setupTestXML(content string) string {
    filePath := "test_events.xml"
    os.WriteFile(filePath, []byte(content), 0644)
    return filePath
}

// ✅ Test notification loading & caching
func TestLoadNotifications(t *testing.T) {
    filePath := setupTestXML(`
        <notifications>
            <notification criticality="info" transient="true" ID="TEST_NOTIFICATION">
                <text>System alert {0}</text>
            </notification>
        </notifications>
    `)

    err := LoadNotifications(filePath)
    assert.NoError(t, err, "Expected successful XML parsing")

    notif, exists := GetCachedNotification("TEST_NOTIFICATION")
    assert.True(t, exists, "Notification should be cached")
    assert.Equal(t, "info", notif.Criticality)
    assert.Equal(t, true, notif.Transient)
    assert.Equal(t, "TEST_NOTIFICATION", notif.ID)
    assert.Equal(t, "System alert {0}", notif.Text)
}

func TestMissingEvent(t *testing.T) {
    _, exists := GetCachedNotification("UNKNOWN_ID")
    assert.False(t, exists, "Expected missing notification to return false")
}

func TestMalformedXML(t *testing.T) {
    filePath := setupTestXML(`<invalid>XML</invalid>`)

    err := LoadNotifications(filePath)
    assert.Error(t, err, "Expected failure when parsing malformed XML")
}

func TestUnmarshalError(t *testing.T) {
    brokenData := []byte("<notifications><notification><text>Missing attrs</text></notification></notifications>")
    var notifications []Notification
    err := xml.Unmarshal(brokenData, &notifications)

    assert.Error(t, err, "Expected XML unmarshaling error")
}

func cleanupTestFiles() {
    os.Remove("test_events.xml")
}
