package customlogger

import (
    "log/slog"
    "os"
)


// customlogger.Fatal("oupsi hihi")
// customlogger.Notification("EVENT_ID", "first param")


type Logger interface {
    Info(msg string, args ...any)
    Notice(msg string, args ...any)
    Warn(msg string, args ...any)
    Fatal(msg string, args ...any)
    Notification(id string, placeholders ...string)
}

type LogEntry struct {
    Level     string      `json:"level"`
    Timestamp string      `json:"timestamp"`
    Message   string      `json:"message"`
    Thread    int         `json:"thread"`
}

type slogLogger struct {
    logger   *slog.Logger
    logLevel slog.Level
}

func NewLogger(level slog.Level) Logger {
    return &slogLogger{
        logger:   slog.New(slog.NewJSONHandler(os.Stdout, nil)),
        logLevel: level,
    }
}

func logJSON(level string, msg string) {
    entry := LogEntry{
        Level:     level,
        Timestamp: time.Now().Format(time.RFC3339),
        Message:   msg,
        Thread:    getThreadID(),
    }

    jsonData, err := json.Marshal(entry)
    if err != nil {
        logger.Error("Failed to marshal JSON log", err)
        return
    }

    os.Stdout.Write(jsonData) // ✅ Print structured JSON log
}


func Info(msg string) {
    if logLevel <= slog.LevelInfo {
        logJSON("info", msg)
    }
}


func Warn(msg string) {
    if logLevel <= slog.LevelWarn {
        logJSON("warn", msg)
    }
}


func Notice(msg string) {
    if logLevel <= slog.LevelWarn {
        logJSON("notice", msg)
    }
}


func Fatal(msg string) {
    if logLevel <= slog.LevelError {
        logJSON("fatal", msg)
        os.Exit(1) // Terminate app
    }
}

func (l *slogLogger) Event(id string, placeholders ...string) {
    notif, exists := GetCachedEvent(id)
    if !exists {
        l.logger.Warn("Event ID not found: " + id)
        return
    }

    msg := fmt.Sprintf(notif.Text, placeholders...)
    l.logger.Info("[Event] " + msg)
}
