package customlogger

import (
    "bytes"
    "log/slog"
    "os"
    "testing"

    "github.com/stretchr/testify/assert"
)

// ✅ Capture logs for assertion
func captureLogs(level slog.Level, logFunc func(string, ...any)) string {
    var buf bytes.Buffer
    logger := slog.New(slog.NewTextHandler(&buf, nil))
    logFunc("Test message")
    return buf.String()
}

// ✅ Test log level filtering
func TestLogLevelFiltering(t *testing.T) {
    ConfigureLogger("warn")

    infoLog := captureLogs(slog.LevelInfo, Info)
    assert.Empty(t, infoLog, "INFO logs should be filtered out")

    warnLog := captureLogs(slog.LevelWarn, Warn)
    assert.NotEmpty(t, warnLog, "WARN logs should appear")
}

// ✅ Test XML unmarshaling errors
func TestInvalidXML(t *testing.T) {
    err := LoadNotifications("invalid.xml")
    assert.Error(t, err, "Expected XML unmarshaling error")
}

// ✅ Test file reading error
func TestFileNotFound(t *testing.T) {
    err := LoadNotifications("missing.xml")
    assert.Error(t, err, "Expected file reading error")
}

// ✅ Test `NewMapXml` failure
func TestNewMapXmlError(t *testing.T) {
    invalidData := []byte("<invalid>")
    _, err := mxj.NewMapXml(invalidData)
    assert.Error(t, err, "Expected NewMapXml error")
}

// ✅ Test missing log level case
func TestMissingLogLevel(t *testing.T) {
    lvl := GetLogLevel()
    assert.Equal(t, slog.LevelInfo, lvl, "Expected default INFO level")
}

// ✅ Test individual logging methods
func TestNoticeLogging(t *testing.T) {
    log := captureLogs(slog.LevelWarn, Notice)
    assert.NotEmpty(t, log, "Expected NOTICE log")
}

func TestWarnLogging(t *testing.T) {
    log := captureLogs(slog.LevelWarn, Warn)
    assert.NotEmpty(t, log, "Expected WARN log")
}



// ✅ Benchmark INFO logging performance
func BenchmarkInfoLog(b *testing.B) {
    for i := 0; i < b.N; i++ {
        Info("Benchmarking INFO log")
    }
}

// ✅ Benchmark WARN logging performance
func BenchmarkWarnLog(b *testing.B) {
    for i := 0; i < b.N; i++ {
        Warn("Benchmarking WARN log")
    }
}

// ✅ Benchmark Notification retrieval (cached)
func BenchmarkCachedNotification(b *testing.B) {
    LoadNotifications("notifications.xml") // ✅ Ensure cache is initialized

    b.ResetTimer() // ✅ Start benchmarking AFTER initialization
    for i := 0; i < b.N; i++ {
        _, exists := GetCachedNotification("MY_NOTIFICATION_ID")
        if !exists {
            b.Fatal("Expected cached notification to exist")
        }
    }
}

// ✅ Benchmark Notification retrieval (uncached)
func BenchmarkUncachedNotification(b *testing.B) {
    b.ResetTimer() // ✅ Prevent measuring setup overhead
    for i := 0; i < b.N; i++ {
        LoadNotifications("notifications.xml") // ✅ Simulates loading without caching
    }
}